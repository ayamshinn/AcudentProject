<?php
/**
 * Register Dentist User Account API
 * Creates user account with profile picture support
 */

// ✅ SUPPRESS PHP ERRORS FROM BREAKING JSON
error_reporting(0);
ini_set('display_errors', 0);

// ✅ SET JSON HEADER FIRST
header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ✅ CATCH ALL ERRORS
try {
    session_start();

    /* ===================== DB CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        echo json_encode(["success" => false, "message" => "Server error: DB connection missing. Path: " . $dbPath]);
        exit;
    }
    require_once $dbPath;

    // ✅ CHECK IF $conn EXISTS
    if (!isset($conn)) {
        echo json_encode(["success" => false, "message" => "Database connection variable \$conn not found"]);
        exit;
    }

    /* ===================== REQUEST CHECK ===================== */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
        exit;
    }

    /* ===================== DETECT INPUT TYPE ===================== */
    // Check if this is multipart/form-data (with file upload) or JSON
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    $isMultipart = strpos($contentType, 'multipart/form-data') !== false;

    if ($isMultipart) {
        // FormData with file upload
        $firstName = trim($_POST['first_name'] ?? '');
        $lastName = trim($_POST['last_name'] ?? '');
        $loginEmail = strtolower(trim($_POST['login_email'] ?? ''));
        $contactEmail = strtolower(trim($_POST['contact_email'] ?? ''));
        $password = trim($_POST['password'] ?? '');
    } else {
        // JSON data (backward compatibility)
        $input = json_decode(file_get_contents('php://input'), true);
        $firstName = trim($input['first_name'] ?? '');
        $lastName = trim($input['last_name'] ?? '');
        $loginEmail = strtolower(trim($input['login_email'] ?? ''));
        $contactEmail = strtolower(trim($input['contact_email'] ?? ''));
        $password = trim($input['password'] ?? '');
    }

    /* ===================== VALIDATION - SECTION 1 ===================== */
    $errors = [];

    // Required fields
    if (empty($firstName)) $errors[] = "First name is required";
    if (empty($lastName)) $errors[] = "Last name is required";
    if (empty($loginEmail)) $errors[] = "Login email is required";
    if (empty($contactEmail)) $errors[] = "Contact email is required";
    if (empty($password)) $errors[] = "Password is required";

    // Email validation
    if (!empty($loginEmail) && !filter_var($loginEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid login email format";
    }
    if (!empty($contactEmail) && !filter_var($contactEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid contact email format";
    }

    // Password validation
    if (!empty($password) && strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }

    // Return validation errors
    if (!empty($errors)) {
        echo json_encode([
            'success' => false,
            'message' => 'Validation failed',
            'errors' => $errors
        ]);
        exit;
    }

    /* ===================== CHECK EXISTING USERNAME ===================== */
    $checkUsernameQuery = "SELECT user_id FROM Users_tb WHERE username = ? LIMIT 1";
    $checkStmt = $conn->prepare($checkUsernameQuery);
    if (!$checkStmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
        exit;
    }

    $checkStmt->bind_param("s", $loginEmail);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Username already registered'
        ]);
        exit;
    }
    $checkStmt->close();

    /* ===================== CHECK EXISTING EMAIL ===================== */
    $checkEmailQuery = "SELECT user_id FROM Users_tb WHERE email = ? LIMIT 1";
    $checkEmailStmt = $conn->prepare($checkEmailQuery);
    if (!$checkEmailStmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
        exit;
    }

    $checkEmailStmt->bind_param("s", $contactEmail);
    $checkEmailStmt->execute();
    $checkEmailResult = $checkEmailStmt->get_result();

    if ($checkEmailResult->num_rows > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Email already registered'
        ]);
        exit;
    }
    $checkEmailStmt->close();

    /* ===================== GET DENTIST ROLE ID ===================== */
    $roleQuery = "SELECT role_id FROM Roles_tb WHERE role_name = 'Dentist' LIMIT 1";
    $roleResult = $conn->query($roleQuery);

    if (!$roleResult) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
        exit;
    }

    if ($roleResult->num_rows === 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Dentist role not found in system'
        ]);
        exit;
    }

    $roleData = $roleResult->fetch_assoc();
    $dentistRoleId = $roleData['role_id'];

    /* ===================== GENERATE USER CODE (USR-D-00X format) ===================== */
    function generateUserCode($conn, $prefix = 'USR-D-00') {
        // Get the count of existing Dentist users to determine next number
        $countQuery = "SELECT COUNT(*) as count FROM Users_tb WHERE user_code LIKE 'USR-D-00%'";
        $countResult = $conn->query($countQuery);
        
        if ($countResult) {
            $countData = $countResult->fetch_assoc();
            $nextNumber = $countData['count'] + 1;
        } else {
            $nextNumber = 1;
        }
        
        // Try up to 100 times to find an available user code
        $maxAttempts = 100;
        for ($i = 0; $i < $maxAttempts; $i++) {
            $userCode = $prefix . $nextNumber;
            
            // Check if this code already exists
            $checkQuery = "SELECT user_id FROM Users_tb WHERE user_code = ? LIMIT 1";
            $checkStmt = $conn->prepare($checkQuery);
            $checkStmt->bind_param("s", $userCode);
            $checkStmt->execute();
            $result = $checkStmt->get_result();
            
            if ($result->num_rows === 0) {
                return $userCode;
            }
            
            // If exists, try next number
            $nextNumber++;
        }
        
        return null;
    }

    $userCode = generateUserCode($conn, 'USR-D-00');
    if (!$userCode) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to generate unique user code'
        ]);
        exit;
    }

    /* ===================== HANDLE PROFILE PICTURE UPLOAD (ACCOUNT PHOTO) ===================== */
    $profilePicturePath = null;
    $profilePictureBlob = null;

    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        $file = $_FILES['profile_picture'];
        
        // Validate file type and size
        if (in_array($file['type'], $allowedTypes) && $file['size'] <= 5242880) { // 5MB max
            // Store as blob in database
            $profilePictureBlob = file_get_contents($file['tmp_name']);
            
            // Also save to filesystem
            $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/uploads/profiles/users/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = uniqid('user_profile_') . '_' . time() . '.' . $fileExtension;
            $fullPath = $uploadDir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $fullPath)) {
                $profilePicturePath = '/Acudent/uploads/profiles/users/' . $filename;
            }
        }
    }

    /* ===================== HASH PASSWORD ===================== */
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    /* ===================== INSERT USER WITH PROFILE PICTURE ===================== */
    $insertUserQuery = "
        INSERT INTO Users_tb (
            user_code,
            role_id,
            first_name,
            last_name,
            username,
            password_hash,
            email,
            profile_picture_path,
            profile_picture,
            created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ";

    $insertUserStmt = $conn->prepare($insertUserQuery);
    if (!$insertUserStmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
        exit;
    }

    $insertUserStmt->bind_param(
        "sisssssss",
        $userCode,
        $dentistRoleId,
        $firstName,
        $lastName,
        $loginEmail,
        $passwordHash,
        $contactEmail,
        $profilePicturePath,
        $profilePictureBlob
    );

    if (!$insertUserStmt->execute()) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to create dentist account: ' . $insertUserStmt->error
        ]);
        exit;
    }

    $newUserId = $insertUserStmt->insert_id;
    $insertUserStmt->close();

    /* ===================== SUCCESS RESPONSE ===================== */
    echo json_encode([
        'success' => true,
        'message' => 'Dentist account created successfully!',
        'dentist' => [
            'user_id' => $newUserId,
            'user_code' => $userCode,
            'username' => $loginEmail,
            'email' => $contactEmail,
            'first_name' => $firstName,
            'last_name' => $lastName,
            'profile_picture_path' => $profilePicturePath
        ],
        'redirect' => '../admin-ui/admin-main.php#../admin-ui/admin-subfolder/admin-dentist-management.html'
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}

exit;
?>