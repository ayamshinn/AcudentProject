<?php
// ✅ SUPPRESS PHP ERRORS FROM BREAKING JSON
error_reporting(0);
ini_set('display_errors', 0);

// ✅ SET JSON HEADER FIRST
header("Content-Type: application/json");

// ✅ CATCH ALL ERRORS
try {
    session_start();

    /* ===================== DB CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        echo json_encode(["success" => false, "message" => "Server error: DB connection missing. Path: " . $dbPath]);
        exit;
    }
    require_once $dbPath;

    // ✅ CHECK IF $conn EXISTS
    if (!isset($conn)) {
        echo json_encode(["success" => false, "message" => "Database connection variable \$conn not found"]);
        exit;
    }

    /* ===================== REQUEST CHECK ===================== */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
        exit;
    }

    /* ===================== INPUT - SECTION 1 ONLY ===================== */
    $input = json_decode(file_get_contents('php://input'), true);

    // Section 1: Account Information
    $firstName = trim($input['first_name'] ?? '');
    $lastName = trim($input['last_name'] ?? '');
    $loginEmail = strtolower(trim($input['login_email'] ?? ''));
    $contactEmail = strtolower(trim($input['contact_email'] ?? ''));
    $password = trim($input['password'] ?? '');

    /* ===================== VALIDATION - SECTION 1 ===================== */
    $errors = [];

    // Required fields
    if (empty($firstName)) $errors[] = "First name is required";
    if (empty($lastName)) $errors[] = "Last name is required";
    if (empty($loginEmail)) $errors[] = "Login email is required";
    if (empty($contactEmail)) $errors[] = "Contact email is required";
    if (empty($password)) $errors[] = "Password is required";

    // Email validation
    if (!empty($loginEmail) && !filter_var($loginEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid login email format";
    }
    if (!empty($contactEmail) && !filter_var($contactEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid contact email format";
    }

    // Password validation
    if (!empty($password) && strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }

    // Return validation errors
    if (!empty($errors)) {
        echo json_encode([
            'success' => false,
            'message' => 'Validation failed',
            'errors' => $errors
        ]);
        exit;
    }

    /* ===================== CHECK EXISTING USERNAME ===================== */
    $checkUsernameQuery = "SELECT user_id FROM Users_tb WHERE username = ? LIMIT 1";
    $checkStmt = $conn->prepare($checkUsernameQuery);
    if (!$checkStmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
        exit;
    }

    $checkStmt->bind_param("s", $loginEmail);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Username already registered'
        ]);
        exit;
    }

    /* ===================== CHECK EXISTING EMAIL ===================== */
    $checkEmailQuery = "SELECT user_id FROM Users_tb WHERE email = ? LIMIT 1";
    $checkEmailStmt = $conn->prepare($checkEmailQuery);
    if (!$checkEmailStmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
        exit;
    }

    $checkEmailStmt->bind_param("s", $contactEmail);
    $checkEmailStmt->execute();
    $checkEmailResult = $checkEmailStmt->get_result();

    if ($checkEmailResult->num_rows > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Email already registered'
        ]);
        exit;
    }

    /* ===================== GET FRONT DESK ROLE ID ===================== */
    $roleQuery = "SELECT role_id FROM Roles_tb WHERE role_name = 'Front Desk' LIMIT 1";
    $roleResult = $conn->query($roleQuery);

    if (!$roleResult) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
        exit;
    }

    if ($roleResult->num_rows === 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Front Desk role not found in system'
        ]);
        exit;
    }

    $roleData = $roleResult->fetch_assoc();
    $frontdeskRoleId = $roleData['role_id'];

    /* ===================== GENERATE USER CODE (USR-F-00X format) ===================== */
    function generateUserCode($conn, $prefix = 'USR-F-00') {
        // Get the count of existing Front Desk users to determine next number
        $countQuery = "SELECT COUNT(*) as count FROM Users_tb WHERE user_code LIKE 'USR-F-00%'";
        $countResult = $conn->query($countQuery);
        
        if ($countResult) {
            $countData = $countResult->fetch_assoc();
            $nextNumber = $countData['count'] + 1;
        } else {
            $nextNumber = 1;
        }
        
        // Try up to 100 times to find an available user code
        $maxAttempts = 100;
        for ($i = 0; $i < $maxAttempts; $i++) {
            // Format: USR-F-001, USR-F-0011, USR-F-00102, USR-F-009999
            // The "00" is fixed, then just append the number (no padding)
            $userCode = $prefix . $nextNumber;
            
            // Check if this code already exists
            $checkQuery = "SELECT user_id FROM Users_tb WHERE user_code = ? LIMIT 1";
            $checkStmt = $conn->prepare($checkQuery);
            $checkStmt->bind_param("s", $userCode);
            $checkStmt->execute();
            $result = $checkStmt->get_result();
            
            if ($result->num_rows === 0) {
                return $userCode;
            }
            
            // If exists, try next number
            $nextNumber++;
        }
        
        return null;
    }

    $userCode = generateUserCode($conn, 'USR-F-00');
    if (!$userCode) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to generate unique user code'
        ]);
        exit;
    }

    /* ===================== HASH PASSWORD ===================== */
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    /* ===================== INSERT USER ===================== */
    $insertUserQuery = "
        INSERT INTO Users_tb (
            user_code,
            role_id,
            first_name,
            last_name,
            username,
            password_hash,
            email,
            created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ";

    $insertUserStmt = $conn->prepare($insertUserQuery);
    if (!$insertUserStmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
        exit;
    }

    $insertUserStmt->bind_param(
        "sisssss",
        $userCode,
        $frontdeskRoleId,
        $firstName,
        $lastName,
        $loginEmail,
        $passwordHash,
        $contactEmail
    );

    if (!$insertUserStmt->execute()) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to create frontdesk account: ' . $insertUserStmt->error
        ]);
        exit;
    }

    $newUserId = $insertUserStmt->insert_id;

    /* ===================== SUCCESS RESPONSE ===================== */
    echo json_encode([
        'success' => true,
        'message' => 'Front Desk account created successfully!',
        'frontdesk' => [
            'user_id' => $newUserId,
            'user_code' => $userCode,
            'username' => $loginEmail,
            'email' => $contactEmail,
            'first_name' => $firstName,
            'last_name' => $lastName
        ],
        
        'redirect' => '../admin-ui/admin-main.php#../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management.html'
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}

exit;
?>