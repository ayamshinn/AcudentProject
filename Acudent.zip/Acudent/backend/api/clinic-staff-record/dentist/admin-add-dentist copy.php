<?php
header("Content-Type: application/json");
session_start();

/* ===================== DB CONNECTION ===================== */
$dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
if (!file_exists($dbPath)) {
    echo json_encode(["success" => false, "message" => "Server error: DB connection missing."]);
    exit;
}
require_once $dbPath;

/* ===================== AUTHENTICATION CHECK (Optional for testing) ===================== */
// Uncomment this section when testing with admin authentication
/*
if (!isset($_SESSION['user']) || $_SESSION['user']['role_name'] !== 'Admin') {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized access. Admin privileges required.'
    ]);
    exit;
}
*/

/* ===================== REQUEST CHECK ===================== */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

/* ===================== INPUT - SECTION 1 ONLY ===================== */
$input = json_decode(file_get_contents('php://input'), true);

// Section 1: Account Information
$firstName = trim($input['first_name'] ?? '');
$lastName = trim($input['last_name'] ?? '');
$loginEmail = strtolower(trim($input['login_email'] ?? ''));
$contactEmail = strtolower(trim($input['contact_email'] ?? ''));
$password = trim($input['password'] ?? '');

/* ===================== VALIDATION - SECTION 1 ===================== */
$errors = [];

// Required fields
if (empty($firstName)) $errors[] = "First name is required";
if (empty($lastName)) $errors[] = "Last name is required";
if (empty($loginEmail)) $errors[] = "Login email is required";
if (empty($contactEmail)) $errors[] = "Contact email is required";
if (empty($password)) $errors[] = "Password is required";

// Email validation
if (!empty($loginEmail) && !filter_var($loginEmail, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid login email format";
}
if (!empty($contactEmail) && !filter_var($contactEmail, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid contact email format";
}

// Password validation
if (!empty($password) && strlen($password) < 8) {
    $errors[] = "Password must be at least 8 characters";
}

// Return validation errors
if (!empty($errors)) {
    echo json_encode([
        'success' => false,
        'message' => 'Validation failed',
        'errors' => $errors
    ]);
    exit;
}

/* ===================== CHECK EXISTING USERNAME ===================== */
$checkUsernameQuery = "SELECT user_id FROM Users_tb WHERE username = ? LIMIT 1";
$checkStmt = $conn->prepare($checkUsernameQuery);
if (!$checkStmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $conn->error
    ]);
    exit;
}

$checkStmt->bind_param("s", $loginEmail);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Username already registered'
    ]);
    exit;
}

/* ===================== GET DENTIST ROLE ID ===================== */
$roleQuery = "SELECT role_id FROM Roles_tb WHERE role_name = 'Dentist' LIMIT 1";
$roleResult = $conn->query($roleQuery);

if (!$roleResult) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $conn->error
    ]);
    exit;
}

if ($roleResult->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Dentist role not found in system'
    ]);
    exit;
}

$roleData = $roleResult->fetch_assoc();
$dentistRoleId = $roleData['role_id'];

/* ===================== GENERATE USER CODE ===================== */
function generateUserCode($conn, $prefix = 'DEN') {
    $maxAttempts = 10;
    for ($i = 0; $i < $maxAttempts; $i++) {
        $randomNumber = str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
        $userCode = $prefix . $randomNumber;
        
        $checkQuery = "SELECT user_id FROM Users_tb WHERE user_code = ? LIMIT 1";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("s", $userCode);
        $checkStmt->execute();
        $result = $checkStmt->get_result();
        
        if ($result->num_rows === 0) {
            return $userCode;
        }
    }
    return null;
}

$userCode = generateUserCode($conn, 'DEN');
if (!$userCode) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to generate unique user code'
    ]);
    exit;
}

/* ===================== HASH PASSWORD ===================== */
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

/* ===================== INSERT USER - SECTION 1 DATA ONLY ===================== */
$insertUserQuery = "
    INSERT INTO Users_tb (
        user_code,
        role_id,
        first_name,
        last_name,
        username,
        password_hash,
        created_at
    ) VALUES (?, ?, ?, ?, ?, ?, NOW())
";

$insertUserStmt = $conn->prepare($insertUserQuery);
if (!$insertUserStmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $conn->error
    ]);
    exit;
}

$insertUserStmt->bind_param(
    "sissss",
    $userCode,
    $dentistRoleId,
    $firstName,
    $lastName,
    $loginEmail,
    $passwordHash
);

if (!$insertUserStmt->execute()) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to create dentist account: ' . $insertUserStmt->error
    ]);
    exit;
}

$newUserId = $insertUserStmt->insert_id;

/* ===================== INSERT BASIC DENTIST DETAILS (Contact Email Only) ===================== */
$insertDentistQuery = "
    INSERT INTO Dentist_Details_tb (
        user_id,
        contact_email,
        status
    ) VALUES (?, ?, 'active')
";

$insertDentistStmt = $conn->prepare($insertDentistQuery);
if (!$insertDentistStmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $conn->error
    ]);
    exit;
}

$insertDentistStmt->bind_param("is", $newUserId, $contactEmail);

if (!$insertDentistStmt->execute()) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to create dentist details: ' . $insertDentistStmt->error
    ]);
    exit;
}

/* ===================== SUCCESS RESPONSE ===================== */
echo json_encode([
    'success' => true,
    'message' => 'Section 1 Test Successful! Dentist account created with basic information.',
    'dentist' => [
        'user_id' => $newUserId,
        'user_code' => $userCode,
        'username' => $loginEmail,
        'contact_email' => $contactEmail,
        'first_name' => $firstName,
        'last_name' => $lastName
    ],
    'credentials' => [
        'username' => $loginEmail,
        'password' => $password  // Send plain password for admin to share with dentist
    ],
    'note' => 'This is Section 1 only - Additional details (personal info, schedule, etc.) not saved yet.',
    'redirect' => '../admin-ui/admin-subfolder/admin-staff-management.html'
]);

exit;
?>