<?php
/**
 * Get All Frontdesk API - FIXED VERSION
 * Retrieves all frontdesk staff records with complete information
 * Supports search, filtering, and pagination
 * 
 * FIXED: Now queries by role instead of using frontdesk_tb
 * This matches how frontdesk records are created in admin-add-frontdesk-record.php
 */

error_reporting(0);
ini_set('display_errors', 0);

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== GET ALL FRONTDESK API CLASS ===================== */
    class GetAllFrontdeskAPI {
        private $conn;
        
        public function __construct($db) {
            $this->conn = $db;
        }
        
        public function getAllFrontdesk($params = []) {
            try {
                $searchTerm = $params['search'] ?? '';
                $orderBy = $params['order_by'] ?? 'alphabetical';
                $page = isset($params['page']) ? max(1, intval($params['page'])) : null;
                $limit = isset($params['limit']) ? max(1, intval($params['limit'])) : 10;
                
                // Build base query - Query by role instead of frontdesk_tb
                // This matches how admin-add-frontdesk-record.php creates records
                $sql = "SELECT 
                    sp.staff_profile_id,
                    sp.user_id,
                    sp.first_name,
                    sp.last_name,
                    sp.birthdate,
                    sp.gender,
                    sp.address,
                    sp.phone,
                    sp.created_at,
                    u.user_code,
                    u.username,
                    u.email,
                    u.profile_picture_path,
                    u.profile_picture,
                    r.role_name
                FROM Staff_Profile_tb sp
                INNER JOIN Users_tb u ON sp.user_id = u.user_id
                INNER JOIN Roles_tb r ON sp.role_id = r.role_id
                WHERE r.role_name = 'Frontdesk'";
                
                // Add search condition
                if (!empty($searchTerm)) {
                    $sql .= " AND (
                        sp.first_name LIKE ? OR 
                        sp.last_name LIKE ? OR 
                        u.email LIKE ? OR 
                        u.user_code LIKE ? OR 
                        CONCAT(sp.first_name, ' ', sp.last_name) LIKE ?
                    )";
                }
                
                // Add ordering
                switch($orderBy) {
                    case 'newest':
                        $sql .= " ORDER BY sp.created_at DESC";
                        break;
                    case 'oldest':
                        $sql .= " ORDER BY sp.created_at ASC";
                        break;
                    case 'alphabetical':
                    default:
                        $sql .= " ORDER BY sp.last_name ASC, sp.first_name ASC";
                        break;
                }
                
                // Add pagination if requested
                if ($page !== null) {
                    $offset = ($page - 1) * $limit;
                    $sql .= " LIMIT ? OFFSET ?";
                }
                
                // Prepare and execute
                $stmt = $this->conn->prepare($sql);
                
                if (!empty($searchTerm)) {
                    $searchParam = "%{$searchTerm}%";
                    if ($page !== null) {
                        $stmt->bind_param("sssssii", 
                            $searchParam, $searchParam, $searchParam, $searchParam, $searchParam,
                            $limit, $offset
                        );
                    } else {
                        $stmt->bind_param("sssss", 
                            $searchParam, $searchParam, $searchParam, $searchParam, $searchParam
                        );
                    }
                } else {
                    if ($page !== null) {
                        $stmt->bind_param("ii", $limit, $offset);
                    }
                }
                
                $stmt->execute();
                $result = $stmt->get_result();
                
                $frontdeskStaff = [];
                while ($row = $result->fetch_assoc()) {
                    // Get schedule for each staff member
                    $schedule = $this->getStaffSchedule($row['staff_profile_id']);
                    $frontdeskStaff[] = $this->formatFrontdeskData($row, $schedule);
                }
                
                $stmt->close();
                
                // Get total count for pagination
                $totalCount = $this->getTotalCount($searchTerm);
                
                // Build response
                $response = [
                    'success' => true,
                    'message' => 'Frontdesk staff retrieved successfully',
                    'data' => $frontdeskStaff,
                    'count' => count($frontdeskStaff),
                    'total_count' => $totalCount
                ];
                
                // Add pagination info
                if ($page !== null) {
                    $response['pagination'] = [
                        'current_page' => $page,
                        'total_pages' => ceil($totalCount / $limit),
                        'limit' => $limit,
                        'total_records' => $totalCount
                    ];
                }
                
                // Add search/filter info
                if (!empty($searchTerm)) {
                    $response['search_term'] = $searchTerm;
                }
                $response['order_by'] = $orderBy;
                
                return $response;
                
            } catch (Exception $e) {
                throw new Exception("Failed to retrieve frontdesk staff: " . $e->getMessage());
            }
        }
        
        private function getStaffSchedule($staffProfileId) {
            $sql = "SELECT 
                day_of_week,
                start_time,
                end_time,
                is_working
            FROM Staff_Base_Schedule_tb
            WHERE staff_profile_id = ?
            ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("i", $staffProfileId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $schedule = [];
            while ($row = $result->fetch_assoc()) {
                $schedule[] = [
                    'day' => $row['day_of_week'],
                    'start_time' => $row['start_time'],
                    'end_time' => $row['end_time'],
                    'is_working' => (bool)$row['is_working']
                ];
            }
            
            $stmt->close();
            return $schedule;
        }
        
        private function getTotalCount($searchTerm = '') {
            // Updated to query by role instead of frontdesk_tb
            $sql = "SELECT COUNT(*) as total 
                    FROM Staff_Profile_tb sp
                    INNER JOIN Users_tb u ON sp.user_id = u.user_id
                    INNER JOIN Roles_tb r ON sp.role_id = r.role_id
                    WHERE r.role_name = 'Frontdesk'";
            
            if (!empty($searchTerm)) {
                $sql .= " AND (
                    sp.first_name LIKE ? OR 
                    sp.last_name LIKE ? OR 
                    u.email LIKE ? OR 
                    u.user_code LIKE ? OR 
                    CONCAT(sp.first_name, ' ', sp.last_name) LIKE ?
                )";
            }
            
            $stmt = $this->conn->prepare($sql);
            
            if (!empty($searchTerm)) {
                $searchParam = "%{$searchTerm}%";
                $stmt->bind_param("sssss", 
                    $searchParam, $searchParam, $searchParam, $searchParam, $searchParam
                );
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();
            
            return $row['total'];
        }
        
        private function formatFrontdeskData($row, $schedule = []) {
            // Handle profile picture
            $profilePicture = null;
            if (!empty($row['profile_picture_path'])) {
                // Check if it's a special flag
                if ($row['profile_picture_path'] === 'generated_default' || 
                    $row['profile_picture_path'] === 'custom_upload') {
                    // Use blob data
                    if (!empty($row['profile_picture'])) {
                        $profilePicture = 'data:image/png;base64,' . base64_encode($row['profile_picture']);
                    }
                } else {
                    // Use file path
                    $profilePicture = $row['profile_picture_path'];
                }
            } elseif (!empty($row['profile_picture'])) {
                $profilePicture = 'data:image/png;base64,' . base64_encode($row['profile_picture']);
            }
            
            // Generate frontdesk code from user_code
            $frontdeskCode = !empty($row['user_code']) ? $row['user_code'] : 'F-' . str_pad($row['staff_profile_id'], 4, '0', STR_PAD_LEFT);
            
            // Extract shift from schedule (MORNING/AFTERNOON/EVENING based on start time)
            $shift = null;
            if (!empty($schedule)) {
                $firstWorkingDay = array_filter($schedule, fn($s) => $s['is_working']);
                if (!empty($firstWorkingDay)) {
                    $firstDay = reset($firstWorkingDay);
                    $startHour = (int)substr($firstDay['start_time'], 0, 2);
                    
                    if ($startHour < 12) {
                        $shift = 'MORNING';
                    } elseif ($startHour < 17) {
                        $shift = 'AFTERNOON';
                    } else {
                        $shift = 'EVENING';
                    }
                }
            }
            
            return [
                'staff_profile_id' => $row['staff_profile_id'],
                'frontdesk_code' => $frontdeskCode,
                'user_id' => $row['user_id'],
                'personal_info' => [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'full_name' => $row['first_name'] . ' ' . $row['last_name'],
                    'birthdate' => $row['birthdate'],
                    'gender' => $row['gender'],
                    'address' => $row['address'],
                    'phone' => $row['phone'],
                    'email' => $row['email']
                ],
                'work_info' => [
                    'shift' => $shift, // Derived from schedule
                    'schedule' => $schedule
                ],
                'profile_picture' => $profilePicture,
                'username' => $row['username'],
                'role_name' => $row['role_name'],
                'created_at' => $row['created_at']
            ];
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $params = [
            'search' => $_GET['search'] ?? '',
            'order_by' => $_GET['order_by'] ?? 'alphabetical',
            'page' => $_GET['page'] ?? null,
            'limit' => $_GET['limit'] ?? 10
        ];
        
        $api = new GetAllFrontdeskAPI($conn);
        $result = $api->getAllFrontdesk($params);
        
        echo json_encode($result);
        
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

exit;
?>