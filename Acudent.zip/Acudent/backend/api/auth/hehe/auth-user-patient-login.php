<?php
header("Content-Type: application/json");
session_start();

$dbPath = __DIR__ . '/../../connection-db.php';
if (!file_exists($dbPath)) {
    echo json_encode(["success" => false, "message" => "Server error: DB connection missing."]);
    exit;
}
require_once $dbPath;

// Read JSON input
$data = json_decode(file_get_contents("php://input"), true);

$username = trim($data['username'] ?? '');
$password = trim($data['password'] ?? '');

if ($username === '' || $password === '') {
    echo json_encode(["success" => false, "message" => "Both username and password are required."]);
    exit;
}

$query = "SELECT 
            u.user_id, 
            u.username, 
            u.password_hash, 
            u.first_name, 
            u.last_name, 
            r.role_name
          FROM Users_tb u
          INNER JOIN Roles_tb r ON u.role_id = r.role_id
          WHERE u.username = ?
          LIMIT 1";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo json_encode(["success" => false, "message" => "Invalid login credentials."]);
    exit;
}

$user = $result->fetch_assoc();

// ❌ Reject if not a Patient
if (strtolower($user['role_name']) !== "patient") {
    echo json_encode(["success" => false, "message" => "This login is for patients only."]);
    exit;
}

// ❌ Wrong password
if (!password_verify($password, $user['password_hash'])) {
    echo json_encode(["success" => false, "message" => "Incorrect password."]);
    exit;
}

// ✅ Store session for patient
$_SESSION['patient'] = [
    'user_id'     => $user['user_id'],
    'username'    => $user['username'],
    'first_name'  => $user['first_name'],
    'last_name'   => $user['last_name'],
    'role'        => "Patient"
];

echo json_encode([
    "success" => true,
    "role" => "Patient",
    "redirect" => "../patient-ui/patient-main.php"
]);
exit;




header("Content-Type: application/json");
session_start();

$dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
if (!file_exists($dbPath)) {
    echo json_encode(["success" => false, "message" => "Server error: DB connection missing."]);
    exit;
}

require_once $dbPath;  // Include the DB connection

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$username = trim($input['username'] ?? '');
$password = trim($input['password'] ?? '');

if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Username and password are required']);
    exit;
}

// Secure query with prepared statement (recommended over direct string)
$query = "SELECT user_id, username, password_hash, role_id FROM Users_tb WHERE username = ? LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo json_encode(['success' => false, 'message' => 'Invalid login credentials']);
    exit;
}

$user = $result->fetch_assoc();

// Password verification (assuming password_hash is hashed; use password_verify)
if (!password_verify($password, $user['password_hash'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid login credentials']);
    exit;
}

// Create session
$_SESSION['user_id'] = $user['user_id'];
$_SESSION['username'] = $user['username'];
$_SESSION['role_id'] = $user['role_id'];

// Determine redirect based on role_id
$redirect = "../user-interface/index.php";  // Default fallback
switch ($user['role_id']) {
    case 1: $redirect = "../admin-ui/admin-main.php"; break;
    case 2: $redirect = "../dentist-ui/dentist-main.php"; break;
    case 3: $redirect = "../frontdesk-ui/frontdesk-main.php"; break;
    case 4: $redirect = "../assistant-ui/assistant-main.php"; break;
    case 5: $redirect = "../patient-ui/patient-dashboard.php"; break;
}

echo json_encode(['success' => true, 'redirect' => $redirect]);
exit;
?>

