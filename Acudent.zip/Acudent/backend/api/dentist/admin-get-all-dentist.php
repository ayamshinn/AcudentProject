<?php
/**
 * Get All Dentists API
 * Retrieves all dentist records with complete information
 * Supports search, filtering, and pagination
 */

error_reporting(0);
ini_set('display_errors', 0);

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== GET ALL DENTISTS API CLASS ===================== */
    class GetAllDentistsAPI {
        private $conn;
        
        public function __construct($db) {
            $this->conn = $db;
        }
        
        public function getAllDentists($params = []) {
            try {
                $searchTerm = $params['search'] ?? '';
                $orderBy = $params['order_by'] ?? 'alphabetical';
                $page = isset($params['page']) ? max(1, intval($params['page'])) : null;
                $limit = isset($params['limit']) ? max(1, intval($params['limit'])) : 10;
                
                // Build base query
                $sql = "SELECT 
                    d.dentist_id,
                    d.staff_profile_id,
                    d.specialization,
                    d.license_number,
                    d.education,
                    d.notes,
                    d.position,
                    d.start_date,
                    d.linkedin_url,
                    d.facebook_url,
                    d.instagram_url,
                    d.tiktok_url,
                    d.youtube_url,
                    d.professional_photo_path,
                    d.professional_photo,
                    sp.user_id,
                    sp.first_name,
                    sp.last_name,
                    sp.birthdate,
                    sp.gender,
                    sp.address,
                    sp.phone,
                    sp.created_at,
                    u.user_code,
                    u.username,
                    u.email,
                    u.profile_picture_path,
                    u.profile_picture,
                    r.role_name
                FROM Dentists_tb d
                INNER JOIN Staff_Profile_tb sp ON d.staff_profile_id = sp.staff_profile_id
                INNER JOIN Users_tb u ON sp.user_id = u.user_id
                INNER JOIN Roles_tb r ON sp.role_id = r.role_id";
                
                // Add search condition
                $whereAdded = false;
                if (!empty($searchTerm)) {
                    $sql .= " WHERE (
                        sp.first_name LIKE ? OR 
                        sp.last_name LIKE ? OR 
                        u.email LIKE ? OR 
                        u.user_code LIKE ? OR 
                        CONCAT(sp.first_name, ' ', sp.last_name) LIKE ?
                    )";
                    $whereAdded = true;
                }
                
                // Add ordering
                switch($orderBy) {
                    case 'newest':
                        $sql .= " ORDER BY sp.created_at DESC";
                        break;
                    case 'oldest':
                        $sql .= " ORDER BY sp.created_at ASC";
                        break;
                    case 'alphabetical':
                    default:
                        $sql .= " ORDER BY sp.last_name ASC, sp.first_name ASC";
                        break;
                }
                
                // Add pagination if requested
                if ($page !== null) {
                    $offset = ($page - 1) * $limit;
                    $sql .= " LIMIT ? OFFSET ?";
                }
                
                // Prepare and execute
                $stmt = $this->conn->prepare($sql);
                
                if (!empty($searchTerm)) {
                    $searchParam = "%{$searchTerm}%";
                    if ($page !== null) {
                        $stmt->bind_param("sssssii", 
                            $searchParam, $searchParam, $searchParam, $searchParam, $searchParam,
                            $limit, $offset
                        );
                    } else {
                        $stmt->bind_param("sssss", 
                            $searchParam, $searchParam, $searchParam, $searchParam, $searchParam
                        );
                    }
                } else {
                    if ($page !== null) {
                        $stmt->bind_param("ii", $limit, $offset);
                    }
                }
                
                $stmt->execute();
                $result = $stmt->get_result();
                
                $dentists = [];
                while ($row = $result->fetch_assoc()) {
                    $dentists[] = $this->formatDentistData($row);
                }
                
                $stmt->close();
                
                // Get total count for pagination
                $totalCount = $this->getTotalCount($searchTerm);
                
                // Build response
                $response = [
                    'success' => true,
                    'message' => 'Dentists retrieved successfully',
                    'data' => $dentists,
                    'count' => count($dentists),
                    'total_count' => $totalCount
                ];
                
                // Add pagination info
                if ($page !== null) {
                    $response['pagination'] = [
                        'current_page' => $page,
                        'total_pages' => ceil($totalCount / $limit),
                        'limit' => $limit,
                        'total_records' => $totalCount
                    ];
                }
                
                // Add search/filter info
                if (!empty($searchTerm)) {
                    $response['search_term'] = $searchTerm;
                }
                $response['order_by'] = $orderBy;
                
                return $response;
                
            } catch (Exception $e) {
                throw new Exception("Failed to retrieve dentists: " . $e->getMessage());
            }
        }
        
        private function getTotalCount($searchTerm = '') {
            $sql = "SELECT COUNT(*) as total 
                    FROM Dentists_tb d
                    INNER JOIN Staff_Profile_tb sp ON d.staff_profile_id = sp.staff_profile_id
                    INNER JOIN Users_tb u ON sp.user_id = u.user_id";
            
            if (!empty($searchTerm)) {
                $sql .= " WHERE (
                    sp.first_name LIKE ? OR 
                    sp.last_name LIKE ? OR 
                    u.email LIKE ? OR 
                    u.user_code LIKE ? OR 
                    CONCAT(sp.first_name, ' ', sp.last_name) LIKE ?
                )";
            }
            
            $stmt = $this->conn->prepare($sql);
            
            if (!empty($searchTerm)) {
                $searchParam = "%{$searchTerm}%";
                $stmt->bind_param("sssss", 
                    $searchParam, $searchParam, $searchParam, $searchParam, $searchParam
                );
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();
            
            return $row['total'];
        }
        
        private function formatDentistData($row) {
            // Handle profile picture
            $profilePicture = null;
            if (!empty($row['professional_photo_path'])) {
                $profilePicture = $row['professional_photo_path'];
            } elseif (!empty($row['profile_picture_path'])) {
                $profilePicture = $row['profile_picture_path'];
            } elseif (!empty($row['professional_photo'])) {
                $profilePicture = 'data:image/jpeg;base64,' . base64_encode($row['professional_photo']);
            } elseif (!empty($row['profile_picture'])) {
                $profilePicture = 'data:image/jpeg;base64,' . base64_encode($row['profile_picture']);
            }
            
            // Generate dentist code
            $dentistCode = !empty($row['user_code']) ? $row['user_code'] : 'D-' . str_pad($row['dentist_id'], 4, '0', STR_PAD_LEFT);
            
            return [
                'dentist_id' => $row['dentist_id'],
                'dentist_code' => $dentistCode,
                'staff_profile_id' => $row['staff_profile_id'],
                'user_id' => $row['user_id'],
                'personal_info' => [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'full_name' => $row['first_name'] . ' ' . $row['last_name'],
                    'birthdate' => $row['birthdate'],
                    'gender' => $row['gender'],
                    'address' => $row['address'],
                    'phone' => $row['phone'],
                    'email' => $row['email']
                ],
                'professional_info' => [
                    'specialization' => $row['specialization'],
                    'license_number' => $row['license_number'],
                    'position' => $row['position'],
                    'education' => $row['education'],
                    'start_date' => $row['start_date'],
                    'notes' => $row['notes']
                ],
                'social_media' => [
                    'linkedin' => $row['linkedin_url'],
                    'facebook' => $row['facebook_url'],
                    'instagram' => $row['instagram_url'],
                    'tiktok' => $row['tiktok_url'],
                    'youtube' => $row['youtube_url']
                ],
                'profile_picture' => $profilePicture,
                'username' => $row['username'],
                'role_name' => $row['role_name'],
                'created_at' => $row['created_at']
            ];
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $params = [
            'search' => $_GET['search'] ?? '',
            'order_by' => $_GET['order_by'] ?? 'alphabetical',
            'page' => $_GET['page'] ?? null,
            'limit' => $_GET['limit'] ?? 10
        ];
        
        $api = new GetAllDentistsAPI($conn);
        $result = $api->getAllDentists($params);
        
        echo json_encode($result);
        
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

exit;
?>