<?php
/**
 * Add Dentist Record API
 * Creates dentist professional records for existing user accounts
 */

// Suppress errors from breaking JSON output
error_reporting(0);
ini_set('display_errors', 0);

// Set JSON headers
header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== DENTIST RECORD API CLASS ===================== */
    class DentistRecordAPI {
        private $conn;
        
        public function __construct($db) {
            $this->conn = $db;
        }
        
        public function addDentistRecord($data) {
            try {
                $this->conn->begin_transaction();
                
                // Validate required fields
                $this->validateDentistInfo($data);
                
                // Verify user exists and get user info
                $userData = $this->getUserData($data['user_id']);
                
                // Get dentist role ID
                $roleId = $this->getDentistRoleId();
                
                // Check if staff profile exists
                $staffProfileId = $this->getOrCreateStaffProfile(
                    $data['user_id'],
                    $roleId,
                    $userData,
                    $data
                );
                
                // Create dentist record
                $dentistId = $this->createDentistRecord($staffProfileId, $data);
                
                $this->conn->commit();
                
                return [
                    'success' => true,
                    'message' => 'Dentist record created successfully',
                    'data' => [
                        'user_id' => $data['user_id'],
                        'staff_profile_id' => $staffProfileId,
                        'dentist_id' => $dentistId
                    ]
                ];
                
            } catch (Exception $e) {
                $this->conn->rollback();
                return [
                    'success' => false,
                    'message' => $e->getMessage()
                ];
            }
        }
        
        private function validateDentistInfo($data) {
            // Check user_id
            if (empty($data['user_id'])) {
                throw new Exception("User ID is required");
            }
            
            // Required professional fields
            $required = [
                'licenseNumber' => 'License number',
                'specialization' => 'Specialization',
                'education' => 'Education'
            ];
            
            foreach ($required as $field => $label) {
                if (empty(trim($data[$field] ?? ''))) {
                    throw new Exception("$label is required");
                }
            }
            
            // Check if user already has a dentist record
            $stmt = $this->conn->prepare("
                SELECT d.dentist_id 
                FROM Dentists_tb d
                INNER JOIN Staff_Profile_tb sp ON d.staff_profile_id = sp.staff_profile_id
                WHERE sp.user_id = ? 
                LIMIT 1
            ");
            $stmt->bind_param("i", $data['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                throw new Exception("This user already has a dentist record");
            }
            $stmt->close();
            
            // Check if license number already exists
            $stmt = $this->conn->prepare("SELECT dentist_id FROM Dentists_tb WHERE license_number = ? LIMIT 1");
            $stmt->bind_param("s", $data['licenseNumber']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                throw new Exception("License number already exists");
            }
            $stmt->close();
            
            // Optional: Validate personal info if provided
            if (!empty($data['phone']) && !preg_match('/^\+?[0-9\s\-()]+$/', $data['phone'])) {
                throw new Exception("Invalid phone number format");
            }
            
            // Validate email if provided
            if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Invalid email format");
            }
        }
        
        private function getUserData($userId) {
            $stmt = $this->conn->prepare("
                SELECT user_id, first_name, last_name, email 
                FROM Users_tb 
                WHERE user_id = ? LIMIT 1
            ");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception("User account not found");
            }
            
            $userData = $result->fetch_assoc();
            $stmt->close();
            return $userData;
        }
        
        private function getDentistRoleId() {
            $stmt = $this->conn->prepare("SELECT role_id FROM Roles_tb WHERE role_name = 'Dentist' LIMIT 1");
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception("Dentist role not found in system");
            }
            
            $row = $result->fetch_assoc();
            $stmt->close();
            return $row['role_id'];
        }
        
        private function getOrCreateStaffProfile($userId, $roleId, $userData, $data) {
            // Check if staff profile already exists
            $stmt = $this->conn->prepare("
                SELECT staff_profile_id 
                FROM Staff_Profile_tb 
                WHERE user_id = ? LIMIT 1
            ");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $staffProfileId = $row['staff_profile_id'];
                $stmt->close();
                
                // Update existing staff profile with new data if provided
                $this->updateStaffProfile($staffProfileId, $userData, $data);
                return $staffProfileId;
            }
            $stmt->close();
            
            // Create new staff profile if it doesn't exist
            return $this->createStaffProfile($userId, $roleId, $userData, $data);
        }
        
        private function updateStaffProfile($staffProfileId, $userData, $data) {
            // Only update fields that are provided
            $updateFields = [];
            $params = [];
            $types = '';
            
            if (!empty($data['firstName'])) {
                $updateFields[] = "first_name = ?";
                $params[] = $data['firstName'];
                $types .= 's';
            }
            
            if (!empty($data['lastName'])) {
                $updateFields[] = "last_name = ?";
                $params[] = $data['lastName'];
                $types .= 's';
            }
            
            if (!empty($data['dateOfBirth'])) {
                $updateFields[] = "birthdate = ?";
                $params[] = $data['dateOfBirth'];
                $types .= 's';
            }
            
            if (!empty($data['gender'])) {
                $updateFields[] = "gender = ?";
                $params[] = $data['gender'];
                $types .= 's';
            }
            
            if (!empty($data['address'])) {
                $updateFields[] = "address = ?";
                $params[] = $data['address'];
                $types .= 's';
            }
            
            if (!empty($data['phone'])) {
                $updateFields[] = "phone = ?";
                $params[] = $data['phone'];
                $types .= 's';
            }
            
            // Only update if there are fields to update
            if (!empty($updateFields)) {
                $updateFields[] = "updated_at = NOW()";
                $params[] = $staffProfileId;
                $types .= 'i';
                
                $sql = "UPDATE Staff_Profile_tb SET " . implode(', ', $updateFields) . " WHERE staff_profile_id = ?";
                $stmt = $this->conn->prepare($sql);
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $stmt->close();
            }
        }
        
        private function createStaffProfile($userId, $roleId, $userData, $data) {
            $stmt = $this->conn->prepare("
                INSERT INTO Staff_Profile_tb (
                    user_id, role_id, first_name, last_name, 
                    birthdate, gender, address, phone, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            // Use provided data or fallback to user data
            $firstName = $data['firstName'] ?? $userData['first_name'];
            $lastName = $data['lastName'] ?? $userData['last_name'];
            $birthdate = $data['dateOfBirth'] ?? null;
            $gender = $data['gender'] ?? null;
            $address = $data['address'] ?? null;
            $phone = $data['phone'] ?? null;
            
            $stmt->bind_param(
                "iissssss",
                $userId,
                $roleId,
                $firstName,
                $lastName,
                $birthdate,
                $gender,
                $address,
                $phone
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create staff profile: " . $stmt->error);
            }
            
            $staffProfileId = $this->conn->insert_id;
            $stmt->close();
            return $staffProfileId;
        }
        
        private function createDentistRecord($staffProfileId, $data) {
            $stmt = $this->conn->prepare("
                INSERT INTO Dentists_tb (
                    staff_profile_id, license_number, specialization, 
                    education, notes, linkedin_url, facebook_url, 
                    instagram_url, tiktok_url, youtube_url
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            // Clean up empty strings to null
            $notes = !empty($data['notes']) ? $data['notes'] : null;
            $linkedin = !empty($data['linkedin']) ? $data['linkedin'] : null;
            $facebook = !empty($data['facebook']) ? $data['facebook'] : null;
            $instagram = !empty($data['instagram']) ? $data['instagram'] : null;
            $tiktok = !empty($data['tiktok']) ? $data['tiktok'] : null;
            $youtube = !empty($data['youtube']) ? $data['youtube'] : null;
            
            $stmt->bind_param(
                "isssssssss",
                $staffProfileId,
                $data['licenseNumber'],
                $data['specialization'],
                $data['education'],
                $notes,
                $linkedin,
                $facebook,
                $instagram,
                $tiktok,
                $youtube
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create dentist record: " . $stmt->error);
            }
            
            $dentistId = $this->conn->insert_id;
            $stmt->close();
            return $dentistId;
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid JSON data'
            ]);
            exit;
        }
        
        $api = new DentistRecordAPI($conn);
        $result = $api->addDentistRecord($input);
        
        echo json_encode($result);
        
    } else {
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'message' => 'Method not allowed'
        ]);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

exit;
?>