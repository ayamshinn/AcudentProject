<?php
/**
 * Add Dentist Record API
 * Creates dentist professional records for existing user accounts
 * Supports professional photo upload for landing page display
 */

error_reporting(0);
ini_set('display_errors', 0);

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== DENTIST RECORD API CLASS ===================== */
    class DentistRecordAPI {
        private $conn;
        
        public function __construct($db) {
            $this->conn = $db;
        }
        
        public function addDentistRecord($data) {
            try {
                $this->conn->begin_transaction();
                
                $this->validateDentistInfo($data);
                $userData = $this->getUserData($data['user_id']);
                $roleId = $this->getDentistRoleId();
                
                $staffProfileId = $this->getOrCreateStaffProfile(
                    $data['user_id'],
                    $roleId,
                    $userData,
                    $data
                );
                
                $dentistId = $this->createDentistRecord($staffProfileId, $data);
                
                // Create work schedule if provided
                if (!empty($data['workingDays']) && is_array($data['workingDays'])) {
                    $this->createWorkSchedule($staffProfileId, $data);
                }
                
                $this->conn->commit();
                
                return [
                    'success' => true,
                    'message' => 'Dentist record created successfully',
                    'data' => [
                        'user_id' => $data['user_id'],
                        'staff_profile_id' => $staffProfileId,
                        'dentist_id' => $dentistId
                    ]
                ];
                
            } catch (Exception $e) {
                $this->conn->rollback();
                return [
                    'success' => false,
                    'message' => $e->getMessage()
                ];
            }
        }
        
        private function validateDentistInfo($data) {
            if (empty($data['user_id'])) {
                throw new Exception("User ID is required");
            }
            
            // Required fields
            $required = [
                'licenseNumber' => 'License number',
                'specialization' => 'Specialization',
                'education' => 'Education',
                'firstName' => 'First name',
                'lastName' => 'Last name',
                'dateOfBirth' => 'Date of birth',
                'gender' => 'Gender'
            ];
            
            foreach ($required as $field => $label) {
                if (empty($data[$field] ?? '')) {
                    throw new Exception("$label is required");
                }
            }
            
            $stmt = $this->conn->prepare("
                SELECT d.dentist_id 
                FROM Dentists_tb d
                INNER JOIN Staff_Profile_tb sp ON d.staff_profile_id = sp.staff_profile_id
                WHERE sp.user_id = ? 
                LIMIT 1
            ");
            $stmt->bind_param("i", $data['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                throw new Exception("This user already has a dentist record");
            }
            $stmt->close();
            
            $stmt = $this->conn->prepare("SELECT dentist_id FROM Dentists_tb WHERE license_number = ? LIMIT 1");
            $stmt->bind_param("s", $data['licenseNumber']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                throw new Exception("License number already exists");
            }
            $stmt->close();
            
            if (!empty($data['phone']) && !preg_match('/^\+?[0-9\s\-()]+$/', $data['phone'])) {
                throw new Exception("Invalid phone number format");
            }
            
            if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Invalid email format");
            }
        }
        
        private function getUserData($userId) {
            $stmt = $this->conn->prepare("
                SELECT user_id, first_name, last_name, email 
                FROM Users_tb 
                WHERE user_id = ? LIMIT 1
            ");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception("User account not found");
            }
            
            $userData = $result->fetch_assoc();
            $stmt->close();
            return $userData;
        }
        
        private function getDentistRoleId() {
            $stmt = $this->conn->prepare("SELECT role_id FROM Roles_tb WHERE role_name = 'Dentist' LIMIT 1");
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception("Dentist role not found in system");
            }
            
            $row = $result->fetch_assoc();
            $stmt->close();
            return $row['role_id'];
        }
        
        private function getOrCreateStaffProfile($userId, $roleId, $userData, $data) {
            $stmt = $this->conn->prepare("
                SELECT staff_profile_id 
                FROM Staff_Profile_tb 
                WHERE user_id = ? LIMIT 1
            ");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $staffProfileId = $row['staff_profile_id'];
                $stmt->close();
                
                $this->updateStaffProfile($staffProfileId, $data);
                return $staffProfileId;
            }
            $stmt->close();
            
            return $this->createStaffProfile($userId, $roleId, $data);
        }
        
        private function updateStaffProfile($staffProfileId, $data) {
            $updateFields = [];
            $params = [];
            $types = '';
            
            if (!empty($data['firstName'])) {
                $updateFields[] = "first_name = ?";
                $params[] = $data['firstName'];
                $types .= 's';
            }
            
            if (!empty($data['lastName'])) {
                $updateFields[] = "last_name = ?";
                $params[] = $data['lastName'];
                $types .= 's';
            }
            
            if (!empty($data['dateOfBirth'])) {
                $updateFields[] = "birthdate = ?";
                $params[] = $data['dateOfBirth'];
                $types .= 's';
            }
            
            if (!empty($data['gender'])) {
                $updateFields[] = "gender = ?";
                $params[] = $data['gender'];
                $types .= 's';
            }
            
            if (!empty($data['address'])) {
                $updateFields[] = "address = ?";
                $params[] = $data['address'];
                $types .= 's';
            }
            
            if (!empty($data['phone'])) {
                $updateFields[] = "phone = ?";
                $params[] = $data['phone'];
                $types .= 's';
            }
            
            if (!empty($updateFields)) {
                $params[] = $staffProfileId;
                $types .= 'i';
                
                $sql = "UPDATE Staff_Profile_tb SET " . implode(', ', $updateFields) . " WHERE staff_profile_id = ?";
                $stmt = $this->conn->prepare($sql);
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $stmt->close();
            }
        }
        
        private function createStaffProfile($userId, $roleId, $data) {
            $stmt = $this->conn->prepare("
                INSERT INTO Staff_Profile_tb (
                    user_id, role_id, first_name, last_name, 
                    birthdate, gender, address, phone, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $firstName = $data['firstName'];
            $lastName = $data['lastName'];
            $birthdate = $data['dateOfBirth'];
            $gender = $data['gender'];
            $address = $data['address'] ?? '';
            $phone = $data['phone'] ?? '';
            
            $stmt->bind_param(
                "iissssss",
                $userId,
                $roleId,
                $firstName,
                $lastName,
                $birthdate,
                $gender,
                $address,
                $phone
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create staff profile: " . $stmt->error);
            }
            
            $staffProfileId = $this->conn->insert_id;
            $stmt->close();
            return $staffProfileId;
        }
        
        private function createDentistRecord($staffProfileId, $data) {
            /* ===================== HANDLE PROFESSIONAL PHOTO UPLOAD (LANDING PAGE) ===================== */
            $professionalPhotoPath = null;
            $professionalPhotoBlob = null;

            if (isset($_FILES['professional_photo']) && $_FILES['professional_photo']['error'] === UPLOAD_ERR_OK) {
                $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
                $file = $_FILES['professional_photo'];
                
                if (in_array($file['type'], $allowedTypes) && $file['size'] <= 5242880) { // 5MB max
                    // Store as blob
                    $professionalPhotoBlob = file_get_contents($file['tmp_name']);
                    
                    // Save to filesystem
                    $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/uploads/profiles/dentists/';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0777, true);
                    }
                    
                    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $filename = uniqid('dentist_prof_') . '_' . time() . '.' . $fileExtension;
                    $fullPath = $uploadDir . $filename;
                    
                    if (move_uploaded_file($file['tmp_name'], $fullPath)) {
                        $professionalPhotoPath = '/Acudent/uploads/profiles/dentists/' . $filename;
                    }
                }
            }

            $stmt = $this->conn->prepare("
                INSERT INTO Dentists_tb (
                    staff_profile_id, license_number, specialization, 
                    education, notes, position, start_date,
                    linkedin_url, facebook_url, instagram_url, 
                    tiktok_url, youtube_url,
                    professional_photo_path, professional_photo
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $notes = !empty($data['notes']) ? $data['notes'] : null;
            $position = !empty($data['position']) ? $data['position'] : null;
            $startDate = !empty($data['startDate']) ? $data['startDate'] : null;
            $linkedin = !empty($data['linkedin']) ? $data['linkedin'] : null;
            $facebook = !empty($data['facebook']) ? $data['facebook'] : null;
            $instagram = !empty($data['instagram']) ? $data['instagram'] : null;
            $tiktok = !empty($data['tiktok']) ? $data['tiktok'] : null;
            $youtube = !empty($data['youtube']) ? $data['youtube'] : null;
            
            $stmt->bind_param(
                "isssssssssssss",
                $staffProfileId,
                $data['licenseNumber'],
                $data['specialization'],
                $data['education'],
                $notes,
                $position,
                $startDate,
                $linkedin,
                $facebook,
                $instagram,
                $tiktok,
                $youtube,
                $professionalPhotoPath,
                $professionalPhotoBlob
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create dentist record: " . $stmt->error);
            }
            
            $dentistId = $this->conn->insert_id;
            $stmt->close();
            return $dentistId;
        }
        
        private function createWorkSchedule($staffProfileId, $data) {
            // Map frontend day names to database enum values
            $dayMapping = [
                'Monday' => 'Mon',
                'Tuesday' => 'Tue',
                'Wednesday' => 'Wed',
                'Thursday' => 'Thu',
                'Friday' => 'Fri',
                'Saturday' => 'Sat',
                'Sunday' => 'Sun'
            ];
            
            // Default times if not provided
            $startTime = !empty($data['startTime']) ? $data['startTime'] : '09:00:00';
            $endTime = !empty($data['endTime']) ? $data['endTime'] : '17:00:00';
            
            // Add seconds if not present (HH:MM -> HH:MM:SS)
            if (strlen($startTime) === 5) {
                $startTime .= ':00';
            }
            if (strlen($endTime) === 5) {
                $endTime .= ':00';
            }
            
            // Delete existing schedule for this staff member (for idempotency)
            $deleteStmt = $this->conn->prepare("DELETE FROM Staff_Base_Schedule_tb WHERE staff_profile_id = ?");
            $deleteStmt->bind_param("i", $staffProfileId);
            $deleteStmt->execute();
            $deleteStmt->close();
            
            // Insert schedule for selected working days
            $stmt = $this->conn->prepare("
                INSERT INTO Staff_Base_Schedule_tb 
                (staff_profile_id, day_of_week, start_time, end_time, is_working) 
                VALUES (?, ?, ?, ?, 1)
            ");
            
            foreach ($data['workingDays'] as $day) {
                if (isset($dayMapping[$day])) {
                    $dbDay = $dayMapping[$day];
                    $stmt->bind_param("isss", $staffProfileId, $dbDay, $startTime, $endTime);
                    
                    if (!$stmt->execute()) {
                        throw new Exception("Failed to create schedule for $day: " . $stmt->error);
                    }
                }
            }
            
            $stmt->close();
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Check if this is multipart/form-data or JSON
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        $isMultipart = strpos($contentType, 'multipart/form-data') !== false;

        if ($isMultipart) {
            // FormData with file upload - convert $_POST to array
            $data = [];
            foreach ($_POST as $key => $value) {
                // Handle JSON stringified arrays (like workingDays)
                if ($key === 'workingDays') {
                    $data[$key] = json_decode($value, true);
                } else {
                    $data[$key] = $value;
                }
            }
        } else {
            // JSON data
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
                exit;
            }
        }
        
        $api = new DentistRecordAPI($conn);
        $result = $api->addDentistRecord($data);
        
        echo json_encode($result);
        
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

exit;
?>