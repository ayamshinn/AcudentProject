<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAPRU - About</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../assets/css/user-interface/about.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/navbar.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');
    </style>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
    </style>

</head>

<body>

    <div class="main-container overflow-hidden">

        <?php include '../user-interface/navbar.php'; ?>


        <div class="landing-page-content-main-container">
            <!----------Landing Page --------------->

            <!-- ================= Section 1  ====================== -->


            <section class="section1 d-flex flex-column justify-content-center align-items-center">

                <div class="dentists-hero-banner w-100 ">
                    <div
                        class="dentists-hero-banner-inner d-flex flex-column justify-content-center align-items-center">
                        <div class="dentists-hero-banner-title">
                            <h1>Know More About Us</h1>
                        </div>
                        <hr class="hori-line">
                        <div
                            class="dentists-hero-banner-sub mt-4 d-flex flex-row w-100 justify-content-center align-items-center gap-3">
                            <div class="dentists-hero-banner-sub-left d-flex flex-row">
                                <h5> <a href="../user-interface/index.php"><i
                                            class="fa-solid fa-house me-2"></i>Home</a> <i
                                        class="fa-solid fa-chevron-right mx-3"></i></h5>


                            </div>
                            <div class="dentists-hero-banner-sub-right">
                                <h5>About</h5>

                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ================= Section 2  ====================== -->
            <section class="section2">
                <div class="about-us-banner-content">
                    <div class="about-us-banner-content-inner text-center">
                        <h5 class="reveal reveal-header header-1"><i class="fa-solid fa-door-open"></i> Welcome to MAPRU
                            Dental</h5>
                        <h2 class="reveal reveal-header header-2">7 Years of Caring for Confident Smiles</h2>

                        <p class="reveal reveal-header header-3">
                            Welcome to MAPRU Dental—your trusted dental clinic for the past seven years.
                            We are proud to serve our community with modern dentistry delivered in a warm,
                            comfortable, and reassuring environment from the moment you arrive.
                            <br><br>
                            Led by Dr. Maja Prudente-Reyes, our clinic is guided by continuous learning,
                            refined expertise, and a strong patient-first philosophy.
                            Each treatment is carefully planned using modern standards and proven techniques,
                            ensuring results that are not only healthy and functional, but long-lasting and confident.
                        </p>



                        <div class="about-us-banner-row reveal reveal-content">
                            <div class="about-us-banner-row-inner  ">
                                <div class="row row-cols-2 g-4">
                                    <div class="col">
                                        <div class="about-us-banner-col img-col-1 ">
                                            <div class="about-us-img-card"><img
                                                    src="../../assets/images/user-interface/banners-images-logo/mapru-aniv2.jpg"
                                                    alt=""></div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="about-us-banner-col img-col-2">
                                            <div class="about-us-img-card"><img
                                                    src="../../assets/images/user-interface/banners-images-logo/mapru10.jpg"
                                                    alt=""></div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="about-us-banner-col img-col-3">
                                            <div class="about-us-img-card"><img
                                                    src="../../assets/images/user-interface/banners-images-logo/mapru4.jpg"
                                                    alt=""></div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="about-us-banner-col img-col-4">
                                            <div class="about-us-img-card"><img
                                                    src="../../assets/images/user-interface/banners-images-logo/mapru22.jpg"
                                                    alt=""></div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>






                    </div>
                </div>
            </section>


            <!-- ================= Section 3  ====================== -->
            <div class="section3 doctor1">
                <div class="founder-header text-center pb-5">
                    <h5 class="reveal reveal-header header-1"><i class="fa-solid fa-certificate"></i> Founder</h5>
                    <h2 class="reveal reveal-header header-2">Meet the Heart of MAPRU Dental</h2>
                    <p class="reveal reveal-header header-3">
                        MAPRU Dental was founded with a vision rooted in care,
                        trust, and genuine concern for every patient.
                    </p>
                </div>
                <div class="row row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1">
                    <div class="col-xxl-5 col-xl-5 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="doctor-left-container px-5 reveal reveal-left">

                            <!-- Image with border -->
                            <div class="border-detail-left">
                                <img src="../../assets/images/user-interface/doctors/mapru23.jpg"
                                    alt="Picture of Mapru">
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-7 col-xl-7 col-lg-12 col-md-12 col-sm-12 col-1 reveal reveal-right">

                        <div class="details-container py-5">
                            <div class="details-doctor-name">
                                <div class="details-icon-doctor">

                                    <h3>Dr. Maja Prudente</h3>
                                </div>


                                <div class="details-doctor-specialization">
                                    <div class="details-icon-doctor">

                                        <h4> <i class="fa-solid fa-user-doctor"></i> Head Dentist</h4>
                                    </div>


                                    <h5>Cosmetic Dentistry Specialist</h5>
                                </div>
                                <div class="details-about-doctor py-3">
                                    <p>Dr. Maja Prudente is the Owner and Chief Dentist of MAPRU Dental Clinic in
                                        Bacoor,
                                        Cavite,
                                        and
                                        also serves as a dentist at South Imus Specialists Hospital. She earned her
                                        Doctor
                                        of
                                        Dental
                                        Medicine
                                        degree from Centro Escolar University and previously completed a Bachelor’s
                                        Degree
                                        in
                                        Nursing Education at Manila Doctors College.
                                        With years of experience in both hospital and private practice, she is
                                        dedicated to
                                        providing quality dental care with a
                                        focus on patient comfort and overall oral health.
                                        <br>
                                        <br>
                                        Beyond her academic background, Dr. Prudente has pursued specialized
                                        training in
                                        orthodontics, oral surgery, hospital dentistry,
                                        and dental sleep medicine, enhancing her ability to offer comprehensive
                                        treatments
                                        to
                                        her
                                        patients.
                                        Her commitment to continuous learning and compassionate care reflects in her
                                        work,
                                        making
                                        her a trusted professional in the dental community.
                                    </p>
                                </div>

                                <div class="doctors-social-reveal-container">
                                    <div class="doctors-social-reveal-btn">

                                        <!-- Trigger icon -->
                                        <i class="fa-solid fa-angle-right trigger-icon"></i>

                                        <!-- Hidden socials -->
                                        <div class="social-icons">
                                            <a href="https://www.instagram.com/maprudentalclinic" target="_blank">
                                                <i class="fa-brands fa-instagram"></i>
                                            </a>

                                            <a href="https://www.facebook.com/maprudentalclinic" target="_blank">
                                                <i class="fa-brands fa-facebook"></i>
                                            </a>

                                            <a href="https://www.tiktok.com/@maprudentalclinic" target="_blank">
                                                <i class="fa-brands fa-tiktok"></i>
                                            </a>

                                            <a href="https://www.linkedin.com/in/maja-prudente-232691b0/?originalSubdomain=ph"
                                                target="_blank">
                                                <i class="fa-brands fa-linkedin"></i>
                                            </a>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!-- ================= Section 4  ====================== -->
            <section class="section4 section-credentials ">
                <div class="credentials-main-container">
                    <div class="credentials-header text-center">
                        <h5 class="reveal reveal-header header-1"><i class="fa-solid fa-certificate"></i> Credentials &
                            Training</h5>
                        <h2 class="reveal reveal-header header-2">Professional Excellence You Can Trust</h2>
                        <p class="reveal reveal-header header-3">Dr. Maja Prudente-Reyes maintains the highest standards
                            through continuous education and
                            professional development.</p>
                    </div>

                    <div class="credentials-content d-flex flex-column justify-content-center align-items-center reveal reveal-content">
                        <!-- Certificates Wall Image -->
                        <div class="certificates-wall mt-3 reveal reveal-content">
                            <img src="../../assets/images/user-interface/banners-images-logo/mapru-certificate.jpg"
                                alt="Wall of Professional Certificates">
                        </div>

                        <!-- Key Highlights Below Image -->
                        <div class="credentials-highlights mt-5  w-100">
                            <div
                                class="row g-4 row-cols-xxl-4 row-cols-xl-4 row-cols-lg-2 row-cols-md-2 row-cols-sm-1 row-cols-1">
                                <div class="col credentials-highlights-col text-center reveal reveal-left">
                                    <i class="fa-solid fa-graduation-cap"></i>
                                    <h5>15+ Certifications</h5>
                                    <p>Specialized training in various dental disciplines</p>
                                </div>
                                <div class="col credentials-highlights-col text-center reveal reveal-left">
                                    <i class="fa-solid fa-chalkboard-teacher"></i>
                                    <h5>International Training</h5>
                                    <p>Learning from world-renowned dental experts</p>
                                </div>
                                <div class="col credentials-highlights-col text-center reveal reveal-right">
                                    <i class="fa-solid fa-user-md"></i>
                                    <h5>Professional Memberships</h5>
                                    <p>Active member of dental associations</p>
                                </div>
                                <div class="col credentials-highlights-col text-center reveal reveal-right">
                                    <i class="fa-solid fa-sync-alt"></i>
                                    <h5>Continuous Learning</h5>
                                    <p>Regular attendance at seminars and workshops</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ================= Section 5 ====================== -->

            <section class="section5 ">
                <div class="about-us-container">
                    <div class="about-us-container-inner ">
                        <div
                            class="row  row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1">
                            <div class="col-left col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <div class="photo-frame  reveal reveal-content reveal-left">

                                    <!-- Behind Frame -->
                                    <div class="photo-behind ">
                                        <img src="../../assets/images/user-interface/banners-images-logo/hero-banner0.jpg"
                                            class="slide">
                                        <img src="../../assets/images/user-interface/banners-images-logo/hero-banner5.jpg"
                                            class="slide">
                                    </div>

                                    <!-- Front Frame -->
                                    <div class="photo-front ">
                                        <img src="../../assets/images/user-interface/banners-images-logo/hero-banner0.jpg"
                                            class="slide">
                                        <img src="../../assets/images/user-interface/banners-images-logo/hero-banner5.jpg"
                                            class="slide">
                                    </div>


                                </div>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <div class="about-us-col-right-container ">
                                    <div class="about-us-col-right-inner">
                                        <div class="about-us-text-container">
                                            <div class="about-us-text-inner">

                                                <div class="about-us-text-title-header">
                                                    <div class="about-us-text-title-header-inner">
                                                        <h5 class="reveal reveal-header" ><i class="fa-solid fa-circle-info"></i> About Us</h5>
                                                    </div>
                                                </div>
                                                <hr class="hori-line m-0 reveal reveal-header">

                                                <div class="about-us-text-phrase-header">
                                                    <div class="about-us-text-phrase-header-inner py-3 reveal reveal-header">
                                                        <h2 >Trusted Family Dentistry in Bacoor, Cavite</h2>
                                                        <h2 >Comprehensive Care for Every Stage of Your Smile</h2>

                                                    </div>
                                                </div>
                                                <div class="about-us-text-content reveal reveal-header">
                                                    <div class="about-us-text-content-inner">
                                                        <p>
                                                            Located in Bacoor, Cavite, MAPRU Dental Clinic provides
                                                            comprehensive dental
                                                            care for individuals and families of all ages. Our clinic
                                                            offers a full range
                                                            of services—from preventive and general dentistry to
                                                            advanced treatments such
                                                            as orthodontics, root canal therapy, dental implants, and
                                                            crowns.
                                                            <br><br>
                                                            With a strong focus on patient comfort, safety, and
                                                            long-term oral health,
                                                            MAPRU Dental combines modern techniques with a friendly,
                                                            family-oriented
                                                            environment to ensure every visit is a positive experience.
                                                        </p>

                                                    </div>
                                                </div>

                                                <div
                                                    class="row row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1 py-3">
                                                    <div
                                                        class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-content">

                                                        <div class="about-us-text-incontainer-inner-left px-4 ">
                                                            <h4><i class="fa-solid fa-bullseye me-2"></i>Mission</h4>
                                                            <p>
                                                                To provide ethical, reliable, and compassionate dental
                                                                care through skilled professionals committed to patient
                                                                comfort and well-being.
                                                            </p>
                                                        </div>
                                                    </div>

                                                    <div
                                                        class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-content">
                                                        <div class="about-us-text-incontainer-right px-4 ">
                                                            <h4><i class="fa-regular fa-eye me-2"></i>Vision</h4>
                                                            <p>
                                                                To be a trusted dental clinic known for professional
                                                                excellence, modern practice, and genuine care for every
                                                                smile.
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </section>


            <!-- ================== Section 6 - Our Core Values ========================== -->
            <section class="section6">
                <div class="core-values-main-container">
                    <div class="core-values-header text-center">
                        <h5 class="reveal reveal-header " ><i class="fa-solid fa-heart-pulse"></i> What Drives Us</h5>
                        <h2 class="reveal reveal-header" >Our Core Values</h2>
                        <p class="reveal reveal-header" >At MAPRU Dental Clinic, every decision we make is guided by these fundamental principles that
                            shape how we care for our patients.</p>
                    </div>

                    <div class="core-values-content reveal reveal-content ">
                        <div
                            class="row g-4 row-cols-xxl-4 row-cols-xl-4 row-cols-lg-2 row-cols-md-2 row-cols-sm-1 row-cols-1">

                            <div class="col">
                                <div class="value-card">
                                    <div class="value-icon">
                                        <i class="fa-solid fa-handshake"></i>
                                    </div>
                                    <h4>Integrity</h4>
                                    <p>We believe in honest communication and ethical practice. Every treatment
                                        recommendation is based on what's truly best for your oral health.</p>
                                </div>
                            </div>

                            <div class="col">
                                <div class="value-card">
                                    <div class="value-icon">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </div>
                                    <h4>Continuous Excellence</h4>
                                    <p>Through ongoing education and training with international experts, we stay
                                        current with modern dental techniques and best practices.</p>
                                </div>
                            </div>

                            <div class="col">
                                <div class="value-card">
                                    <div class="value-icon">
                                        <i class="fa-solid fa-hand-holding-heart"></i>
                                    </div>
                                    <h4>Compassionate Care</h4>
                                    <p>We understand dental anxiety is real. Our warm, patient approach ensures you feel
                                        comfortable and supported throughout your visit.</p>
                                </div>
                            </div>

                            <div class="col">
                                <div class="value-card">
                                    <div class="value-icon">
                                        <i class="fa-solid fa-balance-scale"></i>
                                    </div>
                                    <h4>Accessibility</h4>
                                    <p>Quality dental care shouldn't be out of reach. We offer transparent pricing and
                                        flexible payment options to serve our community better.</p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>


            <!-- =========================== Section 7 ======================================= -->

            <section class="section7">
                <div class="section7-inner d-flex flex-column justify-content-end align-items-center">

                    <div class="col-left-book-now text-center">
                        <h2  class="reveal reveal-header">
                            Ready to Book Your Appointment?
                        </h2>
                        <p  class="reveal reveal-header">
                            Contact us today to schedule your visit and take the first step toward a healthier smile.
                        </p>
                    </div>

                    <div class="col-right-book-now reveal reveal-content">
                        <div class="col-right-book-now-btn h-100 ">
                            <button class="book-now-btn">
                                Book Appointment
                            </button>
                        </div>
                    </div>

                </div>

            </section>









            <!-- =================== Footer ========================= -->

            <?php include '../user-interface/footer.php'; ?>

        </div>





        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="../../assets/js/user-interface/navbar.js"></script>
        <script src="../../assets/js/user-interface/footer.js"></script>
        <script src="../../assets/js/user-interface/about.js"></script>




</body>

</html>