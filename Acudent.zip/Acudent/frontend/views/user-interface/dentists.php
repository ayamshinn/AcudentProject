<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAPRU - Dentist</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../assets/css/user-interface/dentists.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/navbar.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');
    </style>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
    </style>

</head>

<body>
    <div class="main-container ">

        <?php include '../user-interface/navbar.php'; ?>


        <div class="landing-page-content-main-container">
            <!----------Landing Page --------------->


            <section class="section1 d-flex flex-column justify-content-center align-items-center">

                <div class="dentists-hero-banner w-100 ">
                    <div
                        class="dentists-hero-banner-inner d-flex flex-column justify-content-center align-items-center">
                        <div class="dentists-hero-banner-title">
                            <h1>Meet Our Team</h1>
                        </div>
                        <hr class="hori-line">
                        <div
                            class="dentists-hero-banner-sub mt-4 d-flex flex-row w-100 justify-content-center align-items-center gap-3">
                            <div class="dentists-hero-banner-sub-left d-flex flex-row">
                                <h5> <a href="../user-interface/index.php"><i
                                            class="fa-solid fa-house me-2"></i>Home</a> <i
                                        class="fa-solid fa-chevron-right mx-3"></i></h5>


                            </div>
                            <div class="dentists-hero-banner-sub-right">
                                <h5>Dentists</h5>

                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="section2">
                <div class="secondbanner-main-container">
                    <div class="dentist-banner2-inner py-4 ">


                        <div
                            class="row row-cols-xxl-6 row-col-xl-6 row-col-lg-12 row-col-md-12 row-col-sm-12 row-col-12">
                            <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-left">
                                <div class="doctors-secondbanner-pic-left">
                                    <div class="doctors-secondbanner-pic-left-inner">
                                        <div class="doctors-secondbanner-left">
                                            <img src="../../assets/images/user-interface/banners-images-logo/hero-banner0.webp"
                                                alt="Group Photo of dentist">
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-right">

                                <div class="secondbanner-preview-text">
                                    <h5><i class="fa-solid fa-handshake"></i> Our Commitment</h5>
                                    <h2>Professional Care You Can Feel Confident In</h2>
                                    <p>
                                        Every treatment at MAPRU is guided by professional integrity, clinical
                                        expertise,
                                        and a deep commitment to patient well-being. Our doctors combine experience with
                                        continuous development to ensure safe, comfortable, and dependable dental care.
                                    </p>


                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </section>

            <section class="section3">
                <div class="doctor-card">
                    <div class="doctor">
                        <div class="doctor-left-container">
                            <div class="border-detail-left">
                                <img src="../../assets/images/user-interface/doctors/Dra.maja1.jpg"
                                    alt="Picture of Mapru">
                            </div>
                        </div>

                        <div class="details-container">
                            <div class="details-doctor-name">
                                <h3>Dr. Maja Prudente</h3>

                                <div class="details-doctor-specialization">
                                    <div class="details-icon-doctor">
                                        <i class="fa-solid fa-user-doctor"></i>
                                        <h4>Lead Dentist</h4>
                                    </div>
                                    <h5>Cosmetic Dentistry Specialist</h5>
                                </div>

                                <div class="details-about-doctor">
                                    <p>Dr. Maja Prudente is the Owner and Chief Dentist of MAPRU Dental Clinic in
                                        Bacoor, Cavite, and also serves as a dentist at South Imus Specialists Hospital.
                                        She earned her Doctor of Dental Medicine degree from Centro Escolar University
                                        and previously completed a Bachelor's Degree in Nursing Education at Manila
                                        Doctors College. With years of experience in both hospital and private practice,
                                        she is dedicated to providing quality dental care with a focus on patient
                                        comfort and overall oral health.
                                        <br><br>
                                        Beyond her academic background, Dr. Prudente has pursued specialized training in
                                        orthodontics, oral surgery, hospital dentistry, and dental sleep medicine,
                                        enhancing her ability to offer comprehensive treatments to her patients.
                                    </p>
                                </div>

                                <div class="doctors-social-reveal-btn">
                                    <i class="fa-solid fa-angle-right trigger-icon"></i>
                                    <div class="social-icons">
                                        <a href="https://www.instagram.com/maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-instagram"></i>
                                        </a>
                                        <a href="https://www.facebook.com/maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-facebook"></i>
                                        </a>
                                        <a href="https://www.tiktok.com/@maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-tiktok"></i>
                                        </a>
                                        <a href="https://www.linkedin.com/in/maja-prudente-232691b0" target="_blank">
                                            <i class="fa-brands fa-linkedin"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="doctor-card">
                    <div class="doctor">
                        <div class="details-container">
                            <div class="details-doctor-name">
                                <h3>Dr. Renz Christian Tiozon</h3>

                                <div class="details-doctor-specialization">
                                    <div class="details-icon-doctor">
                                        <i class="fa-solid fa-user-doctor"></i>
                                        <h4>Co-Dentist</h4>
                                    </div>
                                    <h5>Cosmetic Dentistry Specialist</h5>
                                </div>

                                <div class="details-about-doctor">
                                    <p>Dr. Renz Christian Tiozon is a Co-Dentist at MAPRU Dental Clinic, where he
                                        provides comprehensive dental care with a strong focus on cosmetic and
                                        restorative treatments. He is committed to helping patients achieve healthy,
                                        confident smiles through personalized and detail-oriented care. Dr. Tiozon
                                        earned his Doctor of Dental Medicine degree and has developed hands-on
                                        experience in both general and cosmetic dentistry.
                                        <br><br>
                                        His clinical interests include smile enhancement procedures, aesthetic
                                        restorations, and preventive dental care, allowing him to address both the
                                        functional and visual aspects of oral health.
                                    </p>
                                </div>

                                <div class="doctors-social-reveal-btn">
                                    <i class="fa-solid fa-angle-right trigger-icon"></i>
                                    <div class="social-icons">
                                        <a href="https://www.instagram.com/maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-instagram"></i>
                                        </a>
                                        <a href="https://www.facebook.com/maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-facebook"></i>
                                        </a>
                                        <a href="https://www.tiktok.com/@maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-tiktok"></i>
                                        </a>
                                        <a href="https://www.linkedin.com/in/maja-prudente-232691b0" target="_blank">
                                            <i class="fa-brands fa-linkedin"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="doctor-right-container">
                            <div class="border-detail-right">
                                <img src="../../assets/images/user-interface/doctors/dr.Renz.jpg" alt="Picture of Renz">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="doctor-card">
                    <div class="doctor">
                        <div class="doctor-left-container">
                            <div class="border-detail-left">
                                <img src="../../assets/images/user-interface/doctors/Dr.Ruth.jpg"
                                    alt="Picture of Irish">
                            </div>
                        </div>

                        <div class="details-container">
                            <div class="details-doctor-name">
                                <h3>Dr. Irish Abarquez</h3>

                                <div class="details-doctor-specialization">
                                    <div class="details-icon-doctor">
                                        <i class="fa-solid fa-user-doctor"></i>
                                        <h4>Co-Dentist</h4>
                                    </div>
                                    <h5>Cosmetic Dentistry Specialist</h5>
                                </div>

                                <div class="details-about-doctor">
                                    <p>Dr. Irish Abarquez is a Co-Dentist at MAPRU Dental Clinic, providing
                                        comprehensive dental care with a strong emphasis on cosmetic and preventive
                                        dentistry. She is dedicated to enhancing patients' smiles while ensuring
                                        long-term oral health through personalized and patient-centered treatment. Dr.
                                        Abarquez earned her Doctor of Dental Medicine degree from a reputable dental
                                        institution in the Philippines.
                                        <br><br>
                                        During her academic training, she developed a keen interest in cosmetic
                                        dentistry and restorative procedures, which she continues to refine in her
                                        professional practice.
                                    </p>
                                </div>

                                <div class="doctors-social-reveal-btn">
                                    <i class="fa-solid fa-angle-right trigger-icon"></i>
                                    <div class="social-icons">
                                        <a href="https://www.instagram.com/maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-instagram"></i>
                                        </a>
                                        <a href="https://www.facebook.com/maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-facebook"></i>
                                        </a>
                                        <a href="https://www.tiktok.com/@maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-tiktok"></i>
                                        </a>
                                        <a href="https://www.linkedin.com/in/maja-prudente-232691b0" target="_blank">
                                            <i class="fa-brands fa-linkedin"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="doctor-card">
                    <div class="doctor">
                        <div class="details-container">
                            <div class="details-doctor-name">
                                <h3>Dr. Gladys Jano Gonzales</h3>

                                <div class="details-doctor-specialization">
                                    <div class="details-icon-doctor">
                                        <i class="fa-solid fa-user-doctor"></i>
                                        <h4>Co-Dentist</h4>
                                    </div>
                                    <h5>Orthodontics & Cosmetic Dentistry Specialist</h5>
                                </div>

                                <div class="details-about-doctor">
                                    <p>Dr. Gladys Jano Gonzales is a Co-Dentist at MAPRU Dental Clinic, providing
                                        comprehensive dental care with a focus on orthodontics and cosmetic dentistry.
                                        She is committed to helping patients achieve properly aligned, healthy, and
                                        confident smiles through well-planned and individualized treatments.
                                        <br><br>
                                        Dr. Gonzales earned her Doctor of Dental Medicine degree, where she developed a
                                        strong foundation in general dentistry, orthodontic principles, and aesthetic
                                        dental care. She continues to enhance her expertise through specialized
                                        training, seminars, and continuing education.
                                    </p>
                                </div>

                                <div class="doctors-social-reveal-btn">
                                    <i class="fa-solid fa-angle-right trigger-icon"></i>
                                    <div class="social-icons">
                                        <a href="https://www.instagram.com/maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-instagram"></i>
                                        </a>
                                        <a href="https://www.facebook.com/maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-facebook"></i>
                                        </a>
                                        <a href="https://www.tiktok.com/@maprudentalclinic" target="_blank">
                                            <i class="fa-brands fa-tiktok"></i>
                                        </a>
                                        <a href="https://www.linkedin.com/in/maja-prudente-232691b0" target="_blank">
                                            <i class="fa-brands fa-linkedin"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="doctor-right-container">
                            <div class="border-detail-right">
                                <img src="../../assets/images/user-interface/doctors/Dr.Jano2.jpg"
                                    alt="Picture of Renz">
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="section4">
                <div class="dentist-care-text-wrapper">
                    <h3 class="reveal reveal-header">Our Approach to Patient Care</h3>
                    <h5 class="reveal reveal-header">Focused on comfort, trust, and long-term oral health at every
                        visit.</h5>
                </div>

                <div class="row row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1">
                    <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-left">
                        <div class="dentist-care-main-container w-100 h-100">
                            <div class="dentist-care-text">
                                <div class="dentist-care-text-title pb-4">
                                    <h3>Expert Dental Care Designed Around You</h3>
                                </div>

                                <p>At <b>MAPRU Dental Clinic</b>, we prioritize patient comfort, safety, and
                                    personalized care
                                    in every treatment we provide. Each patient is thoroughly assessed to understand
                                    their dental needs, concerns, and goals, allowing our dentists to create
                                    individualized treatment plans.
                                    <br>
                                    <br>
                                    We combine professional expertise, modern dental techniques, and a compassionate
                                    approach to ensure a comfortable and positive experience. From preventive care to
                                    specialized treatments, our team is committed to guiding patients with clear
                                    communication, gentle care, and a strong focus on long-term oral health.
                                </p>
                                <hr class="hori-line py-2">


                                <div class="dentist-care-inner-text-container pt-2">
                                    <ul class="dentist-care-list">
                                        <li><i class="fa-solid fa-check"></i> Professional Expertise & Modern Techniques
                                        </li>
                                        <li><i class="fa-solid fa-check"></i> Compassionate & Gentle Care</li>
                                        <li><i class="fa-solid fa-check"></i> Clear Communication & Guidance</li>
                                        <li><i class="fa-solid fa-check"></i> Long-Term Oral Health Focus</li>
                                    </ul>
                                </div>

                            </div>

                        </div>
                    </div>

                    <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 py-5 reveal reveal-right">
                        <div class="vertical-slideshow">

                            <div class="slideshow-track" id="slideshowTrack">
                                <!-- ORIGINAL IMAGES -->
                                <img src="../../../frontend/assets/images/user-interface/doctors/result1.webp">
                                <img src="../../../frontend/assets/images/user-interface/doctors/result2.webp">
                                <img src="../../../frontend/assets/images/user-interface/doctors/result3.webp">
                                <img src="../../../frontend/assets/images/user-interface/doctors/result9.jpg">

                                <!-- DUPLICATE IMAGES (IMPORTANT FOR LOOP) -->
                                <img src="../../../frontend/assets/images/user-interface/doctors/result4.webp">
                                <img src="../../../frontend/assets/images/user-interface/doctors/result5.webp">
                                <img src="../../../frontend/assets/images/user-interface/doctors/result6.webp">
                                <img src="../../../frontend/assets/images/user-interface/doctors/result10.jpg">
                            </div>

                        </div>
                    </div>





                </div>
            </section>




            <section class="section5">
                <div class="section5-inner d-flex flex-column justify-content-end align-items-center">

                    <div class="col-left-book-now text-center">
                        <h2 class="reveal reveal-header">
                            Ready to Book Your Appointment?
                        </h2 class="reveal reveal-header">
                        <p class="reveal reveal-header">
                            Contact us today to schedule your visit and take the first step toward a healthier smile.
                        </p>
                    </div>

                    <div class="col-right-book-now reveal reveal-header">
                        <div class="col-right-book-now-btn h-100 ">
                            <button class="book-now-btn">
                                Book Appointment
                            </button>
                        </div>
                    </div>

                </div>

            </section>




            <section class="section6">
                <div class="row row-cols-xxl-3 row-cols-xl-3 row-cols-lg-2 row-cols-md-1 row-cols-sm-1 row-cols-1">
                    <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-12 col-sm-12 reveal reveal-left">
                        <div class="doctors-lower-bottom-left-pictures-container">
                            <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-12 col-sm-12 ">
                        <div class="doctors-lower-text-container ">
                            <div class="doctor-lower-text-wrapper">
                                <h5 class="reveal reveal-header">Your smile is our priority</h5>
                                <h4 class="reveal reveal-header">-Mapru Dental Clinic</h4>
                            </div>
                            <div class="lower-text-book-appointment">

                            </div>

                        </div>

                    </div>
                    <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-12 col-sm-12 reveal reveal-right">
                        <div class="doctors-lower-bottom-right-pictures-container">
                            <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg" alt="">
                        </div>
                    </div>
                </div>
            </section>

        </div>

        <!-- =================== Footer ========================= -->

        <?php include '../user-interface/footer.php'; ?>

    </div>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/user-interface/navbar.js"></script>
    <script src="../../assets/js/user-interface/footer.js"></script>

    <script src="../../assets/js/user-interface/dentists.js" defer></script>


</body>

</html>