<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAPRU - More Info Services</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../assets/css/user-interface/services-more-info.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/navbar.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');
    </style>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
    </style>

</head>

<body>

    <div class="main-container overflow-hidden">

        <?php include '../user-interface/navbar.php'; ?>


        <div class="services-page-container" id="services-page-container-id">
            <!----------Landing Page --------------->


            <section class="section1 d-flex flex-column justify-content-center align-items-center">

                <div class="dentists-hero-banner w-100 ">
                    <div
                        class="dentists-hero-banner-inner d-flex flex-column justify-content-center align-items-center">
                        <div class="dentists-hero-banner-title">
                            <h1>Cosmetic Dentistry</h1>
                        </div>
                        <hr class="hori-line">
                        <div
                            class="dentists-hero-banner-sub mt-4 d-flex flex-row w-100 justify-content-center align-items-center gap-3">
                            <div class="dentists-hero-banner-sub-left  d-flex flex-row">
                                <h5> <a href="../user-interface/index.php"><i
                                            class="fa-solid fa-house me-2"></i>Home</a> <i
                                        class="fa-solid fa-chevron-right mx-3"></i></h5>


                            </div>
                            <div class="dentists-hero-banner-sub-right m-0 d-flex flex-row ">
                                <h5> <a href="../user-interface/services.php"></i>Services</a> <i
                                        class="fa-solid fa-chevron-right mx-3"></i></h6>
                                    <h6>Cosmetic Dentistry
                                </h5>

                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- =========================== Section 2 ===================================== -->
            <section class="section2">
                <div class="services-banner2-main-container ">
                    <div class="services-banner2-inner  py-4">
                        <div class="row g-3">
                            <div class="col-md-6  reveal reveal-left">
                                <div class="services-banner2-col-left">
                                    <div class="services-banner2-col-left-inner">
                                        <div class="services-banner2-col-left-img">
                                            <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg"
                                                alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 reveal reveal-right">
                                <div class="services-banner2-col-right-inner">
                                    <div class="services-col-container-content">
                                        <h5><i class="fa-solid fa-users-gear"></i> Cosmetic Dentistry at MAPRU</h5>
                                        <h2>Designed for Your Best Smile</h2>
                                        <h2> Naturally and Confidently</h2>


                                        <p>
                                            At MAPRU, our cosmetic dentistry services are designed to enhance the
                                            appearance
                                            of your smile while maintaining optimal oral health. From whitening and
                                            bonding
                                            to personalized aesthetic treatments, we focus on natural-looking results,
                                            comfort, and confidence in every procedure.
                                        </p>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ============================ Section 3 ================================== -->

            <section class="section3">
                <div class="services-main-container">
                    <div class="services-inner ">

                        <div class="services-inner-header text-center mb-5">

                            <h5 class="reveal reveal-header">Cosmetic Dentistry</h5>
                            <h2 class="reveal reveal-header">
                                Cosmetic Care We Offer
                            </h2>

                        </div>
                        <div class="row row-cols-4 g-4 d-flex ">

                            <div class="col services-col reveal reveal-content reveal reveal-content">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content">

                                            <h5>Tooth Filling</h5>
                                            <p>
                                                Restores damaged or decayed teeth to maintain strength, function, and
                                                comfort.
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col services-col reveal reveal-content">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content">

                                            <h5>Tooth Filling</h5>
                                            <p>
                                                Restores damaged or decayed teeth to maintain strength, function, and
                                                comfort.
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col services-col reveal reveal-content">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content">

                                            <h5>Tooth Filling</h5>
                                            <p>
                                                Restores damaged or decayed teeth to maintain strength, function, and
                                                comfort.
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col services-col reveal reveal-content">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content">

                                            <h5>Tooth Whitening</h5>
                                            <p>
                                                Brightens and enhances your smile by safely removing stains and
                                                discoloration.
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col services-col reveal reveal-content">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content">

                                            <h5>Tooth Filling</h5>
                                            <p>
                                                Restores damaged or decayed teeth to maintain strength, function, and
                                                comfort.
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col services-col reveal reveal-content">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content">

                                            <h5>Tooth Filling</h5>
                                            <p>
                                                Restores damaged or decayed teeth to maintain strength, function, and
                                                comfort.
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col services-col reveal reveal-content">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content">

                                            <h5>Tooth</h5>
                                            <p>
                                                Restores damaged or decayed teeth to maintain strength, function, and
                                                comfort.
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col services-col reveal reveal-content">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content">

                                            <h5>Cosmetic Bonding</h5>
                                            <p>
                                                Improves the appearance of teeth by correcting chips, gaps, and minor
                                                imperfections.
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </section>




            <!-- ============================= Section 4 =================== -->
             

            <section class="section4">
                <div class="why-choose-mapru-services-main">
                    <div class="\+why-choose-mapru-services-inner ">
                        <div class="row row-cols-1 row-cols-lg-2">
                            <div class="col reveal reveal-left">
                                <div class="why-mapru-services-col-left">
                                    <h5><i class="fa-regular fa-lightbulb"></i> Why Choose MAPRU for Cosmetic Dentistry?
                                    </h5>
                                    <h2>Enhancing Smiles with Confidence and Precision</h2>
                                    <p>
                                        When it comes to cosmetic dentistry, expertise and attention to detail matter.
                                        At MAPRU, we focus on creating natural-looking, beautiful smiles through
                                        personalized treatments. Our team combines modern techniques with a
                                        patient-centered approach to deliver results that look great and feel
                                        comfortable.
                                    </p>

                                    <ul>
                                        <li><i class="fa-solid fa-check-double"></i> Customized cosmetic treatments
                                            tailored to your smile goals</li>
                                        <li><i class="fa-solid fa-check-double"></i> Advanced aesthetic techniques for
                                            natural-looking results</li>
                                        <li><i class="fa-solid fa-check-double"></i> Focus on comfort, safety, and
                                            precision in every procedure</li>
                                        <li><i class="fa-solid fa-check-double"></i> Smile-enhancing solutions that
                                            boost confidence and appearance</li>
                                    </ul>
                                </div>
                            </div>

                            <div class="col reveal reveal-right">
                                <div class="why-mapru-services-col-right">
                                    <div class="dental-images-grid">
                                        <div class="dental-images-grid-left d-flex flex-column">
                                            <div class="dental-images-grid-left-top">
                                                <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg"
                                                    alt="Dental patient" class="dental-img-1">
                                            </div>
                                            <div class="dental-images-grid-left-bottom">
                                                <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg"
                                                    alt="Dental professional" class="dental-img-2">
                                            </div>
                                        </div>
                                        <div class="dental-images-grid-right ">
                                            <div class="dental-images-grid-right-inner">
                                                <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg"
                                                    alt="Dental office" class="dental-img-3">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- =========================== Section 5 ======================================= -->

            <section class="section5">
                <div class="section5-inner d-flex flex-column justify-content-end align-items-center">
                    
                            <div class="col-left-book-now text-center">
                                <h2 class="reveal reveal-header">
                                    Ready to Book Your Appointment?
                                </h2 class="reveal reveal-header">
                                <p class="reveal reveal-header">
                                    Contact us today to schedule your visit and take the first step toward a healthier smile.
                                </p >
                            </div>
                       
                             <div class="col-right-book-now reveal reveal-content">
                                <div class="col-right-book-now-btn h-100 ">
                                <button class="book-now-btn">
                                    Book Appointment
                                </button>
                                </div>
                            </div>
                    
                </div>

            </section>




        </div>



        <!-- =================== Footer ========================= -->

        <?php include '../user-interface/footer.php'; ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/user-interface/navbar.js"></script>
    <script src="../../assets/js/user-interface/footer.js"></script>
        <script src="../../assets/js/user-interface/services-more-info.js"></script>




</body>

</html>