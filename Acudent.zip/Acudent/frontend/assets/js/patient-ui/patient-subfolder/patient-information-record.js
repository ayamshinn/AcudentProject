document.querySelector(".btn-add-record").addEventListener("click", () => {
    document.querySelector(".no-record-overlay").style.display = "none";
});
