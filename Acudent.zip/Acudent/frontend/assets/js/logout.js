async function logoutUser(event) {
    if (event) event.preventDefault();

    const response = await fetch("/backend/api/auth/logout.php", {
        method: "POST",
        credentials: "include"
    });

    const result = await response.json();

    if (result.success) {
        window.location.href = "../user-interface/auth.html";
    }
}
