document.addEventListener("DOMContentLoaded", () => {
  const navbar = document.querySelector(".navbar-main-container");
  const navLinks = document.querySelectorAll(".nav-links a");

  // ===== Add Active Class Based on Current Page =====
  const currentPage = window.location.pathname.split("/").pop();

  navLinks.forEach(link => {
    const linkPage = link.getAttribute("href").split("/").pop();
    if (currentPage === linkPage) {
      link.classList.add("active");
    }
  });

  // ===== Hide/Show Navbar on Scroll =====
  if (navbar) {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 50) {
        navbar.classList.add("hide");
        navbar.classList.remove("show");
      } else {
        navbar.classList.add("show");
        navbar.classList.remove("hide");
      }
    });
  }
});
