document.addEventListener("DOMContentLoaded", () => {

  section2Animation();
  section3Animation();
  section4Animation();
  section5Animation();





});



function section2Animation() {
  const section = document.querySelector('.section2');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.1;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.1;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.1;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1, .1]
  });

  reveals.forEach(el => observer.observe(el));
}




function section3Animation() {
  const section = document.querySelector('.section3');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.2;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, .2]
  });

  reveals.forEach(el => observer.observe(el));
}



function section4Animation() {
  const section = document.querySelector('.section4');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, .2]
  });

  reveals.forEach(el => observer.observe(el));
}



function section5Animation() {
  const section = document.querySelector('.section5');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.2;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, .2]
  });

  reveals.forEach(el => observer.observe(el));
}


