function initAdminDentistRegister() {
    setupAutoGeneration();
    showPasswordToggle();
    initMultiStepNavigation();
}

// ==================== PASSWORD TOGGLE ====================
function showPasswordToggle() {
    const toggleIcons = document.querySelectorAll('.toggle-password');
    
    toggleIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            const passwordInput = this.previousElementSibling;
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            }
        });
    });
}

// ==================== AUTO-GENERATION ====================
function setupAutoGeneration() {
    const section1 = document.getElementById('section-1');
    const firstNameInput = section1.querySelector('#firstName');
    const lastNameInput = section1.querySelector('#lastName');
    const dateOfBirthInput = section1.querySelector('#dateOfBirth');
    const emailInputSection1 = section1.querySelector('#email');
    
    const section4 = document.getElementById('section-4');
    const loginEmailInput = section4.querySelector('#loginEmail');
    const passwordInput = section4.querySelector('#password');
    const firstNameInputSection4 = section4.querySelector('#firstName');
    const lastNameInputSection4 = section4.querySelector('#lastName');
    const emailInputSection4 = section4.querySelector('#email');

    if (loginEmailInput) loginEmailInput.readOnly = true;
    if (passwordInput) passwordInput.readOnly = true;
    if (firstNameInputSection4) firstNameInputSection4.readOnly = true;
    if (lastNameInputSection4) lastNameInputSection4.readOnly = true;
    if (emailInputSection4) emailInputSection4.readOnly = true;

    function updateAccountInfo() {
        const firstName = firstNameInput.value.trim();
        const lastName = lastNameInput.value.trim();
        const dateOfBirth = dateOfBirthInput.value;
        const email = emailInputSection1.value.trim();
        
        // Auto-populate first name and last name in Section 4
        if (firstNameInputSection4) {
            firstNameInputSection4.value = firstName;
        }
        if (lastNameInputSection4) {
            lastNameInputSection4.value = lastName;
        }
        
        // Auto-populate contact email in Section 4
        if (emailInputSection4) {
            emailInputSection4.value = email;
        }
        
        // Generate login email
        if (lastName) {
            loginEmailInput.value = `dentist${lastName}@mapru.com`;
        } else {
            loginEmailInput.value = '';
        }
        
        // Generate password with birthday
        if (lastName && dateOfBirth) {
            // Format birthday as MMDDYYYY
            const date = new Date(dateOfBirth);
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            const year = date.getFullYear();
            const birthday = `${month}${day}${year}`;
            
            passwordInput.value = `@mapru${lastName}${birthday}`;
        } else if (lastName) {
            passwordInput.value = `@mapru${lastName}`;
        } else {
            passwordInput.value = '';
        }
    }

    if (firstNameInput) {
        firstNameInput.addEventListener('input', updateAccountInfo);
    }
    
    if (lastNameInput) {
        lastNameInput.addEventListener('input', updateAccountInfo);
    }
    
    if (dateOfBirthInput) {
        dateOfBirthInput.addEventListener('input', updateAccountInfo);
    }
    
    if (emailInputSection1) {
        emailInputSection1.addEventListener('input', updateAccountInfo);
    }
}

// ==================== MULTI-STEP NAVIGATION ====================
function initMultiStepNavigation() {
    let currentStep = 1;
    const totalSteps = 5;

    const sections = document.querySelectorAll('.input-process-container');
    const circleBorders = document.querySelectorAll('.circle-border');
    const filledLine = document.getElementById('filled-line');
    const nextBtn = document.getElementById('nextBtn');
    const prevBtn = document.getElementById('prevBtn');
    const submitBtn = document.getElementById('submitBtn');

    if (!sections.length) return;

    showStep(currentStep);

    function showStep(step) {
        sections.forEach(section => section.style.display = 'none');
        sections[step - 1].style.display = 'block';
        updateProgressBar(step);
        updateButtons(step);
    }

    function updateProgressBar(step) {
        circleBorders.forEach((border, index) => {
            if (index < step) {
                border.classList.add('active');
            } else {
                border.classList.remove('active');
            }
        });

        const percentage = ((step - 1) / (totalSteps - 1)) * 100;
        filledLine.style.width = percentage + '%';
    }

    function updateButtons(step) {
        prevBtn.style.display = step === 1 ? 'none' : 'inline-block';
        nextBtn.style.display = step === totalSteps ? 'none' : 'inline-block';
        submitBtn.style.display = step === totalSteps ? 'inline-block' : 'none';
    }

    function validateStep(step) {
        const currentSection = sections[step - 1];
        const inputs = currentSection.querySelectorAll('input[required], select[required], textarea[required]');
        let isValid = true;
        let firstInvalid = null;

        // Check all inputs and mark invalid ones with red border
        inputs.forEach(input => {
            if (input.type === 'checkbox') return;
            
            // Skip readonly fields in validation (they're auto-generated)
            if (input.readOnly) return;
            
            if (!input.checkValidity()) {
                input.classList.add('is-invalid');
                isValid = false;
                if (!firstInvalid) {
                    firstInvalid = input;
                }
            } else {
                input.classList.remove('is-invalid');
            }
        });

        // Step 3: Validate working days
        if (step === 3) {
            const workingDays = currentSection.querySelectorAll('input[name="workingDays"]:checked');
            if (workingDays.length === 0) {
                alert('Please select at least one working day');
                isValid = false;
            }
        }

        // Step 5: Verify checkbox
        if (step === 5) {
            const agreeCheckbox = document.getElementById('agreeTerms');
            if (agreeCheckbox && !agreeCheckbox.checked) {
                agreeCheckbox.classList.add('is-invalid');
                if (!firstInvalid) {
                    firstInvalid = agreeCheckbox;
                }
                isValid = false;
            } else if (agreeCheckbox) {
                agreeCheckbox.classList.remove('is-invalid');
            }
        }

        
        // Show native validation tooltip on first invalid field
        if (!isValid && firstInvalid) {
            firstInvalid.reportValidity(); // Shows native "Please fill out this field" tooltip
            firstInvalid.focus();
        }

        return isValid;
    }

    // ==================== NAVIGATION EVENTS ====================
    nextBtn.addEventListener('click', () => {
        if (validateStep(currentStep)) {
            currentStep++;
            showStep(currentStep);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    });

    prevBtn.addEventListener('click', () => {
        currentStep--;
        showStep(currentStep);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    submitBtn.addEventListener('click', () => {
        if (validateStep(currentStep)) {
            const formData = collectFormData();
            console.log('Form Data:', formData);
            
           
        }
    });

    // Real-time error removal when user starts typing
    document.querySelectorAll('input, select, textarea').forEach(input => {
        input.addEventListener('input', () => {
            input.classList.remove('is-invalid');
        });

        input.addEventListener('change', () => {
            input.classList.remove('is-invalid');
        });
    });

    // Function to collect all form data
    function collectFormData() {
        const section1 = document.getElementById('section-1');
        const section4 = document.getElementById('section-4');
        
        const workingDays = Array.from(document.querySelectorAll('input[name="workingDays"]:checked'))
            .map(cb => cb.value);

        return {
            firstName: section1.querySelector('#firstName')?.value.trim() || '',
            lastName: section1.querySelector('#lastName')?.value.trim() || '',
            dateOfBirth: document.getElementById('dateOfBirth')?.value || '',
            gender: document.getElementById('gender')?.value || '',
            phone: document.getElementById('phone')?.value.trim() || '',
            email: section1.querySelector('#email')?.value.trim() || '',
            address: document.getElementById('address')?.value.trim() || '',
            licenseNumber: document.getElementById('licenseNumber')?.value.trim() || '',
            specialization: document.getElementById('specialization')?.value.trim() || '',
            education: document.getElementById('education')?.value.trim() || '',
            notes: document.getElementById('notes')?.value.trim() || '',
            startDate: document.getElementById('startDate')?.value || '',
            position: document.getElementById('position')?.value || '',
            workingDays: workingDays,
            startTime: document.getElementById('startTime')?.value || '',
            endTime: document.getElementById('endTime')?.value || '',
            loginEmail: section4.querySelector('#loginEmail')?.value.trim() || '',
            password: section4.querySelector('#password')?.value.trim() || ''
        };
    }
}

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', () => {
    initAdminDentistRegister();
});