// ===================== DENTIST REGISTRATION FORM LOGIC =====================
// Handles ONLY: Form UI, validation, navigation, and submission workflow
// REQUIRES: dentist-account-api.js and dentist-record-api.js to be loaded first

(function() {
    'use strict';

    // ==================== DEVELOPMENT MODE (Set to false in production) ====================
    const DEBUG_MODE = false;

    // ==================== WAIT FOR API SCRIPTS TO LOAD ====================
    function waitForAPIs(callback) {
        const checkAPIs = setInterval(() => {
            if (window.createDentistAccountWithImage && window.createDentistRecordWithImage) {
                clearInterval(checkAPIs);
                callback();
            }
        }, 100);
        
        // Timeout after 5 seconds
        setTimeout(() => {
            clearInterval(checkAPIs);
            if (!window.createDentistAccountWithImage || !window.createDentistRecordWithImage) {
                console.error('Required API functions not loaded');
                alert('System error: Required API scripts not loaded. Please refresh the page.');
            }
        }, 5000);
    }

    // ==================== AUTO-GENERATION SETUP ====================
    function setupAutoGeneration() {    
        const section1 = document.getElementById('section-1');
        const firstNameInput = section1?.querySelector('#firstName');
        const lastNameInput = section1?.querySelector('#lastName');
        const dateOfBirthInput = section1?.querySelector('#dateOfBirth');
        const emailInputSection1 = section1?.querySelector('#email');
        
        const section4 = document.getElementById('section-4');
        const loginEmailInput = section4?.querySelector('#loginEmail');
        const passwordInput = section4?.querySelector('#password');
        const firstNameInputSection4 = section4?.querySelector('#firstNameAccount');
        const lastNameInputSection4 = section4?.querySelector('#lastNameAccount');
        const emailInputSection4 = section4?.querySelector('#emailAccount');

        if (loginEmailInput) loginEmailInput.readOnly = true;
        if (passwordInput) passwordInput.readOnly = true;
        if (firstNameInputSection4) firstNameInputSection4.readOnly = true;
        if (lastNameInputSection4) lastNameInputSection4.readOnly = true;
        if (emailInputSection4) emailInputSection4.readOnly = true;

        function updateAccountInfo() {
            if (!firstNameInput || !lastNameInput || !loginEmailInput || !passwordInput) {
                return;
            }

            const firstName = firstNameInput.value.trim();
            const lastName = lastNameInput.value.trim();
            const dateOfBirth = dateOfBirthInput?.value || '';
            const email = emailInputSection1?.value.trim() || '';
            
            if (firstNameInputSection4) {
                firstNameInputSection4.value = firstName;
            }
            if (lastNameInputSection4) {
                lastNameInputSection4.value = lastName;
            }
            
            if (emailInputSection4) {
                emailInputSection4.value = email;
            }
            
            if (lastName) {
                loginEmailInput.value = `dentist${lastName}@mapru.com`;
            } else {
                loginEmailInput.value = '';
            }
            
            if (lastName && dateOfBirth) {
                const date = new Date(dateOfBirth);
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                const year = date.getFullYear();
                const birthday = `${month}${day}${year}`;
                
                passwordInput.value = `@mapru${lastName}${birthday}`;
            } else if (lastName) {
                passwordInput.value = `@mapru${lastName}`;
            } else {
                passwordInput.value = '';
            }
        }

        if (firstNameInput) {
            firstNameInput.addEventListener('input', updateAccountInfo);
        }
        
        if (lastNameInput) {
            lastNameInput.addEventListener('input', updateAccountInfo);
        }
        
        if (dateOfBirthInput) {
            dateOfBirthInput.addEventListener('input', updateAccountInfo);
        }
        
        if (emailInputSection1) {
            emailInputSection1.addEventListener('input', updateAccountInfo);
        }
    }

    // ==================== PASSWORD TOGGLE ====================
    function showPasswordToggle() {
        const toggleIcons = document.querySelectorAll('.toggle-password');
        
        toggleIcons.forEach(icon => {
            icon.addEventListener('click', function() {
                const container = this.parentElement;
                const passwordInput = container.querySelector('input[type="password"], input[type="text"]');
                
                if (passwordInput) {
                    if (passwordInput.type === 'password') {
                        passwordInput.type = 'text';
                        this.classList.remove('fa-eye');
                        this.classList.add('fa-eye-slash');
                    } else {
                        passwordInput.type = 'password';
                        this.classList.remove('fa-eye-slash');
                        this.classList.add('fa-eye');
                    }
                }
            });
        });
    }

    // ==================== PROFILE PICTURE UPLOAD HANDLING ====================
    function setupProfilePictureUpload() {
        // Section 1: Professional Picture (for landing page - dentists_tb)
        const professionalPictureInput = document.getElementById('professionalPicture');
        const uploadProfessionalBtn = document.getElementById('uploadProfessionalBtn');
        const removeProfessionalBtn = document.getElementById('removeProfessionalBtn');
        const professionalImagePreview = document.getElementById('profileImagePreview');
        const professionalDefaultIcon = document.getElementById('profileDefaultIcon');

        // Section 4: Account Profile Picture (for system account - users_tb)
        const accountProfilePictureInput = document.getElementById('accountProfilePicture');
        const uploadAccountProfileBtn = document.getElementById('uploadAccountProfileBtn');
        const removeAccountProfileBtn = document.getElementById('removeAccountProfileBtn');
        const accountProfileImagePreview = document.getElementById('accountProfileImagePreview');
        const accountDefaultIcon = document.getElementById('accountDefaultIcon');

        // Professional Picture Upload Handler (Landing Page)
        if (uploadProfessionalBtn && professionalPictureInput) {
            uploadProfessionalBtn.addEventListener('click', () => {
                professionalPictureInput.click();
            });

            professionalPictureInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    // Validate file size (5MB max)
                    if (file.size > 5 * 1024 * 1024) {
                        alert('File size must be less than 5MB');
                        professionalPictureInput.value = '';
                        return;
                    }

                    // Validate file type
                    if (!file.type.startsWith('image/')) {
                        alert('Please select an image file (JPG, PNG)');
                        professionalPictureInput.value = '';
                        return;
                    }

                    // Preview the image
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        professionalImagePreview.src = e.target.result;
                        professionalImagePreview.style.display = 'block';
                        professionalDefaultIcon.style.display = 'none';
                        removeProfessionalBtn.style.display = 'inline-block';
                    };
                    reader.readAsDataURL(file);
                }
            });

            // Remove Professional Picture
            if (removeProfessionalBtn) {
                removeProfessionalBtn.addEventListener('click', () => {
                    professionalPictureInput.value = '';
                    professionalImagePreview.src = '';
                    professionalImagePreview.style.display = 'none';
                    professionalDefaultIcon.style.display = 'block';
                    removeProfessionalBtn.style.display = 'none';
                });
            }
        }

        // Account Profile Picture Upload Handler (System Account)
        if (uploadAccountProfileBtn && accountProfilePictureInput) {
            uploadAccountProfileBtn.addEventListener('click', () => {
                accountProfilePictureInput.click();
            });

            accountProfilePictureInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    // Validate file size (5MB max)
                    if (file.size > 5 * 1024 * 1024) {
                        alert('File size must be less than 5MB');
                        accountProfilePictureInput.value = '';
                        return;
                    }

                    // Validate file type
                    if (!file.type.startsWith('image/')) {
                        alert('Please select an image file (JPG, PNG)');
                        accountProfilePictureInput.value = '';
                        return;
                    }

                    // Preview the image
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        accountProfileImagePreview.src = e.target.result;
                        accountProfileImagePreview.style.display = 'block';
                        accountDefaultIcon.style.display = 'none';
                        removeAccountProfileBtn.style.display = 'inline-block';
                    };
                    reader.readAsDataURL(file);
                }
            });

            // Remove Account Profile Picture
            if (removeAccountProfileBtn) {
                removeAccountProfileBtn.addEventListener('click', () => {
                    accountProfilePictureInput.value = '';
                    accountProfileImagePreview.src = '';
                    accountProfileImagePreview.style.display = 'none';
                    accountDefaultIcon.style.display = 'block';
                    removeAccountProfileBtn.style.display = 'none';
                });
            }
        }
    }

    // ==================== MULTI-STEP NAVIGATION ====================
    function initMultiStepNavigation() {
        let currentStep = 1;
        const totalSteps = 5;

        const sections = document.querySelectorAll('.input-process-container');
        const circleBorders = document.querySelectorAll('.circle-border');
        const filledLine = document.getElementById('filled-line');
        const nextBtn = document.getElementById('nextBtn');
        const prevBtn = document.getElementById('prevBtn');
        const submitBtn = document.getElementById('submitBtn');

        if (!sections.length) {
            console.error('No sections found');
            return;
        }

        if (DEBUG_MODE) console.log(`Found ${sections.length} sections`);

        // Create error container
        let errorContainer = document.querySelector(".dentist-error-msg");
        if (!errorContainer) {
            errorContainer = document.createElement("div");
            errorContainer.className = "dentist-error-msg";
            errorContainer.style.cssText = "color: #dc3545; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #f8d7da; border: 1px solid #f5c6cb; display: none;";
            
            const formContainer = document.querySelector('.appointment-add-dentist-record-inner');
            if (formContainer) {
                formContainer.insertBefore(errorContainer, formContainer.firstChild);
            }
        }

        // Create success container
        let successContainer = document.querySelector(".dentist-success-msg");
        if (!successContainer) {
            successContainer = document.createElement("div");
            successContainer.className = "dentist-success-msg";
            successContainer.style.cssText = "color: #155724; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #d4edda; border: 1px solid #c3e6cb; display: none;";
            
            const formContainer = document.querySelector('.appointment-add-dentist-record-inner');
            if (formContainer) {
                formContainer.insertBefore(successContainer, formContainer.firstChild);
            }
        }

        showStep(currentStep);

        function showStep(step) {
            if (DEBUG_MODE) console.log(`Showing step ${step}`);
            sections.forEach(section => section.style.display = 'none');
            if (sections[step - 1]) {
                sections[step - 1].style.display = 'block';
            }
            updateProgressBar(step);
            updateButtons(step);
        }

        function updateProgressBar(step) {
            circleBorders.forEach((border, index) => {
                if (index < step) {
                    border.classList.add('active');
                } else {
                    border.classList.remove('active');
                }
            });

            const percentage = ((step - 1) / (totalSteps - 1)) * 100;
            if (filledLine) {
                filledLine.style.width = percentage + '%';
            }
        }

        function updateButtons(step) {
            if (prevBtn) prevBtn.style.display = step === 1 ? 'none' : 'inline-block';
            if (nextBtn) nextBtn.style.display = step === totalSteps ? 'none' : 'inline-block';
            if (submitBtn) submitBtn.style.display = step === totalSteps ? 'inline-block' : 'none';
        }

        function validateStep(step) {
            const currentSection = sections[step - 1];
            if (!currentSection) return false;

            const inputs = currentSection.querySelectorAll('input[required], select[required], textarea[required]');
            let isValid = true;
            let firstInvalid = null;

            inputs.forEach(input => {
                if (input.type === 'checkbox') return;
                if (input.readOnly) return;
                
                if (!input.checkValidity()) {
                    input.classList.add('is-invalid');
                    isValid = false;
                    if (!firstInvalid) {
                        firstInvalid = input;
                    }
                } else {
                    input.classList.remove('is-invalid');
                }
            });

            if (step === 3) {
                const workingDays = currentSection.querySelectorAll('input[name="workingDays"]:checked');
                if (workingDays.length === 0) {
                    alert('Please select at least one working day');
                    isValid = false;
                }
            }

            if (step === 5) {
                const agreeCheckbox = document.getElementById('agreeTerms');
                if (agreeCheckbox && !agreeCheckbox.checked) {
                    agreeCheckbox.classList.add('is-invalid');
                    if (!firstInvalid) {
                        firstInvalid = agreeCheckbox;
                    }
                    isValid = false;
                } else if (agreeCheckbox) {
                    agreeCheckbox.classList.remove('is-invalid');
                }
            }

            if (!isValid && firstInvalid) {
                firstInvalid.reportValidity();
                firstInvalid.focus();
            }

            return isValid;
        }

        function showErrors(errors) {
            if (errors.length === 0) {
                errorContainer.style.display = "none";
                return;
            }

            let errorHTML = "<strong><i class='fa-solid fa-circle-exclamation'></i> Please fix the following errors:</strong><ul style='margin: 8px 0 0 20px; padding-left: 0;'>";
            errors.forEach(error => {
                errorHTML += `<li style='margin: 4px 0;'>${error}</li>`;
            });
            errorHTML += "</ul>";

            errorContainer.innerHTML = errorHTML;
            errorContainer.style.display = "block";
            successContainer.style.display = "none";
            errorContainer.scrollIntoView({ behavior: "smooth", block: "center" });
        }

        function showSuccess(message) {
            successContainer.innerHTML = `<strong><i class='fa-solid fa-circle-check'></i> ${message}</strong>`;
            successContainer.style.display = "block";
            errorContainer.style.display = "none";
            successContainer.scrollIntoView({ behavior: "smooth", block: "center" });
        }

        function showProgress(message) {
            successContainer.innerHTML = `<strong><i class='fa-solid fa-spinner fa-spin'></i> ${message}</strong>`;
            successContainer.style.display = "block";
            errorContainer.style.display = "none";
        }

        // Next button
        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                if (DEBUG_MODE) console.log('Next button clicked');
                if (validateStep(currentStep)) {
                    currentStep++;
                    showStep(currentStep);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
            });
        }

        // Previous button
        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                if (DEBUG_MODE) console.log('Previous button clicked');
                currentStep--;
                showStep(currentStep);
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        // Submit button
        if (submitBtn) {
            submitBtn.addEventListener('click', async () => {
                if (DEBUG_MODE) console.log('Submit button clicked');
                
                // Check if API functions are available
                if (!window.createDentistAccountWithImage || !window.createDentistRecordWithImage) {
                    console.error('API functions not available');
                    showErrors(['System error: Required API scripts not loaded. Please refresh the page.']);
                    return;
                }
                
                if (!validateStep(currentStep)) {
                    return;
                }

                const formData = collectFormData();
                
                const originalBtnContent = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';

                try {
                    showProgress("Step 1/2: Creating user account...");

                    // Prepare FormData for account creation (includes account profile picture)
                    const accountFormData = new FormData();
                    accountFormData.append('first_name', formData.firstName);
                    accountFormData.append('last_name', formData.lastName);
                    accountFormData.append('login_email', formData.loginEmail);
                    accountFormData.append('contact_email', formData.email);
                    accountFormData.append('password', formData.password);
                    
                    // Add account profile picture if exists (for users_tb.profile_picture)
                    if (formData.accountProfilePicture) {
                        accountFormData.append('profile_picture', formData.accountProfilePicture);
                    }

                    // Call the account creation API
                    const accountResult = await window.createDentistAccountWithImage(accountFormData);
                    const userId = accountResult.dentist.user_id;

                    showProgress("Step 2/2: Creating dentist professional record...");

                    // Prepare FormData for dentist record (includes professional profile picture)
                    const dentistFormData = new FormData();
                    dentistFormData.append('user_id', userId);
                    dentistFormData.append('firstName', formData.firstName);
                    dentistFormData.append('lastName', formData.lastName);
                    dentistFormData.append('dateOfBirth', formData.dateOfBirth);
                    dentistFormData.append('gender', formData.gender);
                    dentistFormData.append('phone', formData.phone);
                    dentistFormData.append('email', formData.email);
                    dentistFormData.append('address', formData.address);
                    dentistFormData.append('licenseNumber', formData.licenseNumber);
                    dentistFormData.append('specialization', formData.specialization);
                    dentistFormData.append('education', formData.education);
                    dentistFormData.append('notes', formData.notes || '');
                    dentistFormData.append('linkedin', formData.linkedin || '');
                    dentistFormData.append('facebook', formData.facebook || '');
                    dentistFormData.append('instagram', formData.instagram || '');
                    dentistFormData.append('tiktok', formData.tiktok || '');
                    dentistFormData.append('youtube', formData.youtube || '');
                    dentistFormData.append('startDate', formData.startDate);
                    dentistFormData.append('position', formData.position);
                    dentistFormData.append('workingDays', JSON.stringify(formData.workingDays));
                    dentistFormData.append('startTime', formData.startTime);
                    dentistFormData.append('endTime', formData.endTime);
                    
                    // Add professional picture if exists (for dentists_tb.professional_photo)
                    if (formData.professionalPicture) {
                        dentistFormData.append('professional_photo', formData.professionalPicture);
                    }

                    // Call the dentist record creation API
                    await window.createDentistRecordWithImage(dentistFormData);

                    showSuccess("Dentist account and professional record created successfully! Redirecting...");

                    setTimeout(() => {
                        window.location.href = "../admin-ui/admin-main.php#../admin-ui/admin-subfolder/admin-dentist-management.html";
                    }, 2000);

                } catch (error) {
                    console.error("Registration failed:", error.message);
                    showErrors([error.message || "An error occurred. Please try again."]);
                    
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnContent;
                }
            });
        }

        // Remove validation errors on input
        document.querySelectorAll('input, select, textarea').forEach(input => {
            input.addEventListener('input', () => {
                input.classList.remove('is-invalid');
            });

            input.addEventListener('change', () => {
                input.classList.remove('is-invalid');
            });
        });

        // Collect form data
        function collectFormData() {
            const section1 = document.getElementById('section-1');
            const section4 = document.getElementById('section-4');
            
            const workingDays = Array.from(document.querySelectorAll('input[name="workingDays"]:checked'))
                .map(cb => cb.value);

            // Get profile picture files
            const professionalPictureFile = document.getElementById('professionalPicture')?.files[0] || null;
            const accountProfilePictureFile = document.getElementById('accountProfilePicture')?.files[0] || null;

            return {
                firstName: section1?.querySelector('#firstName')?.value.trim() || '',
                lastName: section1?.querySelector('#lastName')?.value.trim() || '',
                dateOfBirth: document.getElementById('dateOfBirth')?.value || '',
                gender: document.getElementById('gender')?.value || '',
                phone: document.getElementById('phone')?.value.trim() || '',
                email: section1?.querySelector('#email')?.value.trim() || '',
                address: document.getElementById('address')?.value.trim() || '',
                licenseNumber: document.getElementById('licenseNumber')?.value.trim() || '',
                specialization: document.getElementById('specialization')?.value.trim() || '',
                education: document.getElementById('education')?.value.trim() || '',
                notes: document.getElementById('notes')?.value.trim() || '',
                linkedin: document.getElementById('linkedin')?.value.trim() || '',
                facebook: document.getElementById('facebook')?.value.trim() || '',
                instagram: document.getElementById('instagram')?.value.trim() || '',
                tiktok: document.getElementById('tiktok')?.value.trim() || '',
                youtube: document.getElementById('youtube')?.value.trim() || '',
                startDate: document.getElementById('startDate')?.value || '',
                position: document.getElementById('position')?.value || '',
                workingDays: workingDays,
                startTime: document.getElementById('startTime')?.value || '',
                endTime: document.getElementById('endTime')?.value || '',
                loginEmail: section4?.querySelector('#loginEmail')?.value.trim() || '',
                password: section4?.querySelector('#password')?.value.trim() || '',
                professionalPicture: professionalPictureFile,
                accountProfilePicture: accountProfilePictureFile
            };
        }
    }

    // ==================== GLOBAL INITIALIZATION ====================
    window.initAdminDentistRegister = function() {
        if (DEBUG_MODE) console.log('Initializing Dentist Registration System');
        
        // Wait for API scripts to load before initializing form
        waitForAPIs(() => {
            if (DEBUG_MODE) console.log('API scripts loaded, initializing form');
            setupAutoGeneration();
            showPasswordToggle();
            setupProfilePictureUpload();
            initMultiStepNavigation();
        });
    };

    // ==================== DOM READY INITIALIZATION ====================
    // Removed automatic DOMContentLoaded initialization to prevent double initialization
    // The page is initialized by admin-main.js calling window.initAdminDentistRegister()
    if (DEBUG_MODE) {
        console.log('Dentist Registration Form Logic Loaded');
    }

})();