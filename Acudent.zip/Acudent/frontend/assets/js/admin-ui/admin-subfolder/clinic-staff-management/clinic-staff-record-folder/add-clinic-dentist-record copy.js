function initAdminAddDentistRecord() {
    proceedToNextStep();
    setupAutoGeneration();
    showPaswordToggle();
    setupAutoGenerationSection2();
}

function showPaswordToggle() { const toggleIcons = document.querySelectorAll('.toggle-password');
    
    toggleIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            // Find the password input (previous sibling)
            const passwordInput = this.previousElementSibling;
            
            // Toggle the type attribute
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            }
        });
    });
}

function setupAutoGenerationSection2() {
    // Section 1 inputs
    const firstNameInput = document.querySelector('#section-1 #firstName');
    const lastNameInput = document.querySelector('#section-1 #lastName');
    const emailInput = document.querySelector('#section-1 #email');
    const loginEmailInput = document.getElementById('loginEmail');
    const passwordInput = document.getElementById('password');

    // Section 2 inputs
    const firstName2Input = document.querySelector('#section-2 #firstName');
    const lastName2Input = document.querySelector('#section-2 #lastName');
    const email2Input = document.querySelector('#section-2 #email');

    // Make login email and password read-only
    if (loginEmailInput) loginEmailInput.readOnly = true;
    if (passwordInput) passwordInput.readOnly = true;

    // Auto-fill First Name from Section 1 to Section 2
    if (firstNameInput && firstName2Input) {
        firstNameInput.addEventListener('input', () => {
            firstName2Input.value = firstNameInput.value;
        });
    }

    // Auto-fill Last Name and generate credentials
    if (lastNameInput) {
        lastNameInput.addEventListener('input', () => {
            const lastName = lastNameInput.value.trim();
            
            // Auto-fill Last Name to Section 2
            if (lastName2Input) {
                lastName2Input.value = lastNameInput.value;
            }
            
            if (lastName) {
                // Generate login email: dentistLastName@mapru.com
                const generatedEmail = `dentist${lastName}@mapru.com`;
                loginEmailInput.value = generatedEmail;

                // Generate password: @mapruDentistLastName
                const generatedPassword = `@mapruDentist${lastName}`;
                passwordInput.value = generatedPassword;
            } else {
                // Clear if last name is empty
                loginEmailInput.value = '';
                passwordInput.value = '';
            }
        });
    }

    // Auto-fill Contact Email from Section 1 to Section 2
    if (emailInput && email2Input) {
        emailInput.addEventListener('input', () => {
            email2Input.value = emailInput.value;
        });
    }
}

function setupAutoGeneration() {
    const lastNameInput = document.getElementById('lastName');
    const loginEmailInput = document.getElementById('loginEmail');
    const passwordInput = document.getElementById('password');
    // const confirmPasswordInput = document.getElementById('confirmPassword');

    // Make login email and password read-only
    if (loginEmailInput) loginEmailInput.readOnly = true;
    if (passwordInput) passwordInput.readOnly = true;

    // Auto-generate when last name changes
    if (lastNameInput) {
        lastNameInput.addEventListener('input', () => {
            const lastName = lastNameInput.value.trim();
            
            if (lastName) {
                // Generate login email: dentistLastName@mapru.com
                const generatedEmail = `dentist${lastName}@mapru.com`;
                loginEmailInput.value = generatedEmail;

                // Generate password: mapruDentistLastName
                const generatedPassword = `@mapruDentist${lastName}`;
                passwordInput.value = generatedPassword;
            } else {
                // Clear if last name is empty
                loginEmailInput.value = '';
                passwordInput.value = '';
            }
        });
    }
}

function proceedToNextStep() {
    let currentStep = 1;
    const totalSteps = 5;

    // ===================== ELEMENTS =====================
    const sections = document.querySelectorAll('.input-process-container');
    const circleBorders = document.querySelectorAll('.circle-border');
    const filledLine = document.getElementById('filled-line');

    const nextBtn = document.getElementById('nextBtn');
    const prevBtn = document.getElementById('prevBtn');
    const submitBtn = document.getElementById('submitBtn');

    if (!sections.length) return; // SPA safety

    // ===================== INIT =====================
    showStep(currentStep);

    // ===================== FUNCTIONS =====================

    function showStep(step) {
        sections.forEach(section => section.style.display = 'none');
        sections[step - 1].style.display = 'block';

        updateProgressBar(step);
        updateButtons(step);
    }

    function updateProgressBar(step) {
        // Update circles with 'active' class instead of bg-success/bg-danger
        circleBorders.forEach((border, index) => {
            if (index < step) {
                border.classList.add('active');
            } else {
                border.classList.remove('active');
            }
        });

        // Update progress line (horizontal)
        const percentage = ((step - 1) / (totalSteps - 1)) * 100;
        filledLine.style.width = percentage + '%';
    }

    function updateButtons(step) {
        prevBtn.style.display = step === 1 ? 'none' : 'inline-block';
        nextBtn.style.display = step === totalSteps ? 'none' : 'inline-block';
        submitBtn.style.display = step === totalSteps ? 'inline-block' : 'none';
    }

    function validateStep(step) {
        let isValid = true;
        const currentSection = sections[step - 1];
        const inputs = currentSection.querySelectorAll('input[required], select[required], textarea[required]');

        // Clear old errors
        currentSection.querySelectorAll('.invalid-feedback').forEach(e => e.remove());
        currentSection.querySelectorAll('.is-invalid').forEach(e => e.classList.remove('is-invalid'));

        for (const input of inputs) {
            if (input.type !== 'checkbox' && !input.value.trim()) {
                isValid = false;
                input.classList.add('is-invalid');
                input.reportValidity(); // Show tooltip on first invalid field
                input.focus(); // Optional: focus on it
                break; // Stop checking after first invalid field
            }
        }

        // Mark remaining invalid fields without tooltip
        if (!isValid) {
            inputs.forEach(input => {
                if (input.type !== 'checkbox' && !input.value.trim()) {
                    input.classList.add('is-invalid');
                }
            });
        }

        // ---- Step 1: Password length (auto-generated, should always be valid) ----
   

        // ---- Step 3: Working Days (checkbox group) ----
        if (step === 3) {
            const checkboxes = currentSection.querySelectorAll('input[name="workingDays"]');
            const checked = [...checkboxes].some(cb => cb.checked);

            if (!checked && checkboxes.length) {
                isValid = false;
                markInvalid(checkboxes[0], 'Select at least one working day');
            }
        }

        ---- Step 5: Confirm Password ----
        if (step === 5) {
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirmPassword');

            if (password && confirmPassword && password.value !== confirmPassword.value) {
                isValid = false;
                markInvalid(confirmPassword, 'Passwords do not match');
            }
        }

        return isValid;
    }

    function markInvalid(input, message) {
        input.classList.add('is-invalid');

        const error = document.createElement('div');
        error.className = 'invalid-feedback d-block';
        error.textContent = message;

        input.parentElement.appendChild(error);
    }

    // ===================== EVENTS =====================

    nextBtn.addEventListener('click', () => {
        if (validateStep(currentStep)) {
            currentStep++;
            showStep(currentStep);
        }
    });

    prevBtn.addEventListener('click', () => {
        currentStep--;
        showStep(currentStep);
    });

    submitBtn.addEventListener('click', (e) => {
        e.preventDefault();

        if (!validateStep(currentStep)) return;

        const formData = {
            firstName: getVal('firstName'),
            lastName: getVal('lastName'),
            loginEmail: getVal('loginEmail'),
            email: getVal('email'),
            password: getVal('password'),

            dateOfBirth: getVal('dateOfBirth'),
            gender: getVal('gender'),
            phone: getVal('phone'),
            licenseNumber: getVal('licenseNumber'),
            address: getVal('address'),

            startDate: getVal('startDate'),
            position: getVal('position'),
            workingDays: [...document.querySelectorAll('input[name="workingDays"]:checked')].map(cb => cb.value),
            startTime: getVal('startTime'),
            endTime: getVal('endTime'),

            specialization: getVal('specialization'),
            education: getVal('education'),
            notes: getVal('notes')
        };

        console.log('Submitted:', formData);
        alert('Dentist record created successfully!');
    });

    // Remove error on input
    document.querySelectorAll('input, select, textarea').forEach(input => {
        input.addEventListener('input', () => {
            input.classList.remove('is-invalid');
            const error = input.parentElement.querySelector('.invalid-feedback');
            if (error) error.remove();
        });
    });

    function getVal(id) {
        const el = document.getElementById(id);
        return el ? el.value.trim() : '';
    }
}



// ===================== INITIALIZATION =====================
document.addEventListener('DOMContentLoaded', initAdminAddDentistRecord);

document.addEventListener('DOMContentLoaded', function() {
    // Get all toggle password icons
   
});