// ===================== ADMIN FRONTDESK MANAGEMENT PAGE HANDLER =====================
// Handles frontdesk listing page with tile/list view toggle and data loading

// ===================== PREVENT MULTIPLE INITIALIZATIONS =====================
if (window.frontdeskManagementLoaded) {
    console.log('Frontdesk Management already loaded, skipping...');
} else {
    window.frontdeskManagementLoaded = true;
    
    initAdminStaffFrontdeskManagement();
}

// ===================== INITIALIZE FRONTDESK MANAGEMENT =====================
function initAdminStaffFrontdeskManagement() {
    const page = document.querySelector('#admin-staff-frontdesk-page-id');
    if (!page) {
        console.log('Frontdesk page not found in DOM');
        return;
    }
    
    console.log('Frontdesk Management initialized ✅');

    // ===================== INITIALIZE VIEW TOGGLE ===================== //
    const toggleButtons = document.querySelectorAll('.toggle-button');
    const sections = document.querySelectorAll('.profile-box-main-container');

    if (!toggleButtons.length || !sections.length) {
        console.warn('No toggle elements found.');
        return;
    }

    // ===================== TOGGLE MENU / LIST VIEW ===================== //
    toggleButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.getAttribute('data-target');
            const targetSection = document.getElementById(targetId);

            if (!targetSection) return;

            // Hide all sections
            sections.forEach(section => section.classList.add('hidden'));
            // Show selected section
            targetSection.classList.remove('hidden');

            // Update button styles
            toggleButtons.forEach(b => b.classList.remove('active-tab'));
            btn.classList.add('active-tab');

            // Load data for the active view
            if (targetId === 'record-tile-view-id') {
                loadFrontdeskTileView();
            } else if (targetId === 'record-list-view-id') {
                loadFrontdeskListView();
            }
        });
    });

    // ===================== SEARCH FUNCTIONALITY ===================== //
    const searchBar = document.querySelector('.record-searchbar');
    if (searchBar) {
        searchBar.addEventListener('input', debounce(function() {
            const activeView = document.querySelector('.profile-box-main-container:not(.hidden)');
            if (activeView && activeView.id === 'record-tile-view-id') {
                loadFrontdeskTileView();
            } else if (activeView && activeView.id === 'record-list-view-id') {
                loadFrontdeskListView();
            }
        }, 500));
    }

    // ===================== FILTER DROPDOWN ===================== //
    const filterBtn = document.getElementById('filterDropdownBtn');
    const filterMenu = document.getElementById('filterDropdownMenu');
    
    if (filterBtn && filterMenu) {
        filterBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            const isVisible = filterMenu.style.display === 'block';
            filterMenu.style.display = isVisible ? 'none' : 'block';
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!filterBtn.contains(event.target) && !filterMenu.contains(event.target)) {
                filterMenu.style.display = 'none';
            }
        });
    }

    // ===================== FILTER OPTIONS ===================== //
    const filterOptions = document.querySelectorAll('.filter-option');
    filterOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Update active state
            filterOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            
            // Close dropdown
            if (filterMenu) {
                filterMenu.style.display = 'none';
            }

            // Reload data with new filter
            const activeView = document.querySelector('.profile-box-main-container:not(.hidden)');
            if (activeView && activeView.id === 'record-tile-view-id') {
                loadFrontdeskTileView();
            } else if (activeView && activeView.id === 'record-list-view-id') {
                loadFrontdeskListView();
            }
        });
    });

    // ===================== ADD NEW FRONTDESK BUTTON ===================== //
    const staffAddnewRecord = document.querySelectorAll('.add-user-btn');
    staffAddnewRecord.forEach(box => {
        box.addEventListener('click', () => {
            const url = box.getAttribute('data-page');
            if (!url) return;

            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });

    // ===================== LOAD INITIAL DATA ===================== //
    // Load tile view by default - only after API is confirmed ready
    if (typeof window.getAllFrontdesk === 'function') {
        loadFrontdeskTileView();
    } else {
        console.warn('⚠️ API check passed but function not available, showing error');
        showErrorInViews('Failed to initialize. Please refresh the page.');
    }
}

// ===================== LOAD FRONTDESK - TILE VIEW ===================== //
async function loadFrontdeskTileView() {
    const container = document.querySelector('.profile-box-container');
    
    if (!container) {
        console.error('❌ Tile view container not found');
        return;
    }

    try {
        // Show loading state
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3 text-muted">Loading frontdesk staff...</p>
            </div>
        `;

        // ✅ VERIFY API IS AVAILABLE
        if (typeof window.getAllFrontdesk !== 'function') {
            throw new Error('Frontdesk API is not available');
        }

        // Get search value
        const searchValue = document.querySelector('.record-searchbar')?.value || '';
        
        // Get active filter
        const activeFilter = document.querySelector('.filter-option.active')?.dataset.filter || 'alphabetical';
        
        // Fetch frontdesk staff
        const response = await window.getAllFrontdesk({
            search: searchValue,
            order_by: activeFilter
        });

        const frontdeskStaff = response.data || [];
        
        // Clear loading state and existing content
        container.innerHTML = '';

        // Check if frontdesk staff exist
        if (frontdeskStaff.length === 0) {
            container.innerHTML = `
                <div class="col-12 text-center py-5">
                    <i class="fa-solid fa-inbox fa-3x mb-3 text-muted"></i>
                    <p class="text-muted">No frontdesk staff found.</p>
                </div>
            `;
            updateCountDisplay(0, 0);
            return;
        }

        // Loop through frontdesk staff and create cards
        frontdeskStaff.forEach(staff => {
            const formatted = window.formatFrontdeskForDisplay(staff);
            const profilePicture = window.getFrontdeskProfilePicture(staff);

            const colDiv = document.createElement('div');
            colDiv.className = 'col-12 col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-sm-6 col-profile-box';
            
            colDiv.innerHTML = `
                <div class="profile-box" tabindex="0"
                    data-page="../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management-detailed.html"
                    data-id="${formatted.id}">
                    <div class="record-img-container">
                        <img data-id="profile-img-id" src="${profilePicture}" alt="${formatted.name}">
                    </div>
                    <div class="info-container">
                        <h3 data-id="information-frontdesk-record-name-id">${formatted.name}</h3>
                        <span data-id="information-frontdesk-record-fID-id">${formatted.code}</span>
                    </div>
                </div>
            `;
            
            container.appendChild(colDiv);
        });

        // Add click handlers to new boxes
        attachFrontdeskBoxHandlers();

        // Update count display
        updateCountDisplay(frontdeskStaff.length, response.total_count);

    } catch (error) {
        console.error('❌ Error loading frontdesk staff (Tile View):', error);
        
        // Show error state
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load frontdesk staff. Please try again.</p>
                <button class="btn btn-primary mt-3" onclick="loadFrontdeskTileView()">
                    <i class="fa-solid fa-rotate-right me-2"></i>Retry
                </button>
            </div>
        `;
        
        updateCountDisplay(0, 0);
        showError('Failed to load frontdesk staff. Please try again.');
    }
}

// ===================== LOAD FRONTDESK - LIST VIEW ===================== //
async function loadFrontdeskListView() {
    const tbody = document.getElementById('list-view-body-id');
    
    if (!tbody) {
        console.error('❌ List view tbody not found');
        return;
    }

    try {
        // Show loading state
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-3 text-muted">Loading frontdesk staff...</p>
                </td>
            </tr>
        `;

        // ✅ VERIFY API IS AVAILABLE
        if (typeof window.getAllFrontdesk !== 'function') {
            throw new Error('Frontdesk API is not available');
        }

        // Get search value
        const searchValue = document.querySelector('.record-searchbar')?.value || '';
        
        // Get active filter
        const activeFilter = document.querySelector('.filter-option.active')?.dataset.filter || 'alphabetical';
        
        // Fetch frontdesk staff
        const response = await window.getAllFrontdesk({
            search: searchValue,
            order_by: activeFilter
        });

        const frontdeskStaff = response.data || [];
        
        // Clear loading state and existing content
        tbody.innerHTML = '';

        // Check if frontdesk staff exist
        if (frontdeskStaff.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-5">
                        <i class="fa-solid fa-inbox fa-3x mb-3 text-muted"></i>
                        <p class="text-muted">No frontdesk staff found.</p>
                    </td>
                </tr>
            `;
            updateCountDisplay(0, 0);
            return;
        }

        // Loop through frontdesk staff and create rows
        frontdeskStaff.forEach(staff => {
            const formatted = window.formatFrontdeskForDisplay(staff);

            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${formatted.name}</td>
                <td>${formatted.code}</td>
                <td>${formatted.email}</td>
                <td>${formatted.phone}</td>
                <td>
                    <div class="appointment-td-wrapper d-flex flex-row align-items-center">
                        <button type="button" class="td-view-button"
                            data-page="../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management-detailed.html"
                            data-id="${formatted.id}">
                            View Details
                        </button>
                    </div>
                </td>
            `;
            
            tbody.appendChild(row);
        });

        // Add click handlers to view buttons
        attachViewButtonHandlers();

        // Update count display
        updateCountDisplay(frontdeskStaff.length, response.total_count);

    } catch (error) {
        console.error('❌ Error loading frontdesk staff (List View):', error);
        
        // Show error state
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5">
                    <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                    <p class="text-danger">Failed to load frontdesk staff. Please try again.</p>
                    <button class="btn btn-primary mt-3" onclick="loadFrontdeskListView()">
                        <i class="fa-solid fa-rotate-right me-2"></i>Retry
                    </button>
                </td>
            </tr>
        `;
        
        updateCountDisplay(0, 0);
        showError('Failed to load frontdesk staff. Please try again.');
    }
}

// ===================== ATTACH HANDLERS TO FRONTDESK BOXES (TILE VIEW) ===================== //
function attachFrontdeskBoxHandlers() {
    const frontdeskBoxes = document.querySelectorAll('.profile-box');
    frontdeskBoxes.forEach(box => {
        box.addEventListener('click', () => {
            const url = box.getAttribute('data-page');
            if (!url) return;
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

// ===================== ATTACH HANDLERS TO VIEW BUTTONS (LIST VIEW) ===================== //
function attachViewButtonHandlers() {
    const viewButtons = document.querySelectorAll('.td-view-button');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

// ===================== UPDATE COUNT DISPLAY ===================== //
function updateCountDisplay(showing, total) {
    const countShowHeader = document.querySelector('.count-show-header');
    if (countShowHeader) {
        countShowHeader.textContent = `Showing ${showing} of ${total}`;
    }
}

// ===================== SHOW ERROR IN VIEWS ===================== //
function showErrorInViews(message) {
    // Show error in tile view
    const tileContainer = document.querySelector('.profile-box-container');
    if (tileContainer) {
        tileContainer.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">${message}</p>
            </div>
        `;
    }
    
    // Show error in list view
    const listContainer = document.getElementById('list-view-body-id');
    if (listContainer) {
        listContainer.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5">
                    <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                    <p class="text-danger">${message}</p>
                </td>
            </tr>
        `;
    }
    
    updateCountDisplay(0, 0);
}

// ===================== DEBOUNCE HELPER ===================== //
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ===================== SHOW ERROR MESSAGE ===================== //
function showError(message) {
    console.error('Error:', message);
    
    if (typeof window.showToast === 'function') {
        window.showToast('error', message);
    } else {
        alert(message);
    }
}

// ===================== CLEANUP ON PAGE CHANGE =====================
window.cleanupFrontdeskManagement = function() {
    delete window.frontdeskManagementLoaded;
};