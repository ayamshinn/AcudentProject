
function initAdminAddStaffRecord() {
    setupAutoGeneration();
    showPasswordToggle();
    initMultiStepNavigation();
}

// ==================== PASSWORD TOGGLE ====================
function showPasswordToggle() {
    const toggleIcons = document.querySelectorAll('.toggle-password');
    
    toggleIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            const passwordInput = this.previousElementSibling;
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            }
        });
    });
}

// ==================== AUTO-GENERATION ====================
function setupAutoGeneration() {
    const lastNameInput = document.getElementById('lastName');
    const loginEmailInput = document.getElementById('loginEmail');
    const passwordInput = document.getElementById('password');

    if (loginEmailInput) loginEmailInput.readOnly = true;
    if (passwordInput) passwordInput.readOnly = true;

    if (lastNameInput) {
        lastNameInput.addEventListener('input', () => {
            const lastName = lastNameInput.value.trim();
            
            if (lastName) {
                loginEmailInput.value = `dentist${lastName}@mapru.com`;
                passwordInput.value = `@mapruDentist${lastName}`;
            } else {
                loginEmailInput.value = '';
                passwordInput.value = '';
            }
        });
    }
}

// ==================== MULTI-STEP NAVIGATION ====================
function initMultiStepNavigation() {
    let currentStep = 1;
    const totalSteps = 2;

    const sections = document.querySelectorAll('.input-process-container');
    const circleBorders = document.querySelectorAll('.circle-border');
    const filledLine = document.getElementById('filled-line');
    const nextBtn = document.getElementById('nextBtn');
    const prevBtn = document.getElementById('prevBtn');
    const submitBtn = document.getElementById('submitBtn');

    if (!sections.length) return;

    showStep(currentStep);

    function showStep(step) {
        sections.forEach(section => section.style.display = 'none');
        sections[step - 1].style.display = 'block';
        updateProgressBar(step);
        updateButtons(step);
    }

    function updateProgressBar(step) {
        circleBorders.forEach((border, index) => {
            if (index < step) {
                border.classList.add('active');
            } else {
                border.classList.remove('active');
            }
        });

        const percentage = ((step - 1) / (totalSteps - 1)) * 100;
        filledLine.style.width = percentage + '%';
    }

    function updateButtons(step) {
        prevBtn.style.display = step === 1 ? 'none' : 'inline-block';
        nextBtn.style.display = step === totalSteps ? 'none' : 'inline-block';
        submitBtn.style.display = step === totalSteps ? 'inline-block' : 'none';
    }

    function validateStep(step) {
        let isValid = true;
        const currentSection = sections[step - 1];
        const inputs = currentSection.querySelectorAll('input[required], select[required], textarea[required]');

        // Clear old errors
        currentSection.querySelectorAll('.invalid-feedback').forEach(e => e.remove());
        currentSection.querySelectorAll('.is-invalid').forEach(e => e.classList.remove('is-invalid'));

        for (const input of inputs) {
            if (input.type !== 'checkbox' && !input.value.trim()) {
                isValid = false;
                input.classList.add('is-invalid');
                input.reportValidity();
                input.focus();
                break;
            }
        }

        if (!isValid) {
            inputs.forEach(input => {
                if (input.type !== 'checkbox' && !input.value.trim()) {
                    input.classList.add('is-invalid');
                }
            });
        }

        // Step 2: Verify checkbox
        if (step === 2) {
            const agreeCheckbox = document.getElementById('agreeTerms');
            if (agreeCheckbox && !agreeCheckbox.checked) {
                isValid = false;
                markInvalid(agreeCheckbox, 'You must confirm the information is accurate');
            }
        }

        return isValid;
    }

    function markInvalid(input, message) {
        input.classList.add('is-invalid');
        const error = document.createElement('div');
        error.className = 'invalid-feedback d-block';
        error.textContent = message;
        input.parentElement.appendChild(error);
    }

    // ==================== NAVIGATION EVENTS ====================
    nextBtn.addEventListener('click', () => {
        if (validateStep(currentStep)) {
            currentStep++;
            showStep(currentStep);
        }
    });

    prevBtn.addEventListener('click', () => {
        currentStep--;
        showStep(currentStep);
    });

    // Real-time error removal
    document.querySelectorAll('input, select, textarea').forEach(input => {
        input.addEventListener('input', () => {
            input.classList.remove('is-invalid');
            const error = input.parentElement.querySelector('.invalid-feedback');
            if (error) error.remove();
        });
    });
}

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', () => {
    initAdminAddStaffRecord();
});