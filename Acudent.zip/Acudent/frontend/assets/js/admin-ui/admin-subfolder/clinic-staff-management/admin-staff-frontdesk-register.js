// ===================== FRONTDESK REGISTRATION FORM LOGIC =====================
// Handles ONLY: Form UI, validation, navigation, and submission workflow
// REQUIRES: frontdesk-account-api.js and frontdesk-record-api.js to be loaded first
// Tailored to: 4-section HTML form and frontdesk_tb schema

(function() {
    'use strict';

    // ==================== WAIT FOR API SCRIPTS TO LOAD ====================
    function waitForAPIs(callback) {
        const checkAPIs = setInterval(() => {
            if (window.createFrontdeskAccountWithImage && window.createFrontdeskRecord) {
                clearInterval(checkAPIs);
                callback();
            }
        }, 100);
        
        // Timeout after 5 seconds
        setTimeout(() => {
            clearInterval(checkAPIs);
            if (!window.createFrontdeskAccountWithImage || !window.createFrontdeskRecord) {
                console.error('Required API functions not loaded');
                alert('System error: Required API scripts not loaded. Please refresh the page.');
            }
        }, 5000);
    }

    // ==================== AUTO-GENERATION SETUP ====================
    function setupAutoGeneration() {    
        const section1 = document.getElementById('section-1');
        const firstNameInput = section1?.querySelector('#firstName');
        const lastNameInput = section1?.querySelector('#lastName');
        const dateOfBirthInput = section1?.querySelector('#dateOfBirth');
        const emailInputSection1 = section1?.querySelector('#email');
        
        const section3 = document.getElementById('section-3'); // Account section
        const loginEmailInput = section3?.querySelector('#loginEmail');
        const passwordInput = section3?.querySelector('#password');
        const firstNameInputSection3 = section3?.querySelector('#firstNameAccount');
        const lastNameInputSection3 = section3?.querySelector('#lastNameAccount');
        const emailInputSection3 = section3?.querySelector('#emailAccount');

        if (loginEmailInput) loginEmailInput.readOnly = true;
        if (passwordInput) passwordInput.readOnly = true;
        if (firstNameInputSection3) firstNameInputSection3.readOnly = true;
        if (lastNameInputSection3) lastNameInputSection3.readOnly = true;
        if (emailInputSection3) emailInputSection3.readOnly = true;

        function updateAccountInfo() {
            if (!firstNameInput || !lastNameInput || !loginEmailInput || !passwordInput) {
                return;
            }

            const firstName = firstNameInput.value.trim();
            const lastName = lastNameInput.value.trim();
            const dateOfBirth = dateOfBirthInput?.value || '';
            const email = emailInputSection1?.value.trim() || '';
            
            if (firstNameInputSection3) {
                firstNameInputSection3.value = firstName;
            }
            if (lastNameInputSection3) {
                lastNameInputSection3.value = lastName;
            }
            
            if (emailInputSection3) {
                emailInputSection3.value = email;
            }
            
            if (lastName) {
                loginEmailInput.value = `frontdesk${lastName}@mapru.com`;
            } else {
                loginEmailInput.value = '';
            }
            
            if (lastName && dateOfBirth) {
                const date = new Date(dateOfBirth);
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                const year = date.getFullYear();
                const birthday = `${month}${day}${year}`;
                
                passwordInput.value = `@mapru${lastName}${birthday}`;
            } else if (lastName) {
                passwordInput.value = `@mapru${lastName}`;
            } else {
                passwordInput.value = '';
            }
        }

        if (firstNameInput) {
            firstNameInput.addEventListener('input', updateAccountInfo);
        }
        
        if (lastNameInput) {
            lastNameInput.addEventListener('input', updateAccountInfo);
        }
        
        if (dateOfBirthInput) {
            dateOfBirthInput.addEventListener('input', updateAccountInfo);
        }
        
        if (emailInputSection1) {
            emailInputSection1.addEventListener('input', updateAccountInfo);
        }
    }

    // ==================== PASSWORD TOGGLE ====================
    function showPasswordToggle() {
        const toggleIcons = document.querySelectorAll('.toggle-password');
        
        toggleIcons.forEach(icon => {
            icon.addEventListener('click', function() {
                const container = this.parentElement;
                const passwordInput = container.querySelector('input[type="password"], input[type="text"]');
                
                if (passwordInput) {
                    if (passwordInput.type === 'password') {
                        passwordInput.type = 'text';
                        this.classList.remove('fa-eye');
                        this.classList.add('fa-eye-slash');
                    } else {
                        passwordInput.type = 'password';
                        this.classList.remove('fa-eye-slash');
                        this.classList.add('fa-eye');
                    }
                }
            });
        });
    }

    // ==================== PROFILE PICTURE UPLOAD HANDLING ====================
    function setupProfilePictureUpload() {
        // Section 3: Account Profile Picture (for system account - users_tb)
        const accountProfilePictureInput = document.getElementById('accountProfilePicture');
        const uploadAccountProfileBtn = document.getElementById('uploadAccountProfileBtn');
        const removeAccountProfileBtn = document.getElementById('removeAccountProfileBtn');
        const accountProfileImagePreview = document.getElementById('accountProfileImagePreview');
        const accountDefaultIcon = document.getElementById('accountDefaultIcon');

        // Account Profile Picture Upload Handler (System Account)
        if (uploadAccountProfileBtn && accountProfilePictureInput) {
            uploadAccountProfileBtn.addEventListener('click', () => {
                accountProfilePictureInput.click();
            });

            accountProfilePictureInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    // Validate file size (5MB max)
                    if (file.size > 5 * 1024 * 1024) {
                        alert('File size must be less than 5MB');
                        accountProfilePictureInput.value = '';
                        return;
                    }

                    // Validate file type
                    if (!file.type.startsWith('image/')) {
                        alert('Please select an image file (JPG, PNG)');
                        accountProfilePictureInput.value = '';
                        return;
                    }

                    // Preview the image
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        accountProfileImagePreview.src = e.target.result;
                        accountProfileImagePreview.style.display = 'block';
                        accountDefaultIcon.style.display = 'none';
                        removeAccountProfileBtn.style.display = 'inline-block';
                    };
                    reader.readAsDataURL(file);
                }
            });

            // Remove Account Profile Picture
            if (removeAccountProfileBtn) {
                removeAccountProfileBtn.addEventListener('click', () => {
                    accountProfilePictureInput.value = '';
                    accountProfileImagePreview.src = '';
                    accountProfileImagePreview.style.display = 'none';
                    accountDefaultIcon.style.display = 'block';
                    removeAccountProfileBtn.style.display = 'none';
                });
            }
        }
    }

    // ==================== MULTI-STEP NAVIGATION ====================
    function initMultiStepNavigation() {
        let currentStep = 1;
        const totalSteps = 4; // Matches HTML: section-1, section-2, section-3, section-4

        const sections = document.querySelectorAll('.input-process-container');
        const circleBorders = document.querySelectorAll('.circle-border');
        const filledLine = document.getElementById('filled-line');
        const nextBtn = document.getElementById('nextBtn');
        const prevBtn = document.getElementById('prevBtn');
        const submitBtn = document.getElementById('submitBtn');

        if (!sections.length) {
            console.error('No sections found!');
            return;
        }

        console.log(`Found ${sections.length} sections`);

        // Create error container
        let errorContainer = document.querySelector(".frontdesk-error-msg");
        if (!errorContainer) {
            errorContainer = document.createElement("div");
            errorContainer.className = "frontdesk-error-msg";
            errorContainer.style.cssText = "color: #dc3545; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #f8d7da; border: 1px solid #f5c6cb; display: none;";
            
            const formContainer = document.querySelector('.appointment-add-staff-record-inner');
            if (formContainer) {
                formContainer.insertBefore(errorContainer, formContainer.firstChild);
            }
        }

        // Create success container
        let successContainer = document.querySelector(".frontdesk-success-msg");
        if (!successContainer) {
            successContainer = document.createElement("div");
            successContainer.className = "frontdesk-success-msg";
            successContainer.style.cssText = "color: #155724; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #d4edda; border: 1px solid #c3e6cb; display: none;";
            
            const formContainer = document.querySelector('.appointment-add-staff-record-inner');
            if (formContainer) {
                formContainer.insertBefore(successContainer, formContainer.firstChild);
            }
        }

        showStep(currentStep);

        function showStep(step) {
            console.log(`Showing step ${step}`);
            sections.forEach(section => section.style.display = 'none');
            if (sections[step - 1]) {
                sections[step - 1].style.display = 'block';
            }
            updateProgressBar(step);
            updateButtons(step);
        }

        function updateProgressBar(step) {
            circleBorders.forEach((border, index) => {
                if (index < step) {
                    border.classList.add('active');
                } else {
                    border.classList.remove('active');
                }
            });

            const percentage = ((step - 1) / (totalSteps - 1)) * 100;
            if (filledLine) {
                filledLine.style.width = percentage + '%';
            }
        }

        function updateButtons(step) {
            if (prevBtn) prevBtn.style.display = step === 1 ? 'none' : 'inline-block';
            if (nextBtn) nextBtn.style.display = step === totalSteps ? 'none' : 'inline-block';
            if (submitBtn) submitBtn.style.display = step === totalSteps ? 'inline-block' : 'none';
        }

        function validateStep(step) {
            const currentSection = sections[step - 1];
            if (!currentSection) return false;

            const inputs = currentSection.querySelectorAll('input[required], select[required], textarea[required]');
            let isValid = true;
            let firstInvalid = null;

            inputs.forEach(input => {
                if (input.type === 'checkbox') return;
                if (input.readOnly) return;
                
                if (!input.checkValidity()) {
                    input.classList.add('is-invalid');
                    isValid = false;
                    if (!firstInvalid) {
                        firstInvalid = input;
                    }
                } else {
                    input.classList.remove('is-invalid');
                }
            });

            // Validate working days in section-2
            if (step === 2) {
                const workingDays = currentSection.querySelectorAll('input[name="workingDays"]:checked');
                if (workingDays.length === 0) {
                    alert('Please select at least one working day');
                    isValid = false;
                }
            }

            // Validate terms checkbox in section-4 (last step)
            if (step === 4) {
                const agreeCheckbox = document.getElementById('agreeTerms');
                if (agreeCheckbox && !agreeCheckbox.checked) {
                    agreeCheckbox.classList.add('is-invalid');
                    if (!firstInvalid) {
                        firstInvalid = agreeCheckbox;
                    }
                    isValid = false;
                } else if (agreeCheckbox) {
                    agreeCheckbox.classList.remove('is-invalid');
                }
            }

            if (!isValid && firstInvalid) {
                firstInvalid.reportValidity();
                firstInvalid.focus();
            }

            return isValid;
        }

        function showErrors(errors) {
            if (errors.length === 0) {
                errorContainer.style.display = "none";
                return;
            }

            let errorHTML = "<strong><i class='fa-solid fa-circle-exclamation'></i> Please fix the following errors:</strong><ul style='margin: 8px 0 0 20px; padding-left: 0;'>";
            errors.forEach(error => {
                errorHTML += `<li style='margin: 4px 0;'>${error}</li>`;
            });
            errorHTML += "</ul>";

            errorContainer.innerHTML = errorHTML;
            errorContainer.style.display = "block";
            successContainer.style.display = "none";
            errorContainer.scrollIntoView({ behavior: "smooth", block: "center" });
        }

        function showSuccess(message) {
            successContainer.innerHTML = `<strong><i class='fa-solid fa-circle-check'></i> ${message}</strong>`;
            successContainer.style.display = "block";
            errorContainer.style.display = "none";
            successContainer.scrollIntoView({ behavior: "smooth", block: "center" });
        }

        function showProgress(message) {
            successContainer.innerHTML = `<strong><i class='fa-solid fa-spinner fa-spin'></i> ${message}</strong>`;
            successContainer.style.display = "block";
            errorContainer.style.display = "none";
        }

        // Next button
        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                console.log('Next button clicked');
                if (validateStep(currentStep)) {
                    currentStep++;
                    showStep(currentStep);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
            });
        }

        // Previous button
        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                console.log('Previous button clicked');
                currentStep--;
                showStep(currentStep);
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        // Submit button
        if (submitBtn) {
            submitBtn.addEventListener('click', async () => {
                console.log('Submit button clicked');
                
                // Check if API functions are available
                if (!window.createFrontdeskAccountWithImage || !window.createFrontdeskRecord) {
                    console.error('API functions not available');
                    showErrors(['System error: Required API scripts not loaded. Please refresh the page.']);
                    return;
                }
                
                if (!validateStep(currentStep)) {
                    return;
                }

                const formData = collectFormData();
                
                const originalBtnContent = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';

                try {
                    showProgress("Step 1/2: Creating user account...");

                    // Prepare FormData for account creation (includes account profile picture)
                    const accountFormData = new FormData();
                    accountFormData.append('first_name', formData.firstName);
                    accountFormData.append('last_name', formData.lastName);
                    accountFormData.append('login_email', formData.loginEmail);
                    accountFormData.append('contact_email', formData.email);
                    accountFormData.append('password', formData.password);
                    
                    // Add account profile picture if exists (for users_tb.profile_picture)
                    if (formData.accountProfilePicture) {
                        accountFormData.append('profile_picture', formData.accountProfilePicture);
                    }

                    // Call the account creation API
                    const accountResult = await window.createFrontdeskAccountWithImage(accountFormData);
                    const userId = accountResult.frontdesk.user_id;

                    console.log('✅ Account created, User ID:', userId);

                    showProgress("Step 2/2: Creating frontdesk staff record...");

                    // Prepare frontdesk record data (matching database schema)
                    const frontdeskRecordData = {
                        user_id: userId,
                        // For staff_profile_tb
                        firstName: formData.firstName,
                        lastName: formData.lastName,
                        dateOfBirth: formData.dateOfBirth,
                        gender: formData.gender,
                        phone: formData.phone,
                        email: formData.email,
                        address: formData.address,
                        // For frontdesk_tb (only certification and notes exist in schema)
                        certification: formData.certification || null,
                        notes: formData.notes || null,
                        // For staff_base_schedule_tb
                        startDate: formData.startDate,
                        workingDays: formData.workingDays,
                        startTime: formData.startTime,
                        endTime: formData.endTime
                    };

                    // Call the frontdesk record creation API
                    const recordResult = await window.createFrontdeskRecord(frontdeskRecordData);

                    console.log('✅ Frontdesk record created:', recordResult);

                    showSuccess("Frontdesk account and staff record created successfully! Redirecting...");

                    setTimeout(() => {
                        window.location.href = "../admin-ui/admin-main.php#../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-register.html";
                    }, 2000);

                } catch (error) {
                    console.error("❌ Registration error:", error);
                    showErrors([error.message || "An error occurred. Please try again."]);
                    
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnContent;
                }
            });
        }

        // Remove validation errors on input
        document.querySelectorAll('input, select, textarea').forEach(input => {
            input.addEventListener('input', () => {
                input.classList.remove('is-invalid');
            });

            input.addEventListener('change', () => {
                input.classList.remove('is-invalid');
            });
        });

        // Collect form data
        function collectFormData() {
            const section1 = document.getElementById('section-1');
            const section3 = document.getElementById('section-3'); // Account section
            
            const workingDays = Array.from(document.querySelectorAll('input[name="workingDays"]:checked'))
                .map(cb => cb.value);

            // Get account profile picture file
            const accountProfilePictureFile = document.getElementById('accountProfilePicture')?.files[0] || null;

            return {
                // Section 1: Personal Information
                firstName: section1?.querySelector('#firstName')?.value.trim() || '',
                lastName: section1?.querySelector('#lastName')?.value.trim() || '',
                dateOfBirth: document.getElementById('dateOfBirth')?.value || '',
                gender: document.getElementById('gender')?.value || '',
                phone: document.getElementById('phone')?.value.trim() || '',
                email: section1?.querySelector('#email')?.value.trim() || '',
                address: document.getElementById('address')?.value.trim() || '',
                
                // Section 2: Work Schedule
                startDate: document.getElementById('startDate')?.value || '',
                workingDays: workingDays,
                startTime: document.getElementById('startTime')?.value || '',
                endTime: document.getElementById('endTime')?.value || '',
                
                // Section 3: Account Information
                loginEmail: section3?.querySelector('#loginEmail')?.value.trim() || '',
                password: section3?.querySelector('#password')?.value.trim() || '',
                accountProfilePicture: accountProfilePictureFile,
                
                // Optional fields (if they exist in HTML - currently missing)
                certification: document.getElementById('certification')?.value.trim() || null,
                notes: document.getElementById('notes')?.value.trim() || null
            };
        }
    }

    // ==================== GLOBAL INITIALIZATION ====================
    window.initAdminStaffFrontdeskRegister = function() {
        console.log('✅ Initializing Frontdesk Registration System');
        
        // Wait for API scripts to load before initializing form
        waitForAPIs(() => {
            console.log('API scripts loaded, initializing form');
            setupAutoGeneration();
            showPasswordToggle();
            setupProfilePictureUpload();
            initMultiStepNavigation();
        });
    };

    // ==================== DOM READY INITIALIZATION ====================
    document.addEventListener('DOMContentLoaded', () => {
        console.log('✅ Frontdesk Registration Form Logic Loaded');
        if (document.querySelector('.input-process-container')) {
            window.initAdminStaffFrontdeskRegister();
        }
    });

})();