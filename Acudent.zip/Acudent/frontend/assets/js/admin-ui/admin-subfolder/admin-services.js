function initAdminServices() {
    // Fixed selectors
    const addServicesBtn = document.querySelector(".add-services-btn");
    const closeBtn = document.getElementById("close-services-modal");
    const modal = document.getElementById("add-services-modal-container-id");


    // Open modal when button is clicked
    addServicesBtn.addEventListener("click", () => {
        modal.classList.add("active");
    });

    // Close modal when close button is clicked
    closeBtn.addEventListener("click", () => {
        modal.classList.remove("active");
    });

    // Close modal when clicking outside the modal content
    modal.addEventListener("click", (e) => {
        if (e.target === modal) {
            modal.classList.remove("active");
        }
    });

    // Close modal with Escape key
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && modal.classList.contains("active")) {
            modal.classList.remove("active");
        }
    });


    // Toggle functionality
        const toggleButtons = document.querySelectorAll('.toggle-btn');
        const formSections = document.querySelectorAll('.form-section');

        toggleButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                toggleButtons.forEach(btn => btn.classList.remove('active'));
                
                // Add active class to clicked button
                button.classList.add('active');
                
                // Hide all form sections
                formSections.forEach(section => section.classList.remove('active'));
                
                // Show the corresponding form section
                const formId = button.getAttribute('data-form') + '-form';
                document.getElementById(formId).classList.add('active');
            });
        });

        // Close modal functionality
        document.getElementById('close-services-modal').addEventListener('click', () => {
            document.getElementById('add-services-modal-container-id').style.display = 'none';
        });

        // Form submissions
        document.getElementById('mainCategoryForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            console.log('Main Category Form Data:', Object.fromEntries(formData));
            alert('Main Category form submitted! Check console for data.');
        });

        document.getElementById('subcategoryForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            console.log('Subcategory Form Data:', Object.fromEntries(formData));
            alert('Subcategory form submitted! Check console for data.');
        });

        // File input display
        document.getElementById('servicephoto').addEventListener('change', function(e) {
            const fileName = e.target.files[0]?.name || 'Click to upload image';
            const label = document.querySelector('.file-input-label');
            label.innerHTML = `<i class="fa-solid fa-check-circle"></i> ${fileName}`;
        });
}

document.addEventListener('DOMContentLoaded', initAdminServices);