function initAdminStaffManagementDetailed() {
    const page = document.querySelector('#admin-staff-detail-view-page-id');
    if (!page) return;
    console.log('Staff Management Detailed initialized ✅');

    buttons();

}


function buttons() {
    // ===================== BACK TO DENTIST LIST =====================
    const viewButtons = document.querySelectorAll('.patient-view-more-btn');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;

            // Remove the param logic since dentistId is not needed
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });

    const backButtons = document.querySelectorAll('.back-btn');
    backButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;

            // Remove the param logic since dentistId is not needed
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', initAdminStaffManagementDetailed);
