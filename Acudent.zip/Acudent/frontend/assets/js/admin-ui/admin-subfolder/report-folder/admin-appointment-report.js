function initAdminAppointmentReport() {

  const caretWrapper = document.querySelector('.monthly-wrapper-caret-down');
  const caretButton = caretWrapper.querySelector('.inventory-management-caret-button');
  const selectedPeriod = caretWrapper.querySelector('.selected-period');
  const dropdownItems = caretWrapper.querySelectorAll('.monthly-dropdown-item');

  // Toggle dropdown visibility
  caretButton.addEventListener('click', (e) => {
    e.stopPropagation(); // Prevent click from closing dropdown immediately
    caretWrapper.classList.toggle('active');
  });

  // Handle dropdown item clicks
  dropdownItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const newValue = item.textContent.trim();
      selectedPeriod.textContent = newValue; // Update button text
      caretWrapper.classList.remove('active'); // Close dropdown
    });
  });

  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!caretWrapper.contains(e.target)) {
      caretWrapper.classList.remove('active');
    }
  });


  //Graph
  // Sample data (replace with real data from API or PHP)
  const appointmentData = {
    "2023-09": {  // Last month (September)
      labels: Array.from({ length: 30 }, (_, i) => i + 1),  // Days 1-30
      data: [5, 8, 12, 15, 20, 18, 25, 22, 30, 28, 35, 32, 40, 38, 45, 42, 50, 48, 55, 52, 60, 58, 65, 62, 70, 68, 75, 72, 80, 78]
    },
    "2023-10": {  // Current month (October)
      labels: Array.from({ length: 31 }, (_, i) => i + 1),  // Days 1-31
      data: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 95, 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40]
    }
  };

  let chart; // Global variable for the chart instance

  // Function to initialize/update the chart
  function updateChart(selectedMonth) {
    const ctx = document.getElementById('appointment-report-id').getContext('2d');

    // Destroy existing chart if it exists
    if (chart) chart.destroy();

    // Determine last month (static demo)
    const currentData = appointmentData[selectedMonth];
    const lastMonthKey = selectedMonth === "2023-10" ? "2023-09" : "2023-09";
    const lastData = appointmentData[lastMonthKey];

    // Create the chart
    chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: currentData.labels,
        datasets: [
          {
            label: `Current Month (${selectedMonth})`,
            data: currentData.data,
            borderColor: '#28a745',
            backgroundColor: 'rgba(40, 167, 69, 0.2)',
            borderWidth: 3,
            pointRadius: 4,
            pointHoverRadius: 6,
            tension: 0, // Sharp (tusok-tusok)
            fill: false
          },
          {
            label: `Previous Month (${lastMonthKey})`,
            data: lastData.data,
            borderColor: '#dc3545',
            backgroundColor: 'rgba(220, 53, 69, 0.2)',
            borderWidth: 3,
            pointRadius: 0,
            pointHoverRadius: 6,
            tension: 0, // Sharp (tusok-tusok)
            fill: false
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
            labels: {
              boxWidth: 20,
              padding: 15
            }
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                const peak = Math.max(...context.dataset.data);
                return `${context.dataset.label}: ${context.parsed.y} appointments (Peak: ${peak})`;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Number of Appointments'
            },
            ticks: {
              stepSize: 10
            }
          },
          x: {
            title: {
              display: true,
              text: 'Day of Month'
            }
          }
        }
      }
    });
  }

  // Default chart on load
  updateChart("2023-10");


  // Initialize on page load
  const monthSelect = document.getElementById('month-select');

  // Load initial chart (current month)
  updateChart(monthSelect.value);

  // Update chart on dropdown change
  monthSelect.addEventListener('change', (e) => {
    updateChart(e.target.value);
  });



  const modal = document.getElementById("appointment-modal-container-id");
  const closeBtn = document.getElementById("close-modal-btn");
  const viewButtons = document.querySelectorAll(".view-btn");

  // OPEN MODAL
  viewButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      modal.classList.add("active");
    });
  });

  // CLOSE MODAL (X button)
  closeBtn.addEventListener("click", () => {
    modal.classList.remove("active");
  });

  // CLOSE MODAL (click outside)
  modal.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.classList.remove("active");
    }
  });






/// ===== MODAL FUNCTIONALITY =====
const modals = document.getElementById("appointments-modal-container-id");
const closeBtns = document.getElementById("close-appointments-btn");
const viewButton = document.querySelectorAll(".appointment-report-view-detail button");
const modalTitle = document.querySelector(".appointment-modal-title h3");
const modalDescription = document.querySelector(".appointment-modal-title p");
const modalHead = document.getElementById("appointments-report-modal-head");
const modalBody = document.getElementById("appointments-report-modal-body"); // Fixed typo 

// DEBUG: Check which elements are null
console.log("Modal:", modals);
console.log("Close Button:", closeBtns);
console.log("View Buttons count:", viewButton.length);
console.log("Modal Title:", modalTitle);
console.log("Modal Description:", modalDescription);
console.log("Modal Head:", modalHead);
console.log("Modal Body:", modalBody);



// Sample data for each category
const AppointmentData = {
  "completed": [
    { name: "Claire Montalban", patientId: "1001", dentist: "Dr. Maja Prudente", date: "1/19/26", service: "Ceramic Braces" },
    { name: "John Doe", patientId: "1002", dentist: "Dr. Sarah Smith", date: "1/20/26", service: "Teeth Cleaning" }
  ],
  "no-show": [
    { name: "Maria Garcia", patientId: "1003", dentist: "Dr. Michael Brown", date: "1/18/26", service: "Consultation" },
    { name: "Robert Johnson", patientId: "1004", dentist: "Dr. Maja Prudente", date: "1/17/26", service: "X-Ray" }
  ],
  "cancelled": [
    { name: "Lisa Anderson", patientId: "1005", dentist: "Dr. Sarah Smith", date: "1/16/26", service: "Root Canal" },
    { name: "David Wilson", patientId: "1006", dentist: "Dr. Michael Brown", date: "1/15/26", service: "Extraction" }
  ]
};

// Configuration for each category
const categoryConfig = {
  "completed": {
    icon: "fa-solid fa-circle-check",
    title: "Completed Appointments",
    description: "List of all successfully completed appointments this month"
  },
  "no-show": {
    icon: "fa-solid fa-circle-exclamation",
    title: "No Show Appointments",
    description: "Patients who missed their scheduled appointments without notice"
  },
  "cancelled": {
    icon: "fa-solid fa-circle-xmark",
    title: "Cancelled Appointments",
    description: "Appointments that were cancelled by patients or staff"
  }
};

// OPEN MODAL
viewButton.forEach(btn => {
  btn.addEventListener("click", () => {
    const category = btn.getAttribute("data-category");
    const config = categoryConfig[category];
    const appointments = AppointmentData[category] || [];

    // Update modal title and description
    modalTitle.innerHTML = `<i class="${config.icon}"></i> ${config.title}`;
    modalDescription.textContent = config.description;

    // Build table header
    modalHead.innerHTML = `
      <tr>
        <th>Patient Name</th>
        <th>Patient ID</th>
        <th>Service</th>
        <th>Dentist</th>
        <th>Date</th>
      </tr>
    `;

    // Build table body
    if (appointments.length > 0) {
      modalBody.innerHTML = appointments.map(apt => `
        <tr>
          <td>${apt.name}</td>
          <td>${apt.patientId}</td>
          <td>${apt.service}</td>
          <td>${apt.dentist}</td>
          <td>${apt.date}</td>
        </tr>
      `).join('');
    } else {
      modalBody.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center;">No ${category} appointments found</td>
        </tr>
      `;
    }

    // Show modal
    modals.classList.add("active");
  });
});

// CLOSE MODAL (X button)
closeBtns.addEventListener("click", () => {
  modals.classList.remove("active");
});

// CLOSE MODAL (click outside)
modals.addEventListener("click", (e) => {
  if (e.target === modals) {
    modals.classList.remove("active");
  }
});

// CLOSE MODAL (ESC key)
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && modals.classList.contains("active")) {
    modals.classList.remove("active");
  }
});

}
document.addEventListener('DOMContentLoaded', initAdminAppointmentReport);