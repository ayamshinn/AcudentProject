// ===================== FRONTDESK API HANDLER =====================
// Handles: Form submission, validation, API communication

(function() {
    'use strict';
    
    // ✅ PREVENT MULTIPLE INITIALIZATIONS
    if (window.frontdeskAPIHandlerInitialized) {
        return;
    }
    window.frontdeskAPIHandlerInitialized = true;

    // ✅ CREATE UNIQUE HANDLER FUNCTION REFERENCE
    let submitClickHandler = null;

    // ✅ CLEANUP FUNCTION - Can be called externally
    window.cleanupFrontdeskAPIHandler = function() {
        if (submitClickHandler) {
            document.removeEventListener('click', submitClickHandler);
            submitClickHandler = null;
        }
        delete window.frontdeskAPIHandlerInitialized;
        delete window.cleanupFrontdeskAPIHandler;
    };

    // ✅ INITIALIZE IMMEDIATELY
    function initHandler() {
        // Create error message container
        let errorContainer = document.querySelector(".frontdesk-error-msg");
        if (!errorContainer) {
            errorContainer = document.createElement("div");
            errorContainer.className = "frontdesk-error-msg";
            errorContainer.style.cssText = "color: #dc3545; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #f8d7da; border: 1px solid #f5c6cb; display: none;";
            
            const formContainer = document.querySelector('.appointment-add-staff-frontdesk-record-inner');
            if (formContainer) {
                formContainer.insertBefore(errorContainer, formContainer.firstChild);
            }
        }

        // Create success message container
        let successContainer = document.querySelector(".frontdesk-success-msg");
        if (!successContainer) {
            successContainer = document.createElement("div");
            successContainer.className = "frontdesk-success-msg";
            successContainer.style.cssText = "color: #155724; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #d4edda; border: 1px solid #c3e6cb; display: none;";
            
            const formContainer = document.querySelector('.appointment-add-staff-frontdesk-record-inner');
            if (formContainer) {
                formContainer.insertBefore(successContainer, formContainer.firstChild);
            }
        }

        // ==================== GET FORM DATA ====================
        const getSection1Data = () => {
            return {
                first_name: document.querySelector('#section-1 #firstName')?.value.trim() || '',
                last_name: document.querySelector('#section-1 #lastName')?.value.trim() || '',
                login_email: document.getElementById('loginEmail')?.value.trim() || '',
                contact_email: document.querySelector('#section-1 #email')?.value.trim() || '',
                password: document.getElementById('password')?.value || ''
            };
        };

        // ==================== VALIDATION ====================
        function validateSection1(data) {
            const errors = [];

            if (!data.first_name) errors.push("First name is required");
            if (!data.last_name) errors.push("Last name is required");
            if (!data.login_email) errors.push("Login email is required");
            if (!data.contact_email) errors.push("Contact email is required");
            if (!data.password) errors.push("Password is required");

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (data.login_email && !emailRegex.test(data.login_email)) {
                errors.push("Invalid login email format");
            }
            if (data.contact_email && !emailRegex.test(data.contact_email)) {
                errors.push("Invalid contact email format");
            }

            if (data.password && data.password.length < 8) {
                errors.push("Password must be at least 8 characters");
            }

            return errors;
        }

        // ==================== DISPLAY MESSAGES ====================
        function showErrors(errors) {
            if (errors.length === 0) {
                errorContainer.style.display = "none";
                return;
            }

            let errorHTML = "<strong><i class='fa-solid fa-circle-exclamation'></i> Please fix the following errors:</strong><ul style='margin: 8px 0 0 20px; padding-left: 0;'>";
            errors.forEach(error => {
                errorHTML += `<li style='margin: 4px 0;'>${error}</li>`;
            });
            errorHTML += "</ul>";

            errorContainer.innerHTML = errorHTML;
            errorContainer.style.display = "block";
            successContainer.style.display = "none";
            errorContainer.scrollIntoView({ behavior: "smooth", block: "center" });
        }

        function showSuccess(message) {
            successContainer.innerHTML = `<strong><i class='fa-solid fa-circle-check'></i> ${message}</strong>`;
            successContainer.style.display = "block";
            errorContainer.style.display = "none";
            successContainer.scrollIntoView({ behavior: "smooth", block: "center" });
        }

        // ==================== FORM SUBMISSION HANDLER ====================
        async function handleSubmit(e) {
            e.preventDefault();

            const section1Data = getSection1Data();

            // Validate
            const errors = validateSection1(section1Data);
            if (errors.length > 0) {
                showErrors(errors);
                return;
            }

            const submitBtn = e.target;

            // Disable button
            const originalBtnContent = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Creating Frontdesk Record...';

            try {
                const response = await fetch("/Acudent/backend/api/register/register-user-frontdesk.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(section1Data)
                });

                if (!response.ok) {
                    throw new Error(`Server returned ${response.status}: ${response.statusText}`);
                }

                const result = await response.json();

                if (!result.success) {
                    if (result.errors && Array.isArray(result.errors)) {
                        showErrors(result.errors);
                    } else {
                        showErrors([result.message || "Failed to create frontdesk record"]);
                    }
                    
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnContent;
                    return;
                }

                // Success
                showSuccess(result.message || "Frontdesk record created successfully!");

                setTimeout(() => {
                    window.location.href = result.redirect || "../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management.html";
                }, 2000);

            } catch (error) {
                console.error("Add frontdesk error:", error);
                showErrors([`Error connecting to server: ${error.message}. Please try again.`]);
                
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnContent;
            }
        }

        // ==================== ATTACH HANDLER - STORE REFERENCE ====================
        submitClickHandler = function(e) {
            // ✅ ONLY handle if we're on the frontdesk page AND this handler is active
            if (e.target && e.target.id === 'submitBtn' && window.frontdeskAPIHandlerInitialized) {
                handleSubmit(e);
            }
        };

        document.addEventListener('click', submitClickHandler);

        // ==================== REAL-TIME VALIDATION FEEDBACK ====================
        const section1Inputs = [
            document.querySelector('#section-1 #firstName'),
            document.querySelector('#section-1 #lastName'),
            document.getElementById('loginEmail'),
            document.querySelector('#section-1 #email'),
            document.getElementById('password')
        ];

        section1Inputs.forEach(input => {
            if (input) {
                input.addEventListener('input', () => {
                    input.classList.remove('is-invalid');
                    if (errorContainer.style.display === 'block') {
                        errorContainer.style.display = 'none';
                    }
                });
            }
        });
    }

    // ✅ SMART INITIALIZATION
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initHandler);
    } else {
        initHandler();
    }

})();