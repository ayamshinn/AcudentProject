// ===================== ADMIN MAIN API JS =====================
// Handles dynamic loading of ALL API handlers
// Mirrors the structure of admin-main.js for consistency

document.addEventListener('DOMContentLoaded', () => {
    initAPIHandlers();
});

// ===================== LISTEN FOR PAGE LOAD EVENTS =====================
function initAPIHandlers() {
    // Listen for custom 'pageLoaded' event from admin-main.js
    document.addEventListener('pageLoaded', (event) => {
        const pageUrl = event.detail.pageUrl;
        initPageAPIScript(pageUrl);
    });
}

// ===================== PAGE API SCRIPT INITIALIZER =====================
function initPageAPIScript(pageUrl) {

    
    // ========== APPOINTMENTS API ==========
    if (pageUrl.includes('admin-clinic-dentist-record.html')) {
        loadAPIScript(
            'appointmentsApi',
            '../../assets/js-api/admin-api/admin-api-subfolder/admin-add-new-dentist.api.js',
            'Appointments API Handler'
        );
    }

      if (pageUrl.includes('admin-clinic-staff-record.html')) {
        loadAPIScript(
            'appointmentsApi',
            '../../assets/js-api/admin-api/admin-api-subfolder/admin-add-new-staff.api.js',
            'Appointments API Handler'
        );
    }

    // // ========== DASHBOARD API ==========
    // if (pageUrl.includes('admin-dashboard.html')) {
    //     loadAPIScript(
    //         'dashboardApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/dashboard-api-handler.js',
    //         'Dashboard API Handler'
    //     );
    // }

    // // ========== APPOINTMENTS API ==========
    // if (pageUrl.includes('admin-appointments.html')) {
    //     loadAPIScript(
    //         'appointmentsApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/appointments-api-handler.js',
    //         'Appointments API Handler'
    //     );
    // }

    // // ========== MESSAGES API ==========
    // if (pageUrl.includes('admin-messages.html')) {
    //     loadAPIScript(
    //         'messagesApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/messages-api-handler.js',
    //         'Messages API Handler'
    //     );
    // }

    // // ========== PATIENT MANAGEMENT API ==========
    // if (pageUrl.includes('admin-patient-management.html')) {
    //     loadAPIScript(
    //         'patientManagementApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/patient-management-api-handler.js',
    //         'Patient Management API Handler'
    //     );
    // }

    // // ========== DENTIST MANAGEMENT API ==========
    // if (pageUrl.includes('admin-dentist-management.html')) {
    //     loadAPIScript(
    //         'dentistManagementApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/dentist-management-api-handler.js',
    //         'Dentist Management API Handler'
    //     );
    // }

    // // ========== STAFF MANAGEMENT API ==========
    // if (pageUrl.includes('admin-staff-management.html')) {
    //     loadAPIScript(
    //         'staffManagementApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/staff-management-api-handler.js',
    //         'Staff Management API Handler'
    //     );
    // }

    // // ========== INVENTORY MANAGEMENT API ==========
    // if (pageUrl.includes('admin-inventory-management.html')) {
    //     loadAPIScript(
    //         'inventoryManagementApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/inventory-management-api-handler.js',
    //         'Inventory Management API Handler'
    //     );
    // }

    // // ========== INVENTORY REPORT API ==========
    // if (pageUrl.includes('admin-inventory-report.html')) {
    //     loadAPIScript(
    //         'inventoryReportApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/report-folder/inventory-report-api-handler.js',
    //         'Inventory Report API Handler'
    //     );
    // }

    // // ========== FINANCIAL REPORT API ==========
    // if (pageUrl.includes('admin-financial-report.html')) {
    //     loadAPIScript(
    //         'financialReportApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/report-folder/financial-report-api-handler.js',
    //         'Financial Report API Handler'
    //     );
    // }

    // // ========== APPOINTMENT REPORT API ==========
    // if (pageUrl.includes('admin-appointment-report.html')) {
    //     loadAPIScript(
    //         'appointmentReportApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/report-folder/appointment-report-api-handler.js',
    //         'Appointment Report API Handler'
    //     );
    // }

    // // ========== PERFORMANCE REPORT API ==========
    // if (pageUrl.includes('admin-performance-report.html')) {
    //     loadAPIScript(
    //         'performanceReportApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/report-folder/performance-report-api-handler.js',
    //         'Performance Report API Handler'
    //     );
    // }

    // // ========== SERVICES API ==========
    // if (pageUrl.includes('admin-services.html')) {
    //     loadAPIScript(
    //         'servicesApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/services-api-handler.js',
    //         'Services API Handler'
    //     );
    // }

    // // ========== HELP API ==========
    // if (pageUrl.includes('admin-help.html')) {
    //     loadAPIScript(
    //         'helpApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/help-api-handler.js',
    //         'Help API Handler'
    //     );
    // }

    // // ========== SECURITY API ==========
    // if (pageUrl.includes('admin-security.html')) {
    //     loadAPIScript(
    //         'securityApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/security-api-handler.js',
    //         'Security API Handler'
    //     );
    // }

    // // ========== SETTINGS API ==========
    // if (pageUrl.includes('admin-settings.html')) {
    //     loadAPIScript(
    //         'settingsApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/settings-api-handler.js',
    //         'Settings API Handler'
    //     );
    // }

    // // ========== PATIENT MANAGEMENT DETAILED API ==========
    // if (pageUrl.includes('admin-patient-management-detailed.html')) {
    //     loadAPIScript(
    //         'patientDetailedApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/patient-management-detailed-api-handler.js',
    //         'Patient Detailed API Handler'
    //     );
    // }

    // // ========== PATIENT MANAGEMENT VIEW DETAILED API ==========
    // if (pageUrl.includes('admin-patient-management-view-detailed.html')) {
    //     loadAPIScript(
    //         'patientViewDetailedApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/patient-management-view-detailed-api-handler.js',
    //         'Patient View Detailed API Handler'
    //     );
    // }

    // // ========== DENTIST MANAGEMENT DETAILED API ==========
    // if (pageUrl.includes('admin-dentist-management-detailed.html')) {
    //     loadAPIScript(
    //         'dentistDetailedApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/dentist-management-detailed-api-handler.js',
    //         'Dentist Detailed API Handler'
    //     );
    // }

    // // ========== DENTIST MANAGEMENT VIEW DETAILED API ==========
    // if (pageUrl.includes('admin-dentist-management-view-detailed.html')) {
    //     loadAPIScript(
    //         'dentistViewDetailedApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/dentist-management-view-detailed-api-handler.js',
    //         'Dentist View Detailed API Handler'
    //     );
    // }

    // // ========== STAFF MANAGEMENT DETAILED API ==========
    // if (pageUrl.includes('admin-staff-management-detailed.html')) {
    //     loadAPIScript(
    //         'staffDetailedApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/staff-management-detailed-api-handler.js',
    //         'Staff Detailed API Handler'
    //     );
    // }

    // // ========== STAFF MANAGEMENT VIEW DETAILED API ==========
    // if (pageUrl.includes('admin-staff-management-view-detailed.html')) {
    //     loadAPIScript(
    //         'staffViewDetailedApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/staff-management-view-detailed-api-handler.js',
    //         'Staff View Detailed API Handler'
    //     );
    // }

    // // ========== ADD CLINIC DENTIST RECORD API ==========
    // if (pageUrl.includes('add-clinic-dentist-record.html')) {
    //     loadAPIScript(
    //         'addDentistApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/add-dentist-api-handler.js',
    //         'Add Dentist API Handler'
    //     );
    // }

    // // ========== ADD CLINIC STAFF RECORD API ==========
    // if (pageUrl.includes('add-clinic-staff-record.html')) {
    //     loadAPIScript(
    //         'addStaffApi',
    //         '../../assets/js/admin-ui/admin-subfolder/api-handlers/add-staff-api-handler.js',
    //         'Add Staff API Handler'
    //     );
    // }
}

// ===================== REUSABLE API SCRIPT LOADER =====================
function loadAPIScript(flagName, scriptPath, displayName) {
    // Create unique flag name in window object
    const loadedFlag = `${flagName}Loaded`;
    
    // Check if already loaded
    if (window[loadedFlag]) {
        console.log(`⚠️ ${displayName} already loaded`);
        return;
    }

    // Create and load script
    const script = document.createElement('script');
    script.src = scriptPath;
    
    script.onload = () => {
        window[loadedFlag] = true;
        console.log(`✅ ${displayName} loaded successfully`);
    };
    
    script.onerror = () => {
        console.error(`❌ Failed to load ${displayName}`);
        console.error(`   Path: ${scriptPath}`);
    };
    
    document.body.appendChild(script);
}

// ===================== CLEANUP ON PAGE UNLOAD =====================
window.addEventListener('beforeunload', () => {
    console.log('🧹 API handlers cleanup');
});

// ===================== RESET API FLAGS (Optional) =====================
// Uncomment if you want to reload API handlers on page navigation
/*
document.addEventListener('pageLoaded', () => {
    // Reset all flags to allow reloading
    Object.keys(window).forEach(key => {
        if (key.endsWith('ApiLoaded')) {
            delete window[key];
        }
    });
});
*/