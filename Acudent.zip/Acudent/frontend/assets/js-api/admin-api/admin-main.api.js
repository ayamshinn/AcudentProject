// ===================== ADMIN MAIN API JS =====================
// Handles dynamic loading of ALL API handlers

const DEBUG_MODE = false; // Set to false in production

function log(...args) {
    if (DEBUG_MODE) {
        console.log(...args);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    log('DOMContentLoaded - Initializing API handlers');
    initAPIHandlers();
});

// ===================== LISTEN FOR PAGE LOAD EVENTS =====================
function initAPIHandlers() {
    log('Setting up pageLoaded event listener');
    
    // Listen for custom 'pageLoaded' event from admin-main.js
    document.addEventListener('pageLoaded', (event) => {
        log('pageLoaded event received');
        
        const pageUrl = event.detail?.pageUrl;
        if (!pageUrl) {
            console.error('Invalid pageLoaded event - missing pageUrl');
            return;
        }
        
        log('Page URL:', pageUrl);
        initPageAPIScript(pageUrl);
    });
}

// ===================== PAGE API SCRIPT INITIALIZER =====================
async function initPageAPIScript(pageUrl) {
    log('Checking page URL:', pageUrl);
    
    try {
        // ✅ CLEANUP ALL PREVIOUS API HANDLERS BEFORE LOADING NEW ONE
        await cleanupAllAPIHandlers();
        
        // ========== DENTIST MANAGEMENT - GET ALL DENTISTS ==========
        if (pageUrl.includes('admin-dentist-management.html')) {
            log('Loading Dentist Management API...');
            
            await loadAPIScript(
                'getAllDentistsApi',
                '../../assets/js-api/admin-api/clinic-dentist-record/admin-get-all-dentist.api.js',
                'Get All Dentists API'
            );
            
            // ✅ VERIFY API IS ACTUALLY AVAILABLE
            if (typeof window.getAllDentists !== 'function') {
                console.error('❌ API script loaded but function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            
            log('Dentist Management API loaded successfully');
        }
        // ========== FRONTDESK MANAGEMENT - GET ALL FRONTDESK ==========
        else if (pageUrl.includes('admin-staff-frontdesk-management.html')) {
            log('Loading Frontdesk Management API...');
            
            await loadAPIScript(
                'getAllFrontdeskApi',
                '../../assets/js-api/admin-api/clinic-staff-record/admin-get-all-frontdesk.api.js',
                'Get All Frontdesk API'
            );
            
            // ✅ VERIFY API IS ACTUALLY AVAILABLE
            if (typeof window.getAllFrontdesk !== 'function') {
                console.error('❌ API script loaded but function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            
            log('Frontdesk Management API loaded successfully');
        }


        // ========== DENTIST DETAIL VIEW - GET DENTIST BY ID ==========
else if (pageUrl.includes('admin-dentist-management-detailed.html')) {
    log('Loading Dentist Detail View API...');
    
    await loadAPIScript(
        'getDentistByIdApi',
        '../../assets/js-api/admin-api/clinic-dentist-record/admin-get-dentist.api.js',
        'Get Dentist By ID API'
    );
    
    // ✅ VERIFY API IS ACTUALLY AVAILABLE
    if (typeof window.getDentistById !== 'function') {
        console.error('❌ API script loaded but getDentistById function not available');
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    log('Dentist Detail View API loaded successfully');
}

        // ===================== ADD THIS TO admin-main-api.js =====================
// Add this section after the frontdesk management section

// ========== ASSISTANT MANAGEMENT - GET ALL ASSISTANTS ==========
else if (pageUrl.includes('admin-staff-assistant-management.html')) {
    log('Loading Assistant Management API...');
    
    await loadAPIScript(
        'getAllAssistantsApi',
        '../../assets/js-api/admin-api/clinic-staff-record/admin-get-all-assistant.api.js',
        'Get All Assistants API'
    );
    
    // ✅ VERIFY API IS ACTUALLY AVAILABLE
    if (typeof window.getAllAssistants !== 'function') {
        console.error('❌ API script loaded but function not available');
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    log('Assistant Management API loaded successfully');
}


        // ========== DENTIST REGISTRATION - LOAD 2 API FILES ==========
        else if (pageUrl.includes('admin-dentist-register.html')) {
            log('Loading Dentist Registration APIs (2 files)...');
            
            // Load both API files in sequence
            await loadAPIScript(
                'dentistAccountApi',
                '../../assets/js-api/register/register-user-dentist.api.js',
                'Dentist Account API'
            );
            
            await loadAPIScript(
                'dentistRecordApi',
                '../../assets/js-api/admin-api/clinic-dentist-record/admin-add-dentist-record.api.js',
                'Dentist Record API'
            );
            
            log('Both Dentist APIs loaded successfully');
        }
        // ========== ASSISTANT REGISTRATION API ==========
        else if (pageUrl.includes('admin-staff-assistant-register.html')) {
            log('Loading Assistant Registration APIs (2 files)...');
            await loadAPIScript(
                'assistantRegisterApi',
                '../../assets/js-api/register/register-user-staff-assistant.api.js',
                'Assistant Registration'
            );
            await loadAPIScript(
                'asRecordApi',
                '../../assets/js-api/admin-api/clinic-staff-record/admin-add-assistant-record.api.js',
                'Assistant Record API'
            );
            log('Both Assistant APIs loaded successfully');
        }
        // ========== FRONTDESK REGISTRATION API ==========
        else if (pageUrl.includes('admin-staff-frontdesk-register.html')) {
            log('Loading Frontdesk Registration APIs (2 files)...');

            await loadAPIScript(
                'frontdeskRegisterApi',
                '../../assets/js-api/register/register-user-staff-frontdesk.api.js',
                'Frontdesk Registration'
            );
            await loadAPIScript(
                'frontdeskRecordApi',
                '../../assets/js-api/admin-api/clinic-staff-record/admin-add-frontdesk-record.api.js',
                'Frontdesk Record API'
            );
            log('Both Frontdesk APIs loaded successfully');
        }
        else {
            log('No API handler needed for this page');
        }
        
    } catch (error) {
        console.error('❌ Failed to initialize page API:', error);
    }
}

// ===================== CLEANUP ALL API HANDLERS =====================
async function cleanupAllAPIHandlers() {
    log('Cleaning up all API handlers');
    
    // Add small delay to ensure previous scripts finish
    await new Promise(resolve => setTimeout(resolve, 50));
    
    // ✅ Call cleanup functions if they exist
 const cleanupFunctions = [
    'cleanupDentistAccountAPI',      // Dentist account API
    'cleanupDentistRecordAPI',       // Dentist record API
    'cleanupGetAllDentistsAPI',      // Get all dentists API
    'cleanupGetAllFrontdeskAPI',     // Get all frontdesk API
    'cleanupGetAllAssistantsAPI',    // Get all assistants API ✅ ADD THIS
    'cleanupAssistantAPIHandler',    // Assistant API
    'cleanupFrontdeskAPIHandler',    // Frontdesk API
    'cleanupDentistRegistration'     // Dentist form handler (if separate)
];
    
    cleanupFunctions.forEach(funcName => {
        if (typeof window[funcName] === 'function') {
            try {
                window[funcName]();
                log(`${funcName} executed`);
            } catch (error) {
                console.error(`Error in ${funcName}:`, error);
            }
        }
    });
    
    // ✅ Remove all API script tags
const apiHandlers = [
    'dentistAccountApi',
    'dentistRecordApi',
    'getAllDentistsApi',
    'getAllFrontdeskApi',
    'getAllAssistantsApi',           // ✅ ADD THIS
    'assistantRegisterApi',
    'frontdeskRegisterApi',
    'asRecordApi',
    'frontdeskRecordApi'
];
    
    apiHandlers.forEach(flagName => {
        const loadedFlag = `${flagName}Loaded`;
        
        // Remove script tag
        const existingScript = document.querySelector(`script[data-api="${flagName}"]`);
        if (existingScript) {
            log(`Removing script: ${flagName}`);
            existingScript.remove();
        }
        
        // Clear loaded flag
        if (window[loadedFlag]) {
            delete window[loadedFlag];
            log(`Cleared flag: ${loadedFlag}`);
        }
    });
    
    log('Cleanup complete');
}

// ===================== REUSABLE API SCRIPT LOADER (WITH PROMISE) =====================
function loadAPIScript(flagName, scriptPath, displayName) {
    return new Promise((resolve, reject) => {
        log(`Loading ${displayName}...`);
        
        // Create unique flag name in window object
        const loadedFlag = `${flagName}Loaded`;
        
        // Check if already loaded
        if (window[loadedFlag]) {
            log(`${displayName} already loaded`);
            resolve();
            return;
        }

        // Create and load script
        const script = document.createElement('script');
        script.src = scriptPath + '?v=' + Date.now(); // ✅ Cache busting
        script.setAttribute('data-api', flagName);
        script.setAttribute('type', 'text/javascript');
        
        // Add nonce if CSP is enabled
        const metaNonce = document.querySelector('meta[name="csp-nonce"]');
        if (metaNonce) {
            script.setAttribute('nonce', metaNonce.getAttribute('content'));
        }
        
        script.onload = () => {
            // ✅ WAIT A BIT TO ENSURE SCRIPT EXECUTES
            setTimeout(() => {
                window[loadedFlag] = true;
                log(`✅ ${displayName} loaded successfully`);
                resolve();
            }, 100); // Small delay to ensure the IIFE in the API script runs
        };
        
        script.onerror = (error) => {
            console.error(`❌ Failed to load ${displayName} from ${scriptPath}`);
            
            // Show user-friendly error if in production
            if (!DEBUG_MODE) {
                showErrorNotification(`Failed to load ${displayName}. Please refresh the page.`);
            }
            
            reject(new Error(`Failed to load ${displayName}`));
        };
        
        document.body.appendChild(script);
        log(`Script tag appended: ${scriptPath}`);
    });
}

// ===================== ERROR NOTIFICATION HELPER =====================
function showErrorNotification(message) {
    // Check if notification already exists
    if (document.querySelector('.api-load-error')) {
        return;
    }
    
    const errorMsg = document.createElement('div');
    errorMsg.className = 'api-load-error';
    errorMsg.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #dc3545;
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 9999;
        max-width: 350px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        animation: slideIn 0.3s ease-out;
    `;
    
    errorMsg.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fa-solid fa-circle-exclamation" style="font-size: 20px;"></i>
            <div>
                <strong style="display: block; margin-bottom: 4px;">Error</strong>
                <span style="font-size: 14px;">${message}</span>
            </div>
        </div>
    `;
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(errorMsg);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        errorMsg.style.animation = 'slideIn 0.3s ease-out reverse';
        setTimeout(() => errorMsg.remove(), 300);
    }, 5000);
}

// ===================== CLEANUP ON PAGE UNLOAD =====================
window.addEventListener('beforeunload', () => {
    log('Page unload - cleaning up API handlers');
    cleanupAllAPIHandlers();
});

window.adminApiReady = Promise.resolve();