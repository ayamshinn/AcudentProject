// ===================== ADMIN MAIN API JS =====================
// Handles dynamic loading of ALL API handlers

const DEBUG_MODE = false; // Set to false in production

function log(...args) {
    if (DEBUG_MODE) {
        console.log(...args);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    log('DOMContentLoaded - Initializing API handlers');
    initAPIHandlers();
});

// ===================== LISTEN FOR PAGE LOAD EVENTS =====================
function initAPIHandlers() {
    log('Setting up pageLoaded event listener');
    
    // Listen for custom 'pageLoaded' event from admin-main.js
    document.addEventListener('pageLoaded', (event) => {
        log('pageLoaded event received');
        
        const pageUrl = event.detail?.pageUrl;
        if (!pageUrl) {
            console.error('Invalid pageLoaded event - missing pageUrl');
            return;
        }
        
        log('Page URL:', pageUrl);
        initPageAPIScript(pageUrl);
    });
}

// ===================== PAGE API SCRIPT INITIALIZER =====================
function initPageAPIScript(pageUrl) {
    log('Checking page URL:', pageUrl);
    
    // ========== DENTIST REGISTRATION API ==========
    if (pageUrl.includes('admin-dentist-register.html')) {
        loadAPIScript(
            'dentistRegisterApi',
            '../../assets/js-api/register/register-user-dentist.api.js',
            'Dentist Registration'
        );
    }
    // ========== ASSISTANT REGISTRATION API ==========
    else if (pageUrl.includes('admin-staff-assistant-register.html')) {
        loadAPIScript(
            'assistantRegisterApi',
            '../../assets/js-api/register/register-user-staff-assistant.api.js',
            'Assistant Registration'
        );
    }
    // ========== FRONTDESK REGISTRATION API ==========
    else if (pageUrl.includes('admin-staff-frontdesk-register.html')) {
        loadAPIScript(
            'frontdeskRegisterApi',
            '../../assets/js-api/register/register-user-staff-frontdesk.api.js',
            'Frontdesk Registration'
        );
    }
    else {
        log('No API handler needed for this page');
    }
}

// ===================== REUSABLE API SCRIPT LOADER =====================
function loadAPIScript(flagName, scriptPath, displayName) {
    log(`Loading ${displayName}...`);
    
    // Create unique flag name in window object
    const loadedFlag = `${flagName}Loaded`;
    
    // Check if already loaded
    if (window[loadedFlag]) {
        log(`${displayName} already loaded`);
        return;
    }

    // Remove old script if exists
    const existingScript = document.querySelector(`script[data-api="${flagName}"]`);
    if (existingScript) {
        log(`Removing existing ${displayName} script`);
        existingScript.remove();
        delete window[loadedFlag];
    }

    // Create and load script
    const script = document.createElement('script');
    script.src = scriptPath;
    script.setAttribute('data-api', flagName);
    script.setAttribute('type', 'text/javascript');
    
    // Add nonce if CSP is enabled
    const metaNonce = document.querySelector('meta[name="csp-nonce"]');
    if (metaNonce) {
        script.setAttribute('nonce', metaNonce.getAttribute('content'));
    }
    
    script.onload = () => {
        window[loadedFlag] = true;
        log(`${displayName} loaded successfully`);
        
        // Trigger initialization for dynamically loaded script
        const readyEvent = new Event('DOMContentLoaded');
        document.dispatchEvent(readyEvent);
        
        log(`Initialization event dispatched for ${displayName}`);
    };
    
    script.onerror = () => {
        console.error(`Failed to load ${displayName} API handler`);
        
        // Show user-friendly error if in production
        if (!DEBUG_MODE) {
            const errorMsg = document.createElement('div');
            errorMsg.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #dc3545; color: white; padding: 15px; border-radius: 5px; z-index: 9999;';
            errorMsg.textContent = 'Failed to load page resources. Please refresh.';
            document.body.appendChild(errorMsg);
            
            setTimeout(() => errorMsg.remove(), 5000);
        }
    };
    
    document.body.appendChild(script);
    log('Script tag appended to body');
}

// ===================== CLEANUP ON PAGE UNLOAD =====================
window.addEventListener('beforeunload', () => {
    log('API handlers cleanup');
});