// ==================== GET DENTIST BY ID (OPTIMIZED WITH FALLBACK) ====================
/**
 * Gets a single dentist by ID - tries dedicated endpoint first, falls back to all dentists
 * @param {number} dentistId - Dentist ID
 * @returns {Promise<Object>} - Single dentist data with schedule
 */
window.getDentistById = async function(dentistId) {
    try {
        if (DEBUG_MODE) console.log('📤 Fetching dentist by ID:', dentistId);

        if (!dentistId) {
            throw new Error("Dentist ID is required");
        }

        // Try the dedicated endpoint first
        try {
            const url = `/Acudent/backend/api/dentist/admin-get-dentist.php?dentist_id=${dentistId}`;
            
            if (DEBUG_MODE) console.log('📡 Request URL (dedicated endpoint):', url);

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const result = await response.json();
                if (result.success) {
                    if (DEBUG_MODE) console.log('✅ Dentist fetched from dedicated endpoint');
                    return result;
                }
            }
        } catch (endpointError) {
            if (DEBUG_MODE) console.warn('⚠️ Dedicated endpoint failed, falling back to all dentists');
        }

        // Fallback: Get all dentists and filter by ID
        if (DEBUG_MODE) console.log('📡 Using fallback method (all dentists)');
        
        const result = await window.getAllDentists();
        
        if (!result.success || !result.data) {
            throw new Error("Failed to fetch dentists");
        }

        const dentist = result.data.find(d => d.dentist_id === parseInt(dentistId));
        
        if (!dentist) {
            throw new Error(`Dentist with ID ${dentistId} not found`);
        }

        return {
            success: true,
            message: "Dentist retrieved successfully",
            data: dentist
        };

    } catch (error) {
        console.error("Failed to fetch dentist by ID:", error.message);
        throw error;
    }
};