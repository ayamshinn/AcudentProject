/**
 * Dentist Record API Client
 * JavaScript functions for creating dentist professional records
 */

const DentistRecordAPI = {
    // API endpoint
    endpoint: '/Acudent/backend/api/dentist/admin-add-dentist-record.php',

    /**
     * Add dentist record for existing user
     * @param {Object} dentistData - Dentist professional information
     * @returns {Promise<Object>} API response
     */
    async addDentistRecord(dentistData) {
        try {
            const response = await fetch(this.endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(dentistData)
            });

            const result = await response.json();
            
            if (!response.ok || !result.success) {
                throw new Error(result.message || 'Failed to create dentist record');
            }

            return result;

        } catch (error) {
            console.error('Error adding dentist record:', error);
            throw error;
        }
    },

    /**
     * Validate dentist data before submission
     * @param {Object} data - Dentist data to validate
     * @returns {Object} Validation result
     */
    validateDentistData(data) {
        const errors = [];

        // Required fields
        if (!data.user_id) {
            errors.push('User ID is required');
        }

        if (!data.licenseNumber || data.licenseNumber.trim() === '') {
            errors.push('License number is required');
        }

        if (!data.specialization || data.specialization.trim() === '') {
            errors.push('Specialization is required');
        }

        if (!data.education || data.education.trim() === '') {
            errors.push('Education is required');
        }

        // Optional phone validation
        if (data.phone && !/^\+?[0-9\s\-()]+$/.test(data.phone)) {
            errors.push('Invalid phone number format');
        }

        // Optional email validation (if email field is used)
        if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
            errors.push('Invalid email format');
        }

        // Validate URL fields if provided
        const urlFields = ['linkedin', 'facebook', 'instagram', 'tiktok', 'youtube'];
        urlFields.forEach(field => {
            if (data[field] && data[field].trim() !== '') {
                try {
                    new URL(data[field]);
                } catch (e) {
                    errors.push(`Invalid ${field} URL format`);
                }
            }
        });

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }
};

// Example Usage Functions

/**
 * Example 1: Add dentist record with minimal data (Required fields only)
 */
async function addDentistMinimal() {
    try {
        const dentistData = {
            user_id: 123, // Must be an existing user ID
            licenseNumber: 'LIC-2025-001',
            specialization: 'General Dentistry',
            education: 'Doctor of Dental Medicine (DMD), University of the Philippines'
        };

        const result = await DentistRecordAPI.addDentistRecord(dentistData);
        
        if (result.success) {
            console.log('Success:', result.message);
            console.log('Dentist ID:', result.data.dentist_id);
            console.log('Staff Profile ID:', result.data.staff_profile_id);
            alert('Dentist record created successfully!');
            // Redirect or update UI
            // window.location.href = '../admin-ui/admin-main.php#dentist-management';
        }
    } catch (error) {
        console.error('Failed to add dentist:', error);
        alert('Error: ' + error.message);
    }
}

/**
 * Example 2: Add dentist record with complete data (All fields)
 */
async function addDentistComplete() {
    try {
        const dentistData = {
            user_id: 456, // Must be an existing user ID
            
            // Professional info (REQUIRED)
            licenseNumber: 'LIC-2025-002',
            specialization: 'Orthodontics',
            education: 'DMD, Harvard School of Dental Medicine; Certificate in Orthodontics, Boston University',
            notes: 'Specializes in Invisalign and clear aligner therapy',
            
            // Personal info (OPTIONAL - will update staff profile if provided)
            firstName: 'Maria',
            lastName: 'Santos',
            dateOfBirth: '1985-03-15',
            gender: 'Female',
            address: 'Makati City, Metro Manila',
            phone: '+63 917 123 4567',
            
            // Social media (OPTIONAL)
            linkedin: 'https://linkedin.com/in/mariasantos',
            facebook: 'https://facebook.com/drmariasantos',
            instagram: 'https://instagram.com/dr.mariasantos',
            tiktok: 'https://tiktok.com/@drmariasantos',
            youtube: 'https://youtube.com/@drmariasantos'
        };

        const result = await DentistRecordAPI.addDentistRecord(dentistData);
        
        if (result.success) {
            console.log('Dentist record created successfully!');
            console.log('User ID:', result.data.user_id);
            console.log('Staff Profile ID:', result.data.staff_profile_id);
            console.log('Dentist ID:', result.data.dentist_id);
            alert('Dentist record created successfully!');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error: ' + error.message);
    }
}

/**
 * Example 3: Add dentist record with validation
 */
async function addDentistWithValidation(userId, formData) {
    try {
        const dentistData = {
            user_id: userId,
            licenseNumber: formData.licenseNumber,
            specialization: formData.specialization,
            education: formData.education,
            notes: formData.notes || null,
            
            // Personal info
            firstName: formData.firstName || null,
            lastName: formData.lastName || null,
            dateOfBirth: formData.dateOfBirth || null,
            gender: formData.gender || null,
            phone: formData.phone || null,
            address: formData.address || null,
            
            // Social media
            linkedin: formData.linkedin || null,
            facebook: formData.facebook || null,
            instagram: formData.instagram || null,
            tiktok: formData.tiktok || null,
            youtube: formData.youtube || null
        };
        
        // Validate before submitting
        const validation = DentistRecordAPI.validateDentistData(dentistData);
        if (!validation.isValid) {
            alert('Validation Errors:\n' + validation.errors.join('\n'));
            return;
        }
        
        // Submit
        const result = await DentistRecordAPI.addDentistRecord(dentistData);
        
        if (result.success) {
            alert('Dentist record created successfully!');
            console.log('Result:', result.data);
            return result;
        }
        
    } catch (error) {
        console.error('Error:', error);
        alert('Error: ' + error.message);
        throw error;
    }
}

/**
 * Example 4: Add dentist with UI feedback (for your multi-step form)
 */
async function addDentistWithUI(userId, formData, messageDiv) {
    try {
        // Show loading
        if (messageDiv) {
            messageDiv.innerHTML = '<p class="loading">Creating dentist record...</p>';
        }
        
        const dentistData = {
            user_id: userId,
            
            // Section 2: Professional Information (REQUIRED)
            licenseNumber: formData.licenseNumber,
            specialization: formData.specialization,
            education: formData.education,
            notes: formData.notes || null,
            
            // Section 1: Personal Information (OPTIONAL)
            firstName: formData.firstName || null,
            lastName: formData.lastName || null,
            dateOfBirth: formData.dateOfBirth || null,
            gender: formData.gender || null,
            phone: formData.phone || null,
            address: formData.address || null,
            
            // Social Media Links (OPTIONAL)
            linkedin: formData.linkedin || null,
            facebook: formData.facebook || null,
            instagram: formData.instagram || null,
            tiktok: formData.tiktok || null,
            youtube: formData.youtube || null
        };
        
        // Validate
        const validation = DentistRecordAPI.validateDentistData(dentistData);
        if (!validation.isValid) {
            if (messageDiv) {
                messageDiv.innerHTML = `
                    <div class="alert alert-danger">
                        <h5>Validation Errors:</h5>
                        <ul>${validation.errors.map(err => `<li>${err}</li>`).join('')}</ul>
                    </div>
                `;
            }
            return;
        }
        
        // Submit
        const result = await DentistRecordAPI.addDentistRecord(dentistData);
        
        if (result.success) {
            if (messageDiv) {
                messageDiv.innerHTML = `
                    <div class="alert alert-success">
                        <h5><i class="fa-solid fa-circle-check"></i> Success!</h5>
                        <p>${result.message}</p>
                        <p><strong>Dentist ID:</strong> ${result.data.dentist_id}</p>
                        <p><strong>Staff Profile ID:</strong> ${result.data.staff_profile_id}</p>
                    </div>
                `;
            }
            
            // Redirect after 2 seconds
            setTimeout(() => {
                window.location.href = '../admin-ui/admin-main.php#dentist-management';
            }, 2000);
            
            return result;
        }
        
    } catch (error) {
        if (messageDiv) {
            messageDiv.innerHTML = `
                <div class="alert alert-danger">
                    <h5><i class="fa-solid fa-circle-xmark"></i> Error</h5>
                    <p>${error.message}</p>
                </div>
            `;
        }
        throw error;
    }
}

/**
 * Export for use in other modules
 */
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DentistRecordAPI;
}