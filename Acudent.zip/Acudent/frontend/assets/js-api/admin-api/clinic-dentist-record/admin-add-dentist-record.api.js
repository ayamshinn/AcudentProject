// ===================== DENTIST RECORD API =====================
// Handles ONLY: Dentist professional record creation API call with image upload support

(function() {
    'use strict';
    
    if (window.dentistRecordAPIInitialized) {
        return;
    }
    window.dentistRecordAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const RECORD_API_ENDPOINT = "/Acudent/backend/api/dentist/admin-add-dentist-record.php";

    // ==================== DEVELOPMENT MODE (Set to false in production) ====================
    const DEBUG_MODE = false;

    // ==================== CREATE DENTIST RECORD FUNCTION WITH IMAGE ====================
    /**
     * Creates dentist professional record with professional photo
     * @param {FormData} formData - FormData containing dentist info and professional_photo file
     * @returns {Promise<Object>} - API response
     */
    window.createDentistRecordWithImage = async function(formData) {
        try {
            if (DEBUG_MODE) console.log('📤 Creating dentist record with professional photo');

            const response = await fetch(RECORD_API_ENDPOINT, {
                method: "POST",
                body: formData
            });

            if (DEBUG_MODE) console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                if (DEBUG_MODE) console.error('❌ Server error response:', errorText);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (DEBUG_MODE) console.log('📥 Response data:', result);

            if (!result.success) {
                throw new Error(result.message || "Failed to create dentist record");
            }

            return result;

        } catch (error) {
            console.error("Dentist record creation failed:", error.message);
            throw error;
        }
    };

    // ==================== CREATE DENTIST RECORD FUNCTION (BACKWARD COMPATIBILITY) ====================
    /**
     * Creates dentist professional record (JSON version for backward compatibility)
     * @param {Object} recordData - Dentist professional information
     * @returns {Promise<Object>} - API response
     */
    window.createDentistRecord = async function(recordData) {
        try {
            if (DEBUG_MODE) console.log('📤 Creating dentist record (JSON)');

            const response = await fetch(RECORD_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(recordData)
            });

            if (DEBUG_MODE) console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                if (DEBUG_MODE) console.error('❌ Server error response:', errorText);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (DEBUG_MODE) console.log('📥 Response data:', result);

            if (!result.success) {
                throw new Error(result.message || "Failed to create dentist record");
            }

            return result;

        } catch (error) {
            console.error("Dentist record creation failed:", error.message);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    /**
     * Validates dentist record data before submission
     * @param {Object} data - Dentist data to validate
     * @returns {Object} - { isValid: boolean, errors: string[] }
     */
    window.validateDentistData = function(data) {
        const errors = [];

        // ========== REQUIRED FIELDS ==========
        
        // User ID
        if (!data.user_id) {
            errors.push('User ID is required');
        }

        // Professional Information (REQUIRED)
        if (!data.licenseNumber || data.licenseNumber.trim() === '') {
            errors.push('License number is required');
        }

        if (!data.specialization || data.specialization.trim() === '') {
            errors.push('Specialization is required');
        }

        if (!data.education || data.education.trim() === '') {
            errors.push('Education is required');
        }

        // Personal Information (REQUIRED by PHP API)
        if (!data.firstName || data.firstName.trim() === '') {
            errors.push('First name is required');
        }

        if (!data.lastName || data.lastName.trim() === '') {
            errors.push('Last name is required');
        }

        if (!data.dateOfBirth || data.dateOfBirth.trim() === '') {
            errors.push('Date of birth is required');
        }

        if (!data.gender || data.gender.trim() === '') {
            errors.push('Gender is required');
        }

        // ========== OPTIONAL FIELD VALIDATION ==========

        // Phone validation
        if (data.phone && data.phone.trim() !== '' && !/^\+?[0-9\s\-()]+$/.test(data.phone)) {
            errors.push('Invalid phone number format');
        }

        // Email validation
        if (data.email && data.email.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
            errors.push('Invalid email format');
        }

        // URL validation for social media
        const urlFields = ['linkedin', 'facebook', 'instagram', 'tiktok', 'youtube'];
        urlFields.forEach(field => {
            if (data[field] && data[field].trim() !== '') {
                try {
                    new URL(data[field]);
                } catch (e) {
                    errors.push(`Invalid ${field} URL format`);
                }
            }
        });

        // Working days validation (if provided)
        if (data.workingDays) {
            if (!Array.isArray(data.workingDays)) {
                errors.push('Working days must be an array');
            } else if (data.workingDays.length === 0) {
                errors.push('Please select at least one working day');
            } else {
                const validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                const invalidDays = data.workingDays.filter(day => !validDays.includes(day));
                if (invalidDays.length > 0) {
                    errors.push(`Invalid working days: ${invalidDays.join(', ')}`);
                }
            }
        }

        // Time validation (if provided)
        if (data.startTime && data.startTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.startTime)) {
            errors.push('Invalid start time format (use HH:MM)');
        }

        if (data.endTime && data.endTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.endTime)) {
            errors.push('Invalid end time format (use HH:MM)');
        }

        // Date validation
        if (data.startDate && data.startDate.trim() !== '') {
            const startDate = new Date(data.startDate);
            if (isNaN(startDate.getTime())) {
                errors.push('Invalid start date format');
            }
        }

        if (data.dateOfBirth && data.dateOfBirth.trim() !== '') {
            const birthDate = new Date(data.dateOfBirth);
            if (isNaN(birthDate.getTime())) {
                errors.push('Invalid date of birth format');
            } else {
                // Check if person is at least 18 years old
                const today = new Date();
                const age = today.getFullYear() - birthDate.getFullYear();
                if (age < 18) {
                    errors.push('Dentist must be at least 18 years old');
                }
            }
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    if (DEBUG_MODE) console.log('✅ Dentist Record API loaded');

})();