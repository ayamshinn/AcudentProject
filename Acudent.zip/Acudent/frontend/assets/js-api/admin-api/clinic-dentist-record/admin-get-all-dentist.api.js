// ===================== GET ALL DENTISTS API =====================
// Handles ONLY: Fetching all dentist records with search, filter, and pagination support

(function() {
    'use strict';
    
    if (window.getAllDentistsAPIInitialized) {
        return;
    }
    window.getAllDentistsAPIInitialized = true;

    // ==================== API ENDPOINTS ====================
    const GET_ALL_DENTISTS_API_ENDPOINT = "/Acudent/backend/api/dentist/admin-get-all-dentist.php";
    const GET_DENTIST_BY_ID_API_ENDPOINT = "/Acudent/backend/api/dentist/admin-get-dentist.php";

    // ==================== DEVELOPMENT MODE (Set to false in production) ====================
    const DEBUG_MODE = false;

    // ==================== GET ALL DENTISTS FUNCTION ====================
    /**
     * Fetches all dentists from the database
     * @param {Object} options - Query options
     * @param {string} options.search - Search term for filtering
     * @param {string} options.order_by - Sort order: 'alphabetical', 'newest', 'oldest'
     * @param {number} options.page - Page number for pagination
     * @param {number} options.limit - Records per page
     * @returns {Promise<Object>} - API response with dentists data
     */
    window.getAllDentists = async function(options = {}) {
        try {
            if (DEBUG_MODE) console.log('📤 Fetching all dentists with options:', options);

            // Build query parameters
            const params = new URLSearchParams();
            
            if (options.search) params.append('search', options.search);
            if (options.order_by) params.append('order_by', options.order_by);
            if (options.page) params.append('page', options.page);
            if (options.limit) params.append('limit', options.limit);

            const url = `${GET_ALL_DENTISTS_API_ENDPOINT}?${params.toString()}`;
            
            if (DEBUG_MODE) console.log('📡 Request URL:', url);

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (DEBUG_MODE) console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                if (DEBUG_MODE) console.error('❌ Server error response:', errorText);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (DEBUG_MODE) console.log('📥 Response data:', result);

            if (!result.success) {
                throw new Error(result.message || "Failed to fetch dentists");
            }

            return result;

        } catch (error) {
            console.error("Failed to fetch dentists:", error.message);
            throw error;
        }
    };

    // ==================== GET DENTIST BY ID (OPTIMIZED WITH FALLBACK) ====================
    /**
     * Gets a single dentist by ID - tries dedicated endpoint first, falls back to all dentists
     * @param {number} dentistId - Dentist ID
     * @returns {Promise<Object>} - Single dentist data with schedule
     */
    window.getDentistById = async function(dentistId) {
        try {
            if (DEBUG_MODE) console.log('📤 Fetching dentist by ID:', dentistId);

            if (!dentistId) {
                throw new Error("Dentist ID is required");
            }

            // ✅ TRY THE DEDICATED ENDPOINT FIRST
            try {
                const url = `${GET_DENTIST_BY_ID_API_ENDPOINT}?dentist_id=${dentistId}`;
                
                if (DEBUG_MODE) console.log('📡 Request URL (dedicated endpoint):', url);

                const response = await fetch(url, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                if (response.ok) {
                    const result = await response.json();
                    if (result.success) {
                        if (DEBUG_MODE) console.log('✅ Dentist fetched from dedicated endpoint');
                        return result;
                    }
                }
            } catch (endpointError) {
                if (DEBUG_MODE) console.warn('⚠️ Dedicated endpoint failed, falling back to all dentists');
            }

            // ✅ FALLBACK: GET ALL DENTISTS AND FILTER BY ID
            if (DEBUG_MODE) console.log('📡 Using fallback method (all dentists)');
            
            const result = await window.getAllDentists();
            
            if (!result.success || !result.data) {
                throw new Error("Failed to fetch dentists");
            }

            const dentist = result.data.find(d => d.dentist_id === parseInt(dentistId));
            
            if (!dentist) {
                throw new Error(`Dentist with ID ${dentistId} not found`);
            }

            return {
                success: true,
                message: "Dentist retrieved successfully",
                data: dentist
            };

        } catch (error) {
            console.error("Failed to fetch dentist by ID:", error.message);
            throw error;
        }
    };

    // ==================== SEARCH DENTISTS FUNCTION ====================
    /**
     * Searches dentists by name, email, or code
     * @param {string} searchTerm - Search term
     * @returns {Promise<Object>} - Search results
     */
    window.searchDentists = async function(searchTerm) {
        try {
            if (DEBUG_MODE) console.log('🔍 Searching dentists:', searchTerm);

            return await window.getAllDentists({ search: searchTerm });

        } catch (error) {
            console.error("Search failed:", error.message);
            throw error;
        }
    };

    // ==================== GET DENTISTS WITH PAGINATION ====================
    /**
     * Gets dentists with pagination
     * @param {number} page - Page number
     * @param {number} limit - Records per page
     * @returns {Promise<Object>} - Paginated results
     */
    window.getDentistsPaginated = async function(page = 1, limit = 10) {
        try {
            if (DEBUG_MODE) console.log('📄 Fetching paginated dentists:', { page, limit });

            return await window.getAllDentists({ page, limit });

        } catch (error) {
            console.error("Pagination failed:", error.message);
            throw error;
        }
    };

    // ==================== FORMAT DENTIST FOR DISPLAY ====================
    /**
     * Formats dentist data for display in UI
     * @param {Object} dentist - Dentist data object
     * @returns {Object} - Formatted display data
     */
    window.formatDentistForDisplay = function(dentist) {
        return {
            id: dentist.dentist_id,
            code: dentist.dentist_code,
            name: dentist.personal_info.full_name,
            firstName: dentist.personal_info.first_name,
            lastName: dentist.personal_info.last_name,
            email: dentist.personal_info.email,
            phone: dentist.personal_info.phone || 'N/A',
            specialization: dentist.professional_info.specialization,
            license: dentist.professional_info.license_number,
            position: dentist.professional_info.position || 'Dentist',
            profilePicture: dentist.profile_picture || 'default-profile.jpg',
            startDate: dentist.professional_info.start_date,
            createdAt: dentist.created_at
        };
    };

    // ==================== HELPER: GET PROFILE PICTURE ====================
    /**
     * Gets profile picture URL with fallback
     * @param {Object} dentist - Dentist data object
     * @returns {string} - Profile picture URL
     */
    window.getDentistProfilePicture = function(dentist) {
        if (dentist.profile_picture) {
            return dentist.profile_picture;
        }
        return '/Acudent/frontend/assets/images/default-pfp.jpg'; // Default fallback
    };

    // ==================== CLEANUP FUNCTION ====================
    window.cleanupGetAllDentistsAPI = function() {
        delete window.getAllDentists;
        delete window.getDentistById;
        delete window.searchDentists;
        delete window.getDentistsPaginated;
        delete window.formatDentistForDisplay;
        delete window.getDentistProfilePicture;
        delete window.getAllDentistsAPIInitialized;
        if (DEBUG_MODE) console.log('🧹 Get All Dentists API cleaned up');
    };

    if (DEBUG_MODE) console.log('✅ Get All Dentists API loaded');

})();