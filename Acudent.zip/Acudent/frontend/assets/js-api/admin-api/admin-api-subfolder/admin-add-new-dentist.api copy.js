// // API Handler for Add Dentist Record - Section 1 Focus
// document.addEventListener("DOMContentLoaded", () => {
//     const submitBtn = document.getElementById('submitBtn');
//     if (!submitBtn) return;

//     // Create error message container
//     let errorContainer = document.querySelector(".dentist-error-msg");
//     if (!errorContainer) {
//         errorContainer = document.createElement("div");
//         errorContainer.className = "dentist-error-msg";
//         errorContainer.style.cssText = "color: #dc3545; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #f8d7da; border: 1px solid #f5c6cb; display: none;";
        
//         const formContainer = document.querySelector('.appointment-add-dentist-record-inner');
//         if (formContainer) {
//             formContainer.insertBefore(errorContainer, formContainer.firstChild);
//         }
//     }

//     // Create success message container
//     let successContainer = document.querySelector(".dentist-success-msg");
//     if (!successContainer) {
//         successContainer = document.createElement("div");
//         successContainer.className = "dentist-success-msg";
//         successContainer.style.cssText = "color: #155724; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #d4edda; border: 1px solid #c3e6cb; display: none;";
        
//         const formContainer = document.querySelector('.appointment-add-dentist-record-inner');
//         if (formContainer) {
//             formContainer.insertBefore(successContainer, formContainer.firstChild);
//         }
//     }

//     // Section 1 - Account Information Fields
//     const getSection1Data = () => {
//         return {
//             first_name: document.querySelector('#section-1 #firstName')?.value.trim() || '',
//             last_name: document.querySelector('#section-1 #lastName')?.value.trim() || '',
//             login_email: document.getElementById('loginEmail')?.value.trim() || '',
//             contact_email: document.querySelector('#section-1 #email')?.value.trim() || '',
//             password: document.getElementById('password')?.value || ''
//         };
//     };

//     // Section 2 - Personal Information Fields
//     const getSection2Data = () => {
//         return {
//             middle_name: document.querySelector('#section-2 #middleName')?.value.trim() || '',
//             date_of_birth: document.getElementById('dateOfBirth')?.value || '',
//             gender: document.getElementById('gender')?.value || '',
//             phone: document.getElementById('phone')?.value.trim() || '',
//             license_number: document.getElementById('licenseNumber')?.value.trim() || '',
//             address: document.getElementById('address')?.value.trim() || ''
//         };
//     };

//     // Section 3 - Work Schedule Fields
//     const getSection3Data = () => {
//         const workingDaysCheckboxes = document.querySelectorAll('input[name="workingDays"]:checked');
//         const workingDays = Array.from(workingDaysCheckboxes).map(cb => cb.value);

//         return {
//             start_date: document.getElementById('startDate')?.value || '',
//             position: document.getElementById('position')?.value || '',
//             working_days: workingDays,
//             start_time: document.getElementById('startTime')?.value || '',
//             end_time: document.getElementById('endTime')?.value || ''
//         };
//     };

//     // Section 4 - Additional Information Fields
//     const getSection4Data = () => {
//         return {
//             specialization: document.getElementById('specialization')?.value.trim() || '',
//             education: document.getElementById('education')?.value.trim() || '',
//             notes: document.getElementById('notes')?.value.trim() || ''
//         };
//     };

//     // Validate Section 1 fields
//     function validateSection1(data) {
//         const errors = [];

//         if (!data.first_name) errors.push("First name is required");
//         if (!data.last_name) errors.push("Last name is required");
//         if (!data.login_email) errors.push("Login email is required");
//         if (!data.contact_email) errors.push("Contact email is required");
//         if (!data.password) errors.push("Password is required");

//         // Email format validation
//         const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//         if (data.login_email && !emailRegex.test(data.login_email)) {
//             errors.push("Invalid login email format");
//         }
//         if (data.contact_email && !emailRegex.test(data.contact_email)) {
//             errors.push("Invalid contact email format");
//         }

//         // Password validation (minimum 8 characters)
//         if (data.password && data.password.length < 8) {
//             errors.push("Password must be at least 8 characters");
//         }

//         return errors;
//     }

//     // Display errors
//     function showErrors(errors) {
//         if (errors.length === 0) {
//             errorContainer.style.display = "none";
//             return;
//         }

//         let errorHTML = "<strong><i class='fa-solid fa-circle-exclamation'></i> Please fix the following errors:</strong><ul style='margin: 8px 0 0 20px; padding-left: 0;'>";
//         errors.forEach(error => {
//             errorHTML += `<li style='margin: 4px 0;'>${error}</li>`;
//         });
//         errorHTML += "</ul>";

//         errorContainer.innerHTML = errorHTML;
//         errorContainer.style.display = "block";
//         successContainer.style.display = "none";

//         // Scroll to error
//         errorContainer.scrollIntoView({ behavior: "smooth", block: "center" });
//     }

//     // Show success message
//     function showSuccess(message) {
//         successContainer.innerHTML = `<strong><i class='fa-solid fa-circle-check'></i> ${message}</strong>`;
//         successContainer.style.display = "block";
//         errorContainer.style.display = "none";

//         // Scroll to success message
//         successContainer.scrollIntoView({ behavior: "smooth", block: "center" });
//     }

//     // Handle form submission
//     submitBtn.addEventListener('click', async (e) => {
//         e.preventDefault();

//         // Get all form data from all sections
//         const section1Data = getSection1Data();
//         const section2Data = getSection2Data();
//         const section3Data = getSection3Data();
//         const section4Data = getSection4Data();

//         // Validate Section 1 (primary validation focus)
//         const errors = validateSection1(section1Data);
//         if (errors.length > 0) {
//             showErrors(errors);
//             return;
//         }

//         // Verify checkbox agreement
//         const agreeTerms = document.getElementById('agreeTerms');
//         if (agreeTerms && !agreeTerms.checked) {
//             showErrors(["You must confirm that all information is accurate"]);
//             return;
//         }

//         // Combine all data
//         const formData = {
//             ...section1Data,
//             ...section2Data,
//             ...section3Data,
//             ...section4Data
//         };

//         // Disable submit button
//         const originalBtnContent = submitBtn.innerHTML;
//         submitBtn.disabled = true;
//         submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Creating Dentist Record...';

//         try {
//             const response = await fetch("/Acudent/backend/api/staff/add-dentist.php", {
//                 method: "POST",
//                 headers: {
//                     "Content-Type": "application/json"
//                 },
//                 body: JSON.stringify(formData)
//             });

//             // Check if response is ok
//             if (!response.ok) {
//                 console.error("HTTP Error:", response.status, response.statusText);
//                 throw new Error(`Server returned ${response.status}: ${response.statusText}`);
//             }

//             const result = await response.json();
//             console.log("Server response:", result);

//             if (!result.success) {
//                 // Show server errors
//                 if (result.errors && Array.isArray(result.errors)) {
//                     showErrors(result.errors);
//                 } else {
//                     showErrors([result.message || "Failed to create dentist record"]);
//                 }
                
//                 // Re-enable button
//                 submitBtn.disabled = false;
//                 submitBtn.innerHTML = originalBtnContent;
//                 return;
//             }

//             // Success
//             showSuccess(result.message || "Dentist record created successfully! Redirecting...");

//             // Redirect after 2 seconds
//             setTimeout(() => {
//                 window.location.href = result.redirect || "../admin-ui/admin-subfolder/admin-staff-management.html";
//             }, 2000);

//         } catch (error) {
//             console.error("Add dentist error:", error);
//             showErrors([`Error connecting to server: ${error.message}. Please try again.`]);
            
//             // Re-enable button
//             submitBtn.disabled = false;
//             submitBtn.innerHTML = originalBtnContent;
//         }
//     });

//     // Real-time validation feedback for Section 1 fields
//     const section1Inputs = [
//         document.querySelector('#section-1 #firstName'),
//         document.querySelector('#section-1 #lastName'),
//         document.getElementById('loginEmail'),
//         document.querySelector('#section-1 #email'),
//         document.getElementById('password')
//     ];

//     section1Inputs.forEach(input => {
//         if (input) {
//             input.addEventListener('input', () => {
//                 // Clear error styling on input
//                 input.classList.remove('is-invalid');
                
//                 // Hide error messages when user starts typing
//                 if (errorContainer.style.display === 'block') {
//                     errorContainer.style.display = 'none';
//                 }
//             });
//         }
//     });
// });



// API Handler for Add Dentist Record - SECTION 1 ONLY (TESTING)
document.addEventListener("DOMContentLoaded", () => {
    const submitBtn = document.getElementById('submitBtn');
    if (!submitBtn) return;

    // Create error message container
    let errorContainer = document.querySelector(".dentist-error-msg");
    if (!errorContainer) {
        errorContainer = document.createElement("div");
        errorContainer.className = "dentist-error-msg";
        errorContainer.style.cssText = "color: #dc3545; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #f8d7da; border: 1px solid #f5c6cb; display: none;";
        
        const formContainer = document.querySelector('.appointment-add-dentist-record-inner');
        if (formContainer) {
            formContainer.insertBefore(errorContainer, formContainer.firstChild);
        }
    }

    // Create success message container
    let successContainer = document.querySelector(".dentist-success-msg");
    if (!successContainer) {
        successContainer = document.createElement("div");
        successContainer.className = "dentist-success-msg";
        successContainer.style.cssText = "color: #155724; margin: 15px 0; padding: 12px; border-radius: 5px; background-color: #d4edda; border: 1px solid #c3e6cb; display: none;";
        
        const formContainer = document.querySelector('.appointment-add-dentist-record-inner');
        if (formContainer) {
            formContainer.insertBefore(successContainer, formContainer.firstChild);
        }
    }

    // Section 1 - Account Information Fields ONLY
    const getSection1Data = () => {
        return {
            first_name: document.querySelector('#section-1 #firstName')?.value.trim() || '',
            last_name: document.querySelector('#section-1 #lastName')?.value.trim() || '',
            login_email: document.getElementById('loginEmail')?.value.trim() || '',
            contact_email: document.querySelector('#section-1 #email')?.value.trim() || '',
            password: document.getElementById('password')?.value || ''
        };
    };

    // Validate Section 1 fields
    function validateSection1(data) {
        const errors = [];

        if (!data.first_name) errors.push("First name is required");
        if (!data.last_name) errors.push("Last name is required");
        if (!data.login_email) errors.push("Login email is required");
        if (!data.contact_email) errors.push("Contact email is required");
        if (!data.password) errors.push("Password is required");

        // Email format validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (data.login_email && !emailRegex.test(data.login_email)) {
            errors.push("Invalid login email format");
        }
        if (data.contact_email && !emailRegex.test(data.contact_email)) {
            errors.push("Invalid contact email format");
        }

        // Password validation (minimum 8 characters)
        if (data.password && data.password.length < 8) {
            errors.push("Password must be at least 8 characters");
        }

        return errors;
    }

    // Display errors
    function showErrors(errors) {
        if (errors.length === 0) {
            errorContainer.style.display = "none";
            return;
        }

        let errorHTML = "<strong><i class='fa-solid fa-circle-exclamation'></i> Please fix the following errors:</strong><ul style='margin: 8px 0 0 20px; padding-left: 0;'>";
        errors.forEach(error => {
            errorHTML += `<li style='margin: 4px 0;'>${error}</li>`;
        });
        errorHTML += "</ul>";

        errorContainer.innerHTML = errorHTML;
        errorContainer.style.display = "block";
        successContainer.style.display = "none";

        // Scroll to error
        errorContainer.scrollIntoView({ behavior: "smooth", block: "center" });
    }

    // Show success message
    function showSuccess(message) {
        successContainer.innerHTML = `<strong><i class='fa-solid fa-circle-check'></i> ${message}</strong>`;
        successContainer.style.display = "block";
        errorContainer.style.display = "none";

        // Scroll to success message
        successContainer.scrollIntoView({ behavior: "smooth", block: "center" });
    }

    // Handle form submission - SECTION 1 ONLY
    submitBtn.addEventListener('click', async (e) => {
        e.preventDefault();

        // Get Section 1 data ONLY
        const section1Data = getSection1Data();

        // Validate Section 1
        const errors = validateSection1(section1Data);
        if (errors.length > 0) {
            showErrors(errors);
            return;
        }

        // Disable submit button
        const originalBtnContent = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Testing Section 1...';

        // Log data to console for testing
        console.log('Section 1 Data to be sent:', section1Data);

        try {
            const response = await fetch("/Acudent/backend/api/clinic-staff-record/admin-add-dentist.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(section1Data)
            });

            // Check if response is ok
            if (!response.ok) {
                console.error("HTTP Error:", response.status, response.statusText);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            console.log("Server response:", result);

            if (!result.success) {
                // Show server errors
                if (result.errors && Array.isArray(result.errors)) {
                    showErrors(result.errors);
                } else {
                    showErrors([result.message || "Failed to create dentist record"]);
                }
                
                // Re-enable button
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnContent;
                return;
            }

            // Success
            showSuccess(result.message || "Section 1 test successful! Dentist account created.");

            // Show credentials in console
            if (result.credentials) {
                console.log('Generated Credentials:', result.credentials);
            }

            // Redirect after 2 seconds
            setTimeout(() => {
                window.location.href = result.redirect || "../admin-ui/admin-subfolder/admin-staff-management.html";
            }, 2000);

        } catch (error) {
            console.error("Add dentist error:", error);
            showErrors([`Error connecting to server: ${error.message}. Please try again.`]);
            
            // Re-enable button
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnContent;
        }
    });

    // Real-time validation feedback for Section 1 fields
    const section1Inputs = [
        document.querySelector('#section-1 #firstName'),
        document.querySelector('#section-1 #lastName'),
        document.getElementById('loginEmail'),
        document.querySelector('#section-1 #email'),
        document.getElementById('password')
    ];

    section1Inputs.forEach(input => {
        if (input) {
            input.addEventListener('input', () => {
                // Clear error styling on input
                input.classList.remove('is-invalid');
                
                // Hide error messages when user starts typing
                if (errorContainer.style.display === 'block') {
                    errorContainer.style.display = 'none';
                }
            });
        }
    });

    console.log('Section 1 API handler initialized - Ready for testing');
});