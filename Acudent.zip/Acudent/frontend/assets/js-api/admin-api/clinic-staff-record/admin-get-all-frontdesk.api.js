// ===================== GET ALL FRONTDESK API - FIXED VERSION =====================
// Handles ONLY: Fetching all frontdesk staff records with search, filter, and pagination support
// FIXED: Now matches how frontdesk records are created (no frontdesk_tb dependency)

(function() {
    'use strict';
    
    if (window.getAllFrontdeskAPIInitialized) {
        return;
    }
    window.getAllFrontdeskAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const GET_ALL_FRONTDESK_API_ENDPOINT = "/Acudent/backend/api/clinic-staff/admin-get-all-frontdesk.php";

    // ==================== DEVELOPMENT MODE (Set to false in production) ====================
    const DEBUG_MODE = false;

    // ==================== GET ALL FRONTDESK FUNCTION ====================
    /**
     * Fetches all frontdesk staff from the database
     * @param {Object} options - Query options
     * @param {string} options.search - Search term for filtering
     * @param {string} options.order_by - Sort order: 'alphabetical', 'newest', 'oldest'
     * @param {number} options.page - Page number for pagination
     * @param {number} options.limit - Records per page
     * @returns {Promise<Object>} - API response with frontdesk staff data
     */
    window.getAllFrontdesk = async function(options = {}) {
        try {
            if (DEBUG_MODE) console.log('📤 Fetching all frontdesk staff with options:', options);

            // Build query parameters
            const params = new URLSearchParams();
            
            if (options.search) params.append('search', options.search);
            if (options.order_by) params.append('order_by', options.order_by);
            if (options.page) params.append('page', options.page);
            if (options.limit) params.append('limit', options.limit);

            const url = `${GET_ALL_FRONTDESK_API_ENDPOINT}?${params.toString()}`;
            
            if (DEBUG_MODE) console.log('📡 Request URL:', url);

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (DEBUG_MODE) console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                if (DEBUG_MODE) console.error('❌ Server error response:', errorText);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (DEBUG_MODE) console.log('📥 Response data:', result);

            if (!result.success) {
                throw new Error(result.message || "Failed to fetch frontdesk staff");
            }

            return result;

        } catch (error) {
            console.error("Failed to fetch frontdesk staff:", error.message);
            throw error;
        }
    };

    // ==================== GET FRONTDESK BY STAFF PROFILE ID ====================
    /**
     * Gets a single frontdesk staff member by staff_profile_id
     * @param {number} staffProfileId - Staff Profile ID
     * @returns {Promise<Object>} - Single frontdesk staff data
     */
    window.getFrontdeskByStaffId = async function(staffProfileId) {
        try {
            if (DEBUG_MODE) console.log('📤 Fetching frontdesk staff by staff_profile_id:', staffProfileId);

            // Get all frontdesk staff and filter by staff_profile_id
            const result = await window.getAllFrontdesk();
            
            if (!result.success || !result.data) {
                throw new Error("Failed to fetch frontdesk staff");
            }

            const frontdesk = result.data.find(f => f.staff_profile_id === parseInt(staffProfileId));
            
            if (!frontdesk) {
                throw new Error(`Frontdesk staff with staff_profile_id ${staffProfileId} not found`);
            }

            return {
                success: true,
                message: "Frontdesk staff retrieved successfully",
                data: frontdesk
            };

        } catch (error) {
            console.error("Failed to fetch frontdesk staff by ID:", error.message);
            throw error;
        }
    };

    // ==================== SEARCH FRONTDESK FUNCTION ====================
    /**
     * Searches frontdesk staff by name, email, or code
     * @param {string} searchTerm - Search term
     * @returns {Promise<Object>} - Search results
     */
    window.searchFrontdesk = async function(searchTerm) {
        try {
            if (DEBUG_MODE) console.log('🔍 Searching frontdesk staff:', searchTerm);

            return await window.getAllFrontdesk({ search: searchTerm });

        } catch (error) {
            console.error("Search failed:", error.message);
            throw error;
        }
    };

    // ==================== GET FRONTDESK WITH PAGINATION ====================
    /**
     * Gets frontdesk staff with pagination
     * @param {number} page - Page number
     * @param {number} limit - Records per page
     * @returns {Promise<Object>} - Paginated results
     */
    window.getFrontdeskPaginated = async function(page = 1, limit = 10) {
        try {
            if (DEBUG_MODE) console.log('📄 Fetching paginated frontdesk staff:', { page, limit });

            return await window.getAllFrontdesk({ page, limit });

        } catch (error) {
            console.error("Pagination failed:", error.message);
            throw error;
        }
    };

    // ==================== FORMAT FRONTDESK FOR DISPLAY ====================
    /**
     * Formats frontdesk staff data for display in UI
     * @param {Object} frontdesk - Frontdesk staff data object
     * @returns {Object} - Formatted display data
     */
    window.formatFrontdeskForDisplay = function(frontdesk) {
        // Extract working days from schedule
        const workingDays = frontdesk.work_info.schedule
            .filter(s => s.is_working)
            .map(s => s.day);
        
        // Get shift times
        const shiftTimes = frontdesk.work_info.schedule.length > 0 
            ? {
                start: frontdesk.work_info.schedule[0].start_time,
                end: frontdesk.work_info.schedule[0].end_time
            }
            : null;

        return {
            id: frontdesk.staff_profile_id, // FIXED: Use staff_profile_id instead of frontdesk_id
            code: frontdesk.frontdesk_code,
            name: frontdesk.personal_info.full_name,
            firstName: frontdesk.personal_info.first_name,
            lastName: frontdesk.personal_info.last_name,
            email: frontdesk.personal_info.email,
            phone: frontdesk.personal_info.phone || 'N/A',
            shift: frontdesk.work_info.shift || 'Not assigned',
            workingDays: workingDays,
            shiftTimes: shiftTimes,
            profilePicture: frontdesk.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg',
            createdAt: frontdesk.created_at
        };
    };

    // ==================== HELPER: GET PROFILE PICTURE ====================
    /**
     * Gets profile picture URL with fallback
     * @param {Object} frontdesk - Frontdesk staff data object
     * @returns {string} - Profile picture URL
     */
    window.getFrontdeskProfilePicture = function(frontdesk) {
        if (frontdesk.profile_picture) {
            return frontdesk.profile_picture;
        }
        return '/Acudent/frontend/assets/images/default-pfp.jpg'; // Default fallback
    };

    // ==================== HELPER: FORMAT SCHEDULE ====================
    /**
     * Formats schedule for display
     * @param {Array} schedule - Schedule array
     * @returns {string} - Formatted schedule string
     */
    window.formatFrontdeskSchedule = function(schedule) {
        const workingDays = schedule
            .filter(s => s.is_working)
            .map(s => s.day.substring(0, 3)); // Mon, Tue, etc.
        
        if (workingDays.length === 0) return 'No schedule';
        
        const times = schedule.find(s => s.is_working);
        if (!times) return workingDays.join(', ');
        
        return `${workingDays.join(', ')} (${times.start_time} - ${times.end_time})`;
    };

    // ==================== HELPER: GET SHIFT FROM SCHEDULE ====================
    /**
     * Determines shift (MORNING/AFTERNOON/EVENING) from schedule
     * @param {Array} schedule - Schedule array
     * @returns {string} - Shift name
     */
    window.getShiftFromSchedule = function(schedule) {
        const workingDay = schedule.find(s => s.is_working);
        if (!workingDay) return 'Not assigned';
        
        const startHour = parseInt(workingDay.start_time.split(':')[0]);
        
        if (startHour < 12) {
            return 'MORNING';
        } else if (startHour < 17) {
            return 'AFTERNOON';
        } else {
            return 'EVENING';
        }
    };

    if (DEBUG_MODE) console.log('✅ Get All Frontdesk API (Fixed) loaded');

})();