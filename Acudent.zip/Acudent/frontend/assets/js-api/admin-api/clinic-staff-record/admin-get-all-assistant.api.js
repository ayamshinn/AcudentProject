// ===================== GET ALL ASSISTANTS API =====================
// Handles ONLY: Fetching all assistant staff records with search, filter, and pagination support
// MATCHES: Frontdesk pattern - queries by role instead of assistant_tb

(function() {
    'use strict';
    
    if (window.getAllAssistantsAPIInitialized) {
        return;
    }
    window.getAllAssistantsAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const GET_ALL_ASSISTANTS_API_ENDPOINT = "/Acudent/backend/api/clinic-staff/admin-get-all-assistant.php";

    // ==================== DEVELOPMENT MODE (Set to false in production) ====================
    const DEBUG_MODE = false;

    // ==================== GET ALL ASSISTANTS FUNCTION ====================
    /**
     * Fetches all assistant staff from the database
     * @param {Object} options - Query options
     * @param {string} options.search - Search term for filtering
     * @param {string} options.order_by - Sort order: 'alphabetical', 'newest', 'oldest'
     * @param {number} options.page - Page number for pagination
     * @param {number} options.limit - Records per page
     * @returns {Promise<Object>} - API response with assistant staff data
     */
    window.getAllAssistants = async function(options = {}) {
        try {
            if (DEBUG_MODE) console.log('📤 Fetching all assistant staff with options:', options);

            // Build query parameters
            const params = new URLSearchParams();
            
            if (options.search) params.append('search', options.search);
            if (options.order_by) params.append('order_by', options.order_by);
            if (options.page) params.append('page', options.page);
            if (options.limit) params.append('limit', options.limit);

            const url = `${GET_ALL_ASSISTANTS_API_ENDPOINT}?${params.toString()}`;
            
            if (DEBUG_MODE) console.log('📡 Request URL:', url);

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (DEBUG_MODE) console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                if (DEBUG_MODE) console.error('❌ Server error response:', errorText);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (DEBUG_MODE) console.log('📥 Response data:', result);

            if (!result.success) {
                throw new Error(result.message || "Failed to fetch assistant staff");
            }

            return result;

        } catch (error) {
            console.error("Failed to fetch assistant staff:", error.message);
            throw error;
        }
    };

    // ==================== GET ASSISTANT BY STAFF PROFILE ID ====================
    /**
     * Gets a single assistant staff member by staff_profile_id
     * @param {number} staffProfileId - Staff Profile ID
     * @returns {Promise<Object>} - Single assistant staff data
     */
    window.getAssistantByStaffId = async function(staffProfileId) {
        try {
            if (DEBUG_MODE) console.log('📤 Fetching assistant staff by staff_profile_id:', staffProfileId);

            // Get all assistant staff and filter by staff_profile_id
            const result = await window.getAllAssistants();
            
            if (!result.success || !result.data) {
                throw new Error("Failed to fetch assistant staff");
            }

            const assistant = result.data.find(a => a.staff_profile_id === parseInt(staffProfileId));
            
            if (!assistant) {
                throw new Error(`Assistant staff with staff_profile_id ${staffProfileId} not found`);
            }

            return {
                success: true,
                message: "Assistant staff retrieved successfully",
                data: assistant
            };

        } catch (error) {
            console.error("Failed to fetch assistant staff by ID:", error.message);
            throw error;
        }
    };

    // ==================== SEARCH ASSISTANTS FUNCTION ====================
    /**
     * Searches assistant staff by name, email, or code
     * @param {string} searchTerm - Search term
     * @returns {Promise<Object>} - Search results
     */
    window.searchAssistants = async function(searchTerm) {
        try {
            if (DEBUG_MODE) console.log('🔍 Searching assistant staff:', searchTerm);

            return await window.getAllAssistants({ search: searchTerm });

        } catch (error) {
            console.error("Search failed:", error.message);
            throw error;
        }
    };

    // ==================== GET ASSISTANTS WITH PAGINATION ====================
    /**
     * Gets assistant staff with pagination
     * @param {number} page - Page number
     * @param {number} limit - Records per page
     * @returns {Promise<Object>} - Paginated results
     */
    window.getAssistantsPaginated = async function(page = 1, limit = 10) {
        try {
            if (DEBUG_MODE) console.log('📄 Fetching paginated assistant staff:', { page, limit });

            return await window.getAllAssistants({ page, limit });

        } catch (error) {
            console.error("Pagination failed:", error.message);
            throw error;
        }
    };

    // ==================== FORMAT ASSISTANT FOR DISPLAY ====================
    /**
     * Formats assistant staff data for display in UI
     * @param {Object} assistant - Assistant staff data object
     * @returns {Object} - Formatted display data
     */
    window.formatAssistantForDisplay = function(assistant) {
        // Extract working days from schedule
        const workingDays = assistant.work_info.schedule
            .filter(s => s.is_working)
            .map(s => s.day);
        
        // Get shift times
        const shiftTimes = assistant.work_info.schedule.length > 0 
            ? {
                start: assistant.work_info.schedule[0].start_time,
                end: assistant.work_info.schedule[0].end_time
            }
            : null;

        return {
            id: assistant.staff_profile_id,
            code: assistant.assistant_code,
            name: assistant.personal_info.full_name,
            firstName: assistant.personal_info.first_name,
            lastName: assistant.personal_info.last_name,
            email: assistant.personal_info.email,
            phone: assistant.personal_info.phone || 'N/A',
            shift: assistant.work_info.shift || 'Not assigned',
            workingDays: workingDays,
            shiftTimes: shiftTimes,
            profilePicture: assistant.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg',
            createdAt: assistant.created_at
        };
    };

    // ==================== HELPER: GET PROFILE PICTURE ====================
    /**
     * Gets profile picture URL with fallback
     * @param {Object} assistant - Assistant staff data object
     * @returns {string} - Profile picture URL
     */
    window.getAssistantProfilePicture = function(assistant) {
        if (assistant.profile_picture) {
            return assistant.profile_picture;
        }
        return '/Acudent/frontend/assets/images/default-pfp.jpg'; // Default fallback
    };

    // ==================== HELPER: FORMAT SCHEDULE ====================
    /**
     * Formats schedule for display
     * @param {Array} schedule - Schedule array
     * @returns {string} - Formatted schedule string
     */
    window.formatAssistantSchedule = function(schedule) {
        const workingDays = schedule
            .filter(s => s.is_working)
            .map(s => s.day.substring(0, 3)); // Mon, Tue, etc.
        
        if (workingDays.length === 0) return 'No schedule';
        
        const times = schedule.find(s => s.is_working);
        if (!times) return workingDays.join(', ');
        
        return `${workingDays.join(', ')} (${times.start_time} - ${times.end_time})`;
    };

    // ==================== HELPER: GET SHIFT FROM SCHEDULE ====================
    /**
     * Determines shift (MORNING/AFTERNOON/EVENING) from schedule
     * @param {Array} schedule - Schedule array
     * @returns {string} - Shift name
     */
    window.getShiftFromSchedule = function(schedule) {
        const workingDay = schedule.find(s => s.is_working);
        if (!workingDay) return 'Not assigned';
        
        const startHour = parseInt(workingDay.start_time.split(':')[0]);
        
        if (startHour < 12) {
            return 'MORNING';
        } else if (startHour < 17) {
            return 'AFTERNOON';
        } else {
            return 'EVENING';
        }
    };

    // ==================== CLEANUP FUNCTION ====================
    window.cleanupGetAllAssistantsAPI = function() {
        delete window.getAllAssistantsAPIInitialized;
        delete window.getAllAssistants;
        delete window.getAssistantByStaffId;
        delete window.searchAssistants;
        delete window.getAssistantsPaginated;
        delete window.formatAssistantForDisplay;
        delete window.getAssistantProfilePicture;
        delete window.formatAssistantSchedule;
        delete window.getShiftFromSchedule;
        delete window.cleanupGetAllAssistantsAPI;
        console.log('🧹 Get All Assistants API cleaned up');
    };

    if (DEBUG_MODE) console.log('✅ Get All Assistants API loaded');

})();